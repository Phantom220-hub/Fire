# Последний костёр

Пиксельное выживание: днём собираешь ресурсы и строишь базу, ночью держишь костёр до рассвета.
Студия **Nyxvault** · главный разработчик **Анас Акрамзод**.

## Как получить APK (через GitHub)

1. Создай на GitHub новый репозиторий (например, `last-campfire`).
2. Залей в него **всё содержимое этой папки** (включая скрытую папку `.github`).
   В Termux это так:
   ```
   pkg install git unzip -y
   termux-setup-storage
   cd ~/storage/downloads
   unzip LastCampfire.zip -d LastCampfire
   cd LastCampfire
   git init -b main
   git add .
   git commit -m "Последний костёр"
   git remote add origin https://github.com/ТВОЙ_НИК/last-campfire.git
   git push -u origin main
   ```
   (вместо пароля при push вводится токен GitHub)
3. На GitHub открой вкладку **Actions** → **Build APK**. Сборка идёт 5–8 минут.
4. Открой завершённую сборку → внизу **Artifacts** → скачай `Last-Campfire-APK`.
5. Распакуй архив и установи `app-debug.apk` (разреши установку из неизвестных источников).

Если сборка не стартовала сама: Actions → Build APK → **Run workflow**.

## Управление
- Води пальцем по экрану — герой идёт и сам добывает ресурсы, сам стреляет.
- Кнопки внизу: стена, турель, факел, починка костра, улучшение костра.
- На ПК: WASD/стрелки, клавиши 1–5 — постройки.
