'use strict';
/* Nyxvault — «Последний костёр». Музыка и звуки генерируются кодом (WebAudio). */
const Snd = (function () {
  let ac = null, master, musicBus, sfxBus, rev, noiseBuf;
  let on = true, mode = 'off', timer = null, nextT = 0, step = 0, lastShoot = 0, lastHit = 0;
  const mtof = m => 440 * Math.pow(2, (m - 69) / 12);

  function init() {
    if (ac) { if (ac.state === 'suspended') ac.resume(); return; }
    const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return;
    try {
      ac = new AC();
      master = ac.createGain(); master.gain.value = on ? 0.85 : 0; master.connect(ac.destination);
      musicBus = ac.createGain(); musicBus.gain.value = 0.9; musicBus.connect(master);
      sfxBus = ac.createGain(); sfxBus.gain.value = 0.8; sfxBus.connect(master);
      // реверберация из шума
      const len = ac.sampleRate * 1.8, ir = ac.createBuffer(2, len, ac.sampleRate);
      for (let ch = 0; ch < 2; ch++) { const d = ir.getChannelData(ch); for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / len, 2.6); }
      rev = ac.createConvolver(); rev.buffer = ir;
      const rg = ac.createGain(); rg.gain.value = 0.5; rev.connect(rg); rg.connect(master);
      noiseBuf = ac.createBuffer(1, ac.sampleRate, ac.sampleRate);
      const nd = noiseBuf.getChannelData(0); for (let i = 0; i < nd.length; i++) nd[i] = Math.random() * 2 - 1;
      nextT = ac.currentTime + 0.1;
      timer = setInterval(tick, 60);
    } catch (e) { ac = null; }
  }

  function env(g, t, a, d, v) {
    g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(Math.max(v, 0.0002), t + a);
    g.gain.exponentialRampToValueAtTime(0.0001, t + a + d);
  }
  function osc(type, f, t, dur, vol, o) {
    o = o || {};
    const os = ac.createOscillator(), g = ac.createGain(); os.type = type;
    os.frequency.setValueAtTime(f, t);
    if (o.f2) os.frequency.exponentialRampToValueAtTime(o.f2, t + dur);
    const a = o.a || 0.005; env(g, t, a, dur, vol);
    let n = os;
    if (o.lp) { const lp = ac.createBiquadFilter(); lp.type = 'lowpass'; lp.frequency.value = o.lp; os.connect(lp); n = lp; }
    n.connect(g); g.connect(o.dest || sfxBus);
    if (o.wet) { const w = ac.createGain(); w.gain.value = o.wet; g.connect(w); w.connect(rev); }
    os.start(t); os.stop(t + a + dur + 0.05);
  }
  function noise(t, dur, vol, fc, type, o) {
    o = o || {};
    const s = ac.createBufferSource(); s.buffer = noiseBuf; s.loop = true;
    const f = ac.createBiquadFilter(); f.type = type || 'lowpass'; f.frequency.setValueAtTime(fc || 2000, t);
    if (o.f2) f.frequency.exponentialRampToValueAtTime(o.f2, t + dur);
    const g = ac.createGain(); env(g, t, 0.003, dur, vol);
    s.connect(f); f.connect(g); g.connect(o.dest || sfxBus);
    s.start(t); s.stop(t + dur + 0.05);
  }

  // ---------- музыка ----------
  const CH = [[45, [0, 3, 7]], [41, [0, 4, 7]], [48, [0, 4, 7]], [43, [0, 4, 7]]];
  const PENTA = [57, 60, 62, 64, 67, 69, 72, 74];
  const PAT = [0, 1, 2, 1, 0, 2, 1, 2];
  function spb() { return mode === 'boss' ? 0.285 : mode === 'night' ? 0.33 : mode === 'menu' ? 0.42 : 0.385; }

  function musicStep(t, s) {
    const bar = Math.floor(s / 8) % 4, st = s % 8, root = CH[bar][0], iv = CH[bar][1];
    const night = mode === 'night' || mode === 'boss', boss = mode === 'boss', d = spb();
    if (st === 0) {
      iv.forEach(i => osc('triangle', mtof(root + 12 + i), t, d * 7.5, night ? 0.03 : 0.04, { a: 0.6, wet: 0.5, dest: musicBus, lp: 1500 }));
      osc(night ? 'sawtooth' : 'sine', mtof(root), t, d * 7.5, night ? 0.05 : 0.07, { a: 0.25, lp: night ? 260 : 420, dest: musicBus });
    }
    const n = root + 24 + iv[PAT[st]] + (st % 4 === 3 ? 12 : 0);
    if (night) {
      osc('square', mtof(n), t, d * 0.9, 0.018, { lp: boss ? 1500 : 900, dest: musicBus, wet: 0.25 });
      if (st === 0 || st === 4 || (boss && (st === 2 || st === 6))) osc('sine', 130, t, 0.2, 0.32, { f2: 38, dest: musicBus });
      if (st % 2 === 1) noise(t, 0.05, 0.05, 7000, 'highpass', { dest: musicBus });
      if (st === 4) noise(t, 0.12, 0.07, 1800, 'bandpass', { dest: musicBus });
      if (boss && st === 0) osc('sawtooth', mtof(root + 12), t, d * 3, 0.04, { lp: 700, dest: musicBus, a: 0.02 });
    } else {
      if (Math.random() < 0.8) osc('sine', mtof(n), t, d * 1.6, 0.05, { dest: musicBus, wet: 0.6 });
      if (st % 2 === 0 && Math.random() < 0.3) osc('triangle', mtof(PENTA[(Math.random() * PENTA.length) | 0]), t, d * 3, 0.03, { dest: musicBus, wet: 0.9, a: 0.01 });
    }
  }
  function tick() {
    if (!ac || mode === 'off') { if (ac) nextT = Math.max(nextT, ac.currentTime); return; }
    if (ac.state === 'suspended') return;
    while (nextT < ac.currentTime + 0.25) { musicStep(nextT, step); step++; nextT += spb(); }
    if (nextT < ac.currentTime) nextT = ac.currentTime;
  }

  // ---------- эффекты ----------
  const SFX = {
    shoot: t => { osc('square', 880, t, 0.09, 0.05, { f2: 330, lp: 3000 }); },
    zap: t => { noise(t, 0.22, 0.12, 4000, 'bandpass', { f2: 500 }); osc('sawtooth', 1200, t, 0.2, 0.06, { f2: 120, lp: 2500 }); },
    hit: t => { noise(t, 0.05, 0.08, 1800, 'lowpass'); },
    kill: t => { osc('sine', 260, t, 0.16, 0.12, { f2: 60 }); noise(t, 0.1, 0.07, 1200, 'lowpass'); },
    chop: t => { noise(t, 0.06, 0.12, 900, 'bandpass'); osc('triangle', 180, t, 0.07, 0.1, { f2: 90 }); },
    mine: t => { osc('square', 1400, t, 0.04, 0.05, { f2: 900 }); noise(t, 0.05, 0.08, 3000, 'highpass'); },
    pick: t => { osc('square', 1000, t, 0.06, 0.05); osc('square', 1500, t + 0.05, 0.08, 0.05); },
    build: t => { osc('sine', 150, t, 0.18, 0.25, { f2: 60 }); noise(t, 0.08, 0.12, 600, 'lowpass'); osc('triangle', 660, t + 0.08, 0.2, 0.06, { wet: 0.4 }); },
    no: t => { osc('square', 160, t, 0.18, 0.07, { f2: 110 }); },
    hurt: t => { osc('sawtooth', 300, t, 0.25, 0.12, { f2: 70, lp: 1500 }); noise(t, 0.12, 0.1, 800, 'lowpass'); },
    fire: t => { osc('sawtooth', 120, t, 0.3, 0.1, { f2: 50, lp: 400 }); noise(t, 0.18, 0.1, 600, 'lowpass'); },
    nova: t => { osc('sine', 90, t, 0.45, 0.3, { f2: 380 }); noise(t, 0.35, 0.14, 2500, 'bandpass', { f2: 300 }); },
    horn: t => { osc('sawtooth', 110, t, 1.3, 0.1, { lp: 500, a: 0.2, wet: 0.5 }); osc('sawtooth', 165, t, 1.3, 0.08, { lp: 500, a: 0.25, wet: 0.5 }); },
    boss: t => { osc('sawtooth', 70, t, 1.8, 0.2, { f2: 35, lp: 700, a: 0.05, wet: 0.6 }); noise(t, 1.2, 0.12, 400, 'lowpass', { f2: 80 }); },
    dawn: t => { [0, 4, 7, 12, 16].forEach((i, k) => osc('triangle', mtof(69 + i), t + k * 0.13, 0.9, 0.09, { wet: 0.8, a: 0.01 })); },
    up: t => { [0, 7, 12].forEach((i, k) => osc('square', mtof(72 + i), t + k * 0.07, 0.15, 0.05, { wet: 0.4 })); },
    over: t => { [0, -3, -7, -12].forEach((i, k) => osc('sawtooth', mtof(57 + i), t + k * 0.25, 0.8, 0.09, { lp: 900, wet: 0.7 })); },
    boom: t => { osc('sine', 120, t, 0.5, 0.35, { f2: 30 }); noise(t, 0.4, 0.2, 1400, 'lowpass', { f2: 120 }); },
    lob: t => { osc('sine', 420, t, 0.25, 0.1, { f2: 110, wet: 0.2 }); noise(t, 0.1, 0.08, 900, 'lowpass'); },
    bolt: t => { osc('sawtooth', 220, t, 0.12, 0.08, { f2: 70, lp: 1800 }); noise(t, 0.08, 0.08, 2500, 'highpass'); },
    flame: t => { noise(t, 0.25, 0.09, 900, 'bandpass', { f2: 400 }); },
    chest: t => { [0, 4, 7, 12, 16, 19].forEach((i, k) => osc('square', mtof(72 + i), t + k * 0.06, 0.16, 0.05, { wet: 0.5 })); },
    click: t => { osc('square', 700, t, 0.04, 0.04); }
  };
  function sfx(name) {
    if (!ac || !on) return;
    const now = ac.currentTime;
    if (name === 'shoot') { if (now - lastShoot < 0.07) return; lastShoot = now; }
    if (name === 'hit') { if (now - lastHit < 0.05) return; lastHit = now; }
    try { SFX[name] && SFX[name](now + 0.001); } catch (e) { }
  }
  function setOn(v) { on = v; if (master) master.gain.setTargetAtTime(on ? 0.85 : 0, ac.currentTime, 0.05); }
  function setMode(m) { if (m !== mode) { mode = m; if (m === 'day' || m === 'menu') step = Math.ceil(step / 8) * 8; if (ac) nextT = ac.currentTime + 0.05; } }
  return { init: init, sfx: sfx, setOn: setOn, mode: setMode, isOn: () => on, ready: () => !!ac };
})();
