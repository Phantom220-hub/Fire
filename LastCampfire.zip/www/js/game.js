'use strict';
/* ПОСЛЕДНИЙ КОСТЁР — © Nyxvault. Главный разработчик: Анас Акрамзод. */
(function () {
  const WW = 1400, WH = 900, CX = 700, CY = 450;
  const $ = s => document.querySelector(s);
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const rand = (a, b) => a + Math.random() * (b - a);
  const rint = (a, b) => Math.floor(rand(a, b + 1));
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const d2 = (a, b, c, d) => (a - c) * (a - c) + (b - d) * (b - d);
  const TAU = Math.PI * 2;

  // ================= сохранение =================
  const SAVE_KEY = 'nyxvault_last_campfire_v1';
  const save = { coins: 0, best: 0, kills: 0, hero: 'hunter', owned: { hunter: true }, sound: true };
  try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s) Object.assign(save, s); } catch (e) { }
  function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { } }

  // ================= данные =================
  const HEROES = {
    hunter: { name: 'Охотник', desc: 'Меткий стрелок. Быстро стреляет, хорошо растёт с двойными зарядами.', price: 0, hp: 100, speed: 68, start: {}, bolt: '#ffb347' },
    mage: { name: 'Маг бури', desc: 'Начинает с грозовым посохом: молния бьёт по цепочке врагов. Хрупкий.', price: 60, hp: 80, speed: 66, start: { lightning: 1 }, bolt: '#c58bff' },
    robot: { name: 'Страж-6', desc: 'Стальной боец. Много здоровья, вокруг него кружатся огни.', price: 120, hp: 150, speed: 60, start: { orbit: 1 }, bolt: '#55f0ff' }
  };
  const UPG = [
    { id: 'multi', em: '✦', name: 'Двойной заряд', max: 4, desc: 'Ещё один снаряд за выстрел' },
    { id: 'dmg', em: '🔥', name: 'Сила огня', max: 6, desc: '+30% к урону героя' },
    { id: 'rate', em: '⚡', name: 'Быстрые руки', max: 6, desc: 'Стреляешь на 15% чаще' },
    { id: 'pierce', em: '🏹', name: 'Пронзающий', max: 3, desc: 'Снаряды пробивают +1 врага' },
    { id: 'lightning', em: '🌩️', name: 'Грозовой посох', max: 5, desc: 'Молния бьёт цепочкой врагов' },
    { id: 'orbit', em: '🌀', name: 'Кружащиеся огни', max: 5, desc: 'Огни крутятся вокруг тебя и жгут' },
    { id: 'nova', em: '💥', name: 'Огненное кольцо', max: 5, desc: 'Взрыв вокруг героя каждые секунды' },
    { id: 'speed', em: '👟', name: 'Лёгкие ноги', max: 4, desc: '+12% к скорости бега' },
    { id: 'vit', em: '❤️', name: 'Крепкое тело', max: 5, desc: '+30 здоровья и лечение' },
    { id: 'life', em: '🩸', name: 'Жажда жизни', max: 4, desc: 'Шанс вылечиться при убийстве' },
    { id: 'luck', em: '🍀', name: 'Золотые руки', max: 3, desc: '+35% добычи ресурсов' },
    { id: 'firehp', em: '🛡️', name: 'Щит костра', max: 3, desc: '+60 прочности костра и лечение' },
    { id: 'wall', em: '🧱', name: 'Мастер стен', max: 3, desc: 'Постройки на 50% прочнее' },
    { id: 'tur', em: '🗼', name: 'Умные турели', max: 4, desc: 'Турели бьют сильнее и чаще' }
  ];
  const ET = {
    slime: { hp: 12, spd: 24, dmg: 5, r: 5, w: 6, from: 1, coin: 1, col: '#63d36f' },
    bat: { hp: 7, spd: 50, dmg: 4, r: 4, w: 3, from: 2, coin: 1, col: '#9a6bd8' },
    ghoul: { hp: 32, spd: 30, dmg: 9, r: 6, w: 4, from: 3, coin: 2, col: '#dcd5bb' },
    ghost: { hp: 20, spd: 34, dmg: 7, r: 5, w: 3, from: 5, coin: 2, col: '#9ff3e6' },
    brute: { hp: 120, spd: 19, dmg: 20, r: 10, w: 2, from: 7, coin: 5, col: '#e0734a' },
    boss: { hp: 450, spd: 15, dmg: 26, r: 16, w: 0, from: 99, coin: 40, col: '#c58bff' }
  };
  const BUILD = [
    { id: 'wall', name: 'Стена', icon: 'wall', cost: () => ({ wood: 4 }) },
    { id: 'turret', name: 'Турель', icon: 'turret', cost: () => ({ wood: 8, stone: 6 }) },
    { id: 'torch', name: 'Факел', icon: 'torch', cost: () => ({ wood: 3, crystal: 1 }) },
    { id: 'repair', name: 'Чинить', icon: 'hammer', ico: 1, cost: () => ({ wood: 6 }) },
    { id: 'fire', name: 'Костёр+', icon: 'flame', ico: 1, cost: () => { const L = run ? run.fire.level : 1; return L >= 6 ? null : { wood: 10 * L, stone: 6 * L, crystal: L >= 3 ? L - 2 : 0 }; } }
  ];

  // ================= холст =================
  const cv = $('#cv'), ctx = cv.getContext('2d', { alpha: false });
  const lc = document.createElement('canvas'), lctx = lc.getContext('2d');
  let W = 480, H = 270, SC = 2;
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const k = Math.max(2, Math.round(window.innerHeight * dpr / 270));
    SC = k / dpr;
    W = clamp(Math.ceil(window.innerWidth / SC), 320, 760); H = Math.ceil(window.innerHeight / SC);
    cv.width = W; cv.height = H; lc.width = W; lc.height = H;
    cv.style.width = (W * SC) + 'px'; cv.style.height = (H * SC) + 'px';
  }
  window.addEventListener('resize', resize); resize();

  // ================= состояние =================
  let state = 'splash'; // splash | menu | play
  let run = null, scene = null;
  let paused = false, modalOpen = false;
  const cam = { x: 0, y: 0 };
  const input = { x: 0, y: 0, kx: 0, ky: 0 };
  let hudT = 0;

  function stats() {
    const u = run.up, hd = run.hd;
    return {
      dmg: 6 * (1 + 0.3 * (u.dmg || 0)), cd: 0.55 * Math.pow(0.85, u.rate || 0), shots: 1 + (u.multi || 0), pierce: u.pierce || 0,
      speed: hd.speed * (1 + 0.12 * (u.speed || 0)), maxHp: hd.hp + 30 * (u.vit || 0), harvest: 1 + 0.35 * (u.luck || 0),
      turret: 1 + 0.3 * (u.tur || 0), wallHp: 60 * (1 + 0.5 * (u.wall || 0)), range: 150
    };
  }

  function newRun() {
    const hd = HEROES[save.hero] || HEROES.hunter;
    const r = {
      heroId: save.hero, hd: hd, night: 1, phase: 'day', t: 0, dayLen: 60, nightLen: 52, time: 0,
      player: { kind: 'p', x: CX - 34, y: CY + 34, r: 5, hp: hd.hp, maxHp: hd.hp, face: 0.6, anim: 0, inv: 0, cd: 0.3, ht: 0, lt: 2, nt: 3, swing: 0, moving: false, fx: 1, fy: 0 },
      fire: { kind: 'f', x: CX, y: CY + 2, r: 11, hp: 100, maxHp: 100, level: 1, flash: 0, aura: 0.5 },
      res: { wood: 0, stone: 0, crystal: 0 }, nodes: [], structs: [], enemies: [], projs: [], eprojs: [], parts: [], bolts: [], rings: [], flies: [],
      up: Object.assign({}, hd.start), kills: 0, coins: 0, bosses: 0, spawnAcc: 0, shake: 0, burstT: 16, orbA: 0, bossRef: null,
      over: false, overT: 0, st: null, dark: 0, dkOverride: null, embT: 0, hintShown: {}, why: ''
    };
    for (let i = 0; i < 38; i++) r.flies.push({ x: rand(40, WW - 40), y: rand(40, WH - 40), ph: rand(0, 6), sp: rand(0.4, 1) });
    run = r; r.st = stats();
    regrow(r, true);
    return r;
  }

  // ================= ресурсы на карте =================
  function regrow(r, first) {
    const want = { tree: 64, rock: 22, crystal: 9 };
    const have = { tree: 0, rock: 0, crystal: 0 };
    r.nodes.forEach(n => have[n.type]++);
    Object.keys(want).forEach(type => {
      let need = want[type] - have[type], tries = 0;
      if (!first) need = Math.min(need, Math.ceil(want[type] * 0.5));
      while (need > 0 && tries++ < 400) {
        let x, y;
        if (Math.random() < 0.55) { const a = rand(0, TAU), m = Math.sqrt(Math.random()); x = CX + Math.cos(a) * 330 * m; y = CY + Math.sin(a) * 210 * m; }
        else { x = rand(50, WW - 50); y = rand(60, WH - 40); }
        if (x < 40 || x > WW - 40 || y < 50 || y > WH - 30) continue;
        if (d2(x, y, CX, CY) < 70 * 70) continue;
        let ok = true;
        for (let i = 0; i < r.nodes.length; i++) { const n = r.nodes[i]; if (d2(x, y, n.x, n.y) < 20 * 20) { ok = false; break; } }
        if (!ok) continue;
        const hp = type === 'tree' ? 4 : type === 'rock' ? 6 : 8;
        r.nodes.push({ kind: 'n', type: type, x: x, y: y, hp: hp, maxHp: hp, shake: 0, v: rint(0, type === 'crystal' ? 0 : 2), r: 6 });
        need--;
      }
    });
  }

  // ================= частицы =================
  function burst(x, y, col, n, spd, life, size, add) {
    const r = run || scene; if (!r) return;
    for (let i = 0; i < n && r.parts.length < 420; i++) {
      const a = rand(0, TAU), s = rand(0.2, 1) * spd;
      r.parts.push({ x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - spd * 0.2, life: rand(0.5, 1) * life, max: life, col: col, size: size || 1, g: 60, add: !!add });
    }
  }
  function spark(x, y, col, life) {
    const r = run || scene; if (!r || r.parts.length > 420) return;
    r.parts.push({ x: x, y: y, vx: rand(-6, 6), vy: rand(-26, -12), life: life, max: life, col: col, size: 1, g: -4, add: true });
  }

  // ================= HUD / экраны =================
  $('#icHeart').src = SPR.iconURL.heart; $('#icFlame').src = SPR.iconURL.flame;
  $('#icWood').src = SPR.iconURL.wood; $('#icStone').src = SPR.iconURL.stone; $('#icCrystal').src = SPR.iconURL.crystal;
  const elHp = $('#hpFill'), elHpT = $('#hpTxt'), elFire = $('#fireFill'), elFireT = $('#fireTxt');
  const elPh = $('#phaseTxt'), elPhF = $('#phaseFill'), elPhS = $('#phaseSub');
  const cache = {};
  function setT(el, key, v) { if (cache[key] !== v) { cache[key] = v; el.textContent = v; } }
  function hint(t, ms) {
    const h = $('#hint'); h.textContent = t; h.classList.add('on'); clearTimeout(hint.tm);
    hint.tm = setTimeout(() => h.classList.remove('on'), ms || 3200);
  }
  function banner(txt, sub, col) {
    const b = $('#banner'); b.style.color = col || '#fff'; b.innerHTML = txt + (sub ? '<small>' + sub + '</small>' : '');
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  }
  function fmtT(s) { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function costHtml(c) {
    if (!c) return '<span style="color:#ffd166">МАКС</span>';
    return ['wood', 'stone', 'crystal'].filter(k => c[k] > 0).map(k => '<span><img class="ic" src="' + SPR.iconURL[k] + '">' + c[k] + '</span>').join('') || '<span>—</span>';
  }
  function afford(c) { return !c || (run.res.wood >= (c.wood || 0) && run.res.stone >= (c.stone || 0) && run.res.crystal >= (c.crystal || 0)); }

  function buildBar() {
    const el = $('#build'); el.innerHTML = '';
    BUILD.forEach(b => {
      const d = document.createElement('div'); d.className = 'bb'; d.dataset.id = b.id;
      d.innerHTML = '<img class="main' + (b.ico ? ' ico' : '') + '" src="' + SPR.iconURL[b.icon] + '"><div class="nm">' + b.name + '</div><div class="cs"></div>';
      d.addEventListener('pointerdown', e => { e.stopPropagation(); e.preventDefault(); doBuild(b.id); });
      el.appendChild(d);
    });
  }
  buildBar();

  function updateHud() {
    const r = run; if (!r) return;
    const p = r.player, f = r.fire;
    elHp.style.transform = 'scaleX(' + clamp(p.hp / p.maxHp, 0, 1) + ')'; setT(elHpT, 'hp', Math.ceil(Math.max(0, p.hp)) + '/' + p.maxHp);
    elFire.style.transform = 'scaleX(' + clamp(f.hp / f.maxHp, 0, 1) + ')'; setT(elFireT, 'fire', Math.ceil(Math.max(0, f.hp)) + '/' + f.maxHp);
    ['wood', 'stone', 'crystal'].forEach(k => {
      const el = $('#c' + k[0].toUpperCase() + k.slice(1)), b = el.querySelector('b');
      if (cache['r' + k] !== r.res[k]) { if (cache['r' + k] !== undefined && r.res[k] > cache['r' + k]) { el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); } cache['r' + k] = r.res[k]; b.textContent = r.res[k]; }
    });
    const night = r.phase === 'night';
    document.body.classList.toggle('night', night);
    if (r.phase === 'day') { setT(elPh, 'ph', 'ДЕНЬ ' + r.night); const left = r.dayLen - r.t; elPhF.style.transform = 'scaleX(' + clamp(left / r.dayLen, 0, 1) + ')'; setT(elPhS, 'phs', left < 10 ? 'Скоро ночь! Готовь защиту' : 'Ночь через ' + fmtT(left)); }
    else if (night) { setT(elPh, 'ph', 'НОЧЬ ' + r.night); const left = r.nightLen - r.t; elPhF.style.transform = 'scaleX(' + clamp(left / r.nightLen, 0, 1) + ')'; setT(elPhS, 'phs', r.bossRef && !r.bossRef.dead ? 'Победи Короля Теней!' : 'До рассвета ' + fmtT(left)); }
    else { setT(elPh, 'ph', 'РАССВЕТ'); elPhF.style.transform = 'scaleX(1)'; setT(elPhS, 'phs', 'Выбери улучшение'); }
    const bb = $('#bossBar');
    if (r.bossRef && !r.bossRef.dead) { bb.style.display = 'block'; $('#bossFill').style.transform = 'scaleX(' + clamp(r.bossRef.hp / r.bossRef.maxHp, 0, 1) + ')'; } else bb.style.display = 'none';
    $('#vig').style.opacity = (f.hp / f.maxHp < 0.3 || p.hp / p.maxHp < 0.25) && !r.over ? (0.55 + 0.35 * Math.sin(r.time * 6)) : 0;
    document.querySelectorAll('.bb').forEach(el => {
      const b = BUILD.find(x => x.id === el.dataset.id), c = b.cost(), key = 'b' + b.id;
      const html = costHtml(c); if (cache[key] !== html) { cache[key] = html; el.querySelector('.cs').innerHTML = html; }
      const can = !!c && afford(c); el.classList.toggle('no', !can);
    });
  }

  // ----- экраны / окна -----
  function showMenu() {
    state = 'menu'; run = null; document.body.classList.remove('playing', 'night'); $('#vig').style.opacity = 0; closeModal(true);
    scene = newRun.call(null); run = null; scene.dkOverride = 0.78; scene.player.x = CX + 30; scene.player.y = CY + 30;
    $('#splash').classList.remove('on'); $('#menu').classList.add('on');
    $('#menuStat').textContent = '🪙 ' + save.coins + '   ·   Рекорд: ' + save.best + ' ноч.';
    $('#bSound').textContent = 'Звук: ' + (save.sound ? 'вкл' : 'выкл');
    Snd.mode('menu');
  }
  function openModal(html, cls) {
    const m = $('#modal'); m.innerHTML = html; m.className = 'modal panel px ' + (cls || '');
    $('#modalbg').classList.add('on'); modalOpen = true;
  }
  function closeModal(silent) { $('#modalbg').classList.remove('on'); modalOpen = false; }

  function startRun() {
    scene = null; newRun(); state = 'play'; paused = false;
    $('#menu').classList.remove('on'); closeModal();
    document.body.classList.add('playing'); cache.ph = null;
    Object.keys(cache).forEach(k => { if (/^(r|b)/.test(k)) delete cache[k]; });
    cam.x = clamp(run.player.x - W / 2, 0, WW - W); cam.y = clamp(run.player.y - H / 2, 0, WH - H);
    Snd.mode('day'); banner('ДЕНЬ 1', 'Руби деревья, добывай камень — герой всё делает сам', '#ffd166');
    setTimeout(() => { if (run && run.night === 1 && run.phase === 'day') hint('Води пальцем по экрану — герой идёт и сам добывает ресурсы', 5000); }, 2800);
    updateHud();
  }

  function showPause() {
    if (state !== 'play' || run.over || modalOpen) return;
    paused = true; Snd.sfx('click');
    openModal('<h2>Пауза</h2><p>Ночь ' + run.night + ' · убито ' + run.kills + '</p><div><button class="btn go" id="mCont">Продолжить</button></div><div><button class="btn" id="mMenu">В меню</button></div>');
    $('#mCont').onclick = () => { closeModal(); paused = false; Snd.sfx('click'); };
    $('#mMenu').onclick = () => { Snd.sfx('click'); finishRun(true); };
  }
  $('#pauseBtn').addEventListener('pointerdown', e => { e.stopPropagation(); e.preventDefault(); showPause(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) showPause(); });

  function finishRun(toMenu) {
    if (run) { const bonus = Math.floor(run.coins / 4) + Math.max(0, run.night - 1) * 3; save.coins += bonus; save.kills += run.kills; save.best = Math.max(save.best, run.night - (run.phase === 'night' ? 1 : 0)); persist(); }
    run = null; paused = false; showMenu();
  }

  function showOver() {
    const r = run; const survived = Math.max(0, r.night - 1);
    const bonus = Math.floor(r.coins / 4) + survived * 3;
    save.coins += bonus; save.best = Math.max(save.best, survived); save.kills += r.kills; persist();
    Snd.sfx('over'); Snd.mode('off');
    openModal('<h2 style="color:' + (r.why === 'fire' ? '#ff8a3a' : '#ff5a5f') + '">' + (r.why === 'fire' ? 'Костёр погас' : 'Герой пал') + '</h2>' +
      '<p>' + (r.why === 'fire' ? 'Тьма поглотила лагерь…' : 'Ночь оказалась слишком длинной…') + '</p>' +
      '<div class="stats"><div><b>' + survived + '</b>ночей пережито</div><div><b>' + r.kills + '</b>монстров убито</div><div><b>+' + bonus + '</b>монет</div></div>' +
      '<p>Рекорд: <span class="gold">' + save.best + ' ноч.</span></p>' +
      '<div><button class="btn go" id="oAgain">Ещё раз</button><button class="btn" id="oMenu">В меню</button></div>');
    r.over = 2;
    $('#oAgain').onclick = () => { Snd.sfx('click'); run = null; startRun(); };
    $('#oMenu').onclick = () => { Snd.sfx('click'); run = null; showMenu(); };
  }
  function gameOver(why) { const r = run; if (r.over) return; r.over = true; r.overT = 1.1; r.why = why; r.shake = 8; burst(r.player.x, r.player.y - 6, '#ff5a5f', 30, 90, 0.9, 2, true); }

  function showHeroes() {
    let h = '<h2>Герои</h2><p>Монеты: <span class="gold">🪙 ' + save.coins + '</span></p><div class="cards">';
    Object.keys(HEROES).forEach(id => {
      const hd = HEROES[id], own = !!save.owned[id], sel = save.hero === id;
      h += '<div class="card hero' + (sel ? ' sel' : '') + '" data-id="' + id + '"><canvas width="14" height="18" data-p="' + id + '"></canvas><b>' + hd.name + '</b><small>' + hd.desc + '</small><small style="margin-top:.3rem">❤ ' + hd.hp + ' · 👟 ' + hd.speed + '</small>' +
        '<div class="lv">' + (sel ? 'ВЫБРАН' : own ? 'ВЫБРАТЬ' : '🪙 ' + hd.price + (save.coins >= hd.price ? ' — КУПИТЬ' : ' — не хватает')) + '</div></div>';
    });
    h += '</div><div><button class="btn" id="hBack">Назад</button></div>';
    openModal(h);
    document.querySelectorAll('canvas[data-p]').forEach(c => { const s = SPR.hero[c.dataset.p][0]; c.width = s.w; c.height = s.h; c.getContext('2d').drawImage(s.c, 0, 0); });
    document.querySelectorAll('.card.hero').forEach(el => el.onclick = () => {
      const id = el.dataset.id, hd = HEROES[id];
      if (!save.owned[id]) { if (save.coins >= hd.price) { save.coins -= hd.price; save.owned[id] = true; save.hero = id; Snd.sfx('up'); } else { Snd.sfx('no'); return; } }
      else { save.hero = id; Snd.sfx('click'); }
      persist(); showHeroes(); $('#menuStat').textContent = '🪙 ' + save.coins + '   ·   Рекорд: ' + save.best + ' ноч.';
    });
    $('#hBack').onclick = () => { Snd.sfx('click'); closeModal(); };
  }
  function showAbout() {
    openModal('<h2>Последний костёр</h2><p>Днём собирай дерево, камень и кристаллы, строй стены, турели и факелы.<br>Ночью из тьмы идут чудовища — держи костёр до рассвета!<br>После каждой ночи выбирай новое улучшение. Каждая пятая ночь — босс.</p>' +
      '<p style="margin-top:.8rem">Студия <b class="gold">Nyxvault</b><br>Главный разработчик: <b class="gold">Анас Акрамзод</b></p><p style="opacity:.6;font-size:.75rem">Версия 1.0</p><div><button class="btn" id="aBack">Назад</button></div>');
    $('#aBack').onclick = () => { Snd.sfx('click'); closeModal(); };
  }

  // ================= выбор улучшения =================
  let picksLeft = 0;
  function showUpgrade(n) {
    picksLeft = n;
    const r = run, avail = UPG.filter(u => (r.up[u.id] || 0) < u.max);
    for (let i = avail.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const t = avail[i]; avail[i] = avail[j]; avail[j] = t; }
    const ch = avail.slice(0, 3);
    let h = '<h2>Рассвет! Выбери улучшение</h2><div class="cards">';
    ch.forEach(u => { const lv = r.up[u.id] || 0; h += '<div class="card" data-id="' + u.id + '"><div class="em">' + u.em + '</div><b>' + u.name + '</b><small>' + u.desc + '</small><span class="lv">Ур. ' + lv + ' → ' + (lv + 1) + '</span></div>'; });
    h += '</div>' + (n > 1 ? '<p class="gold">Награда за босса: ещё одно улучшение!</p>' : '');
    openModal(h); Snd.sfx('up');
    document.querySelectorAll('.card[data-id]').forEach(el => el.onclick = () => {
      const id = el.dataset.id; r.up[id] = (r.up[id] || 0) + 1; applyUpg(id); Snd.sfx('up');
      closeModal(); picksLeft--;
      if (picksLeft > 0) setTimeout(() => showUpgrade(picksLeft), 200); else startDay();
    });
  }
  function applyUpg(id) {
    const r = run, p = r.player, f = r.fire;
    r.st = stats();
    if (id === 'vit') { p.maxHp = r.st.maxHp; p.hp = Math.min(p.maxHp, p.hp + 30); }
    if (id === 'firehp') { f.maxHp += 60; f.hp = Math.min(f.maxHp, f.hp + 60); }
  }

  // ================= ночь / день =================
  function startDay() {
    const r = run; r.night = r.night; r.phase = 'day'; r.t = 0; r.dayLen = 50; r.nightLen = Math.min(46 + 7 * r.night, 115);
    r.player.hp = Math.min(r.player.maxHp, r.player.hp + r.player.maxHp * 0.35);
    regrow(r, false); r.st = stats();
    Snd.mode('day'); banner('ДЕНЬ ' + r.night, 'Пополни запасы и укрепи лагерь', '#ffd166');
  }
  function startNight() {
    const r = run; r.phase = 'night'; r.t = 0; r.spawnAcc = 0; r.burstT = 14; r.nightLen = Math.min(46 + 7 * r.night, 115);
    const boss = r.night % 5 === 0;
    Snd.mode(boss ? 'boss' : 'night'); Snd.sfx('horn');
    banner('НОЧЬ ' + r.night, boss ? 'Пришёл Король Теней!' : 'Защити костёр до рассвета', boss ? '#d79bff' : '#8fa0ff');
    if (r.night === 1) setTimeout(() => hint('Герой стреляет сам. Не дай монстрам потушить костёр!', 5000), 2600);
    if (boss) spawnBoss();
  }
  function endNight() {
    const r = run; r.phase = 'choose';
    r.enemies.forEach(e => { if (!e.dead) { e.dead = true; burst(e.x, e.y - 6, ET[e.type].col, 8, 50, 0.7, 1, true); } });
    r.enemies = []; r.eprojs = []; r.bossRef = null;
    r.coins += 5 + r.night * 2; save.best = Math.max(save.best, r.night); persist();
    Snd.sfx('dawn'); Snd.mode('day'); banner('РАССВЕТ', 'Ночь ' + r.night + ' пережита!', '#ffd166');
    const boss = r.night % 5 === 0; r.night++;
    setTimeout(() => { if (run === r && !r.over) showUpgrade(boss ? 2 : 1); }, 1400);
  }
  function darkness(r) {
    if (r.dkOverride !== null) return r.dkOverride;
    if (r.phase === 'day') { const l = r.dayLen - r.t; return l < 8 ? 1 - l / 8 : 0; }
    if (r.phase === 'night') { const l = r.nightLen - r.t; return (l < 8 && !(r.bossRef && !r.bossRef.dead)) ? clamp(l / 8, 0, 1) : 1; }
    return 0;
  }

  // ================= враги =================
  function spawnEnemy(type, x, y) {
    const t = ET[type], r = run, n = r.night - 1, m = 1 + 0.15 * n;
    const e = { type: type, x: x, y: y, hp: t.hp * m, maxHp: t.hp * m, spd: t.spd * rand(0.9, 1.1), r: t.r, dmg: t.dmg * (1 + 0.08 * n), kx: 0, ky: 0, hit: 0, cd: rand(0, 0.6), tgt: null, tt: rand(0, 0.4), orb: 0, ph: rand(0, 6.28), anim: rand(0, 5), dead: false };
    r.enemies.push(e); return e;
  }
  function spawnPos(angle) {
    const r = run; let x, y, tries = 0;
    do {
      const a = angle !== undefined ? angle + rand(-0.35, 0.35) : rand(0, TAU), k = rand(0.95, 1.12);
      x = CX + Math.cos(a) * 480 * k; y = CY + Math.sin(a) * 320 * k;
      x = clamp(x, 30, WW - 30); y = clamp(y, 40, WH - 20);
    } while (d2(x, y, r.player.x, r.player.y) < 170 * 170 && tries++ < 5);
    return [x, y];
  }
  function pickType() {
    const n = run.night, list = []; let tot = 0;
    for (const k in ET) { const t = ET[k]; if (t.w > 0 && n >= t.from) { list.push([k, t.w]); tot += t.w; } }
    let v = Math.random() * tot; for (const it of list) { v -= it[1]; if (v <= 0) return it[0]; }
    return 'slime';
  }
  function spawnBoss() {
    const r = run, p = spawnPos(), tier = r.night / 5;
    const e = spawnEnemy('boss', p[0], p[1]);
    e.maxHp = e.hp = 450 + 260 * (tier - 1); e.dmg = 26 + 4 * tier; e.sk = 2.5; e.sm = 7; r.bossRef = e;
    Snd.sfx('boss');
  }
  function chooseTarget(e) {
    const r = run, p = r.player, f = r.fire;
    let best = f, bd = d2(e.x, e.y, f.x, f.y);
    if (e.type !== 'ghost') for (let i = 0; i < r.structs.length; i++) { const s = r.structs[i], d = d2(e.x, e.y, s.x, s.y); if (d < bd) { bd = d; best = s; } }
    if (d2(e.x, e.y, p.x, p.y) < 70 * 70 && p.hp > 0) best = p;
    e.tgt = best;
  }
  function dmgEnemy(e, d, fx, fy, kb) {
    if (e.dead) return;
    e.hp -= d; e.hit = 0.11; Snd.sfx('hit');
    const a = Math.atan2(e.y - fy, e.x - fx), k = (kb || 90) * (e.type === 'boss' ? 0.04 : e.type === 'brute' ? 0.35 : 1);
    e.kx += Math.cos(a) * k; e.ky += Math.sin(a) * k;
    if (e.hp <= 0) killEnemy(e);
  }
  function killEnemy(e) {
    if (e.dead) return; e.dead = true; const r = run, t = ET[e.type];
    r.kills++; r.coins += t.coin; burst(e.x, e.y - 6, t.col, e.type === 'boss' ? 50 : 9, e.type === 'boss' ? 130 : 60, 0.7, e.type === 'boss' ? 2 : 1, false);
    Snd.sfx('kill');
    const lf = r.up.life || 0; if (lf && Math.random() < 0.2 * lf) r.player.hp = Math.min(r.player.maxHp, r.player.hp + 2);
    if (e.type === 'boss') { r.bosses++; r.shake = 10; burst(e.x, e.y - 20, '#ffffff', 40, 160, 1, 2, true); r.eprojs = []; }
  }
  function hurtPlayer(d) {
    const p = run.player; if (p.inv > 0 || run.over) return;
    p.hp -= d; p.inv = 0.55; run.shake = Math.max(run.shake, 4); Snd.sfx('hurt'); burst(p.x, p.y - 8, '#ff5a5f', 6, 50, 0.4, 1);
    if (p.hp <= 0) gameOver('hero');
  }
  function hurtFire(d) {
    const f = run.fire; if (run.over) return;
    f.hp -= d; f.flash = 0.18; run.shake = Math.max(run.shake, 2.5);
    if (Math.random() < 0.4) Snd.sfx('fire');
    burst(f.x, f.y - 8, '#ff9a3a', 3, 40, 0.5, 1, true);
    if (f.hp <= 0) gameOver('fire');
  }
  function hurtStruct(s, d) {
    s.hp -= d; s.flash = 0.12;
    if (s.hp <= 0 && !s.dead) { s.dead = true; burst(s.x, s.y - 8, '#9a6b3e', 12, 70, 0.7, 1); Snd.sfx('hit'); }
  }
  function dmgTarget(t, d) { if (t.kind === 'p') hurtPlayer(d); else if (t.kind === 'f') hurtFire(d); else hurtStruct(t, d); }

  // ================= постройки =================
  function doBuild(id) {
    if (state !== 'play' || !run || run.over || paused || modalOpen || run.phase === 'choose') return;
    const r = run, b = BUILD.find(x => x.id === id), c = b.cost(); r.st = stats();
    if (!c) { hint('Костёр уже на максимальном уровне'); Snd.sfx('no'); return; }
    if (!afford(c)) { hint('Не хватает ресурсов'); Snd.sfx('no'); return; }
    const p = r.player, f = r.fire;
    if (id === 'repair') {
      let need = f.hp < f.maxHp; r.structs.forEach(s => { if (s.hp < s.max) need = true; });
      if (!need) { hint('Чинить нечего'); Snd.sfx('no'); return; }
      f.hp = Math.min(f.maxHp, f.hp + f.maxHp * 0.4); r.structs.forEach(s => { s.hp = Math.min(s.max, s.hp + s.max * 0.5); });
      burst(f.x, f.y - 10, '#7dff8f', 14, 60, 0.8, 1, true);
    } else if (id === 'fire') {
      f.level++; const add = 40; f.maxHp += add; f.hp = Math.min(f.maxHp, f.hp + add + 30); burst(f.x, f.y - 10, '#ffd15c', 30, 110, 1, 2, true);
      banner('КОСТЁР УРОВНЯ ' + f.level, 'Больше света, огня и прочности', '#ffb23a');
    } else {
      const ang = p.moving ? Math.atan2(p.fy, p.fx) : Math.atan2(p.fy, p.fx), tries = [0, 0.7, -0.7, 1.4, -1.4, 2.2, -2.2, 3.1];
      let pos = null;
      for (const da of tries) {
        const x = clamp(p.x + Math.cos(ang + da) * 20, 16, WW - 16), y = clamp(p.y + Math.sin(ang + da) * 20 + 2, 30, WH - 6);
        let ok = d2(x, y, f.x, f.y) > 26 * 26;
        for (let i = 0; ok && i < r.structs.length; i++) if (d2(x, y, r.structs[i].x, r.structs[i].y) < 13 * 13) ok = false;
        if (ok) { pos = [x, y]; break; }
      }
      if (!pos) { hint('Здесь нет места'); Snd.sfx('no'); return; }
      const hp = id === 'wall' ? r.st.wallHp : id === 'turret' ? 55 * (1 + 0.5 * (r.up.wall || 0)) : 35 * (1 + 0.5 * (r.up.wall || 0));
      r.structs.push({ kind: 's', type: id, x: pos[0], y: pos[1], r: id === 'torch' ? 4 : 7, hp: hp, max: hp, flash: 0, cd: rand(0.2, 0.6), aim: 0, aura: 0.5, dead: false, muz: 0 });
      burst(pos[0], pos[1] - 6, '#c9a05a', 8, 40, 0.5, 1);
    }
    r.res.wood -= c.wood || 0; r.res.stone -= c.stone || 0; r.res.crystal -= c.crystal || 0;
    Snd.sfx('build'); updateHud();
  }

  // ================= обновление =================
  function update(dt) {
    const r = run; r.time += dt; r.st = stats(); const st = r.st;
    if (r.over) { r.overT -= dt; updateParts(r, dt); if (r.over === true && r.overT <= 0) { r.over = 1; showOver(); } return; }
    // фаза
    if (r.phase === 'day') { r.t += dt; if (r.t >= r.dayLen) startNight(); }
    else if (r.phase === 'night') {
      r.t += dt; const left = r.nightLen - r.t, bossAlive = r.bossRef && !r.bossRef.dead;
      if (left > 6 || bossAlive) {
        const rate = (0.26 + 0.17 * r.night) * (r.night % 5 === 0 ? 0.6 : 1);
        r.spawnAcc += dt * rate;
        while (r.spawnAcc >= 1) { r.spawnAcc -= 1; if (r.enemies.length < 60) { const p = spawnPos(); spawnEnemy(pickType(), p[0], p[1]); } }
        r.burstT -= dt;
        if (r.burstT <= 0 && left > 12) {
          r.burstT = rand(14, 20); const a = rand(0, TAU), n = 3 + r.night;
          for (let i = 0; i < n && r.enemies.length < 70; i++) { const p = spawnPos(a); spawnEnemy(pickType(), p[0], p[1]); }
          hint('⚠ Орда с той стороны!', 2200); Snd.sfx('horn');
        }
      }
      if (r.t >= r.nightLen && !bossAlive) endNight();
    }
    updatePlayer(r, dt, st);
    updateStructs(r, dt, st);
    updateEnemies(r, dt, st);
    updateProjs(r, dt);
    // зоны огня
    const f = r.fire; f.flash = Math.max(0, f.flash - dt); f.aura -= dt;
    if (f.aura <= 0) { f.aura = 0.5; const R = 34 + 6 * f.level, D = 2.5 * f.level; r.enemies.forEach(e => { if (!e.dead && d2(e.x, e.y, f.x, f.y) < (R + e.r) * (R + e.r)) dmgEnemy(e, D, f.x, f.y, 40); }); }
    r.structs = r.structs.filter(s => !s.dead); r.enemies = r.enemies.filter(e => !e.dead);
    updateAmbient(r, dt);
    r.shake = Math.max(0, r.shake - dt * 14);
    hudT -= dt; if (hudT <= 0) { hudT = 0.1; updateHud(); }
  }

  function updateAmbient(r, dt) {
    updateParts(r, dt);
    r.embT -= dt;
    if (r.embT <= 0) { r.embT = 0.07; spark(r.fire.x + rand(-5, 5), r.fire.y - 8, pick(['#ffb23a', '#ff7a1a', '#ffe08a']), rand(0.8, 1.6)); }
    r.flies.forEach(fl => { fl.ph += dt * fl.sp; fl.x += Math.cos(fl.ph * 1.3) * 6 * dt; fl.y += Math.sin(fl.ph) * 5 * dt; });
  }
  function updateParts(r, dt) {
    const a = r.parts;
    for (let i = a.length - 1; i >= 0; i--) {
      const p = a[i]; p.life -= dt; if (p.life <= 0) { a[i] = a[a.length - 1]; a.pop(); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += p.g * dt; p.vx *= 0.99;
    }
    for (let i = r.bolts.length - 1; i >= 0; i--) { r.bolts[i].life -= dt; if (r.bolts[i].life <= 0) r.bolts.splice(i, 1); }
    for (let i = r.rings.length - 1; i >= 0; i--) { const g = r.rings[i]; g.life -= dt; g.r += (g.max - g.r) * Math.min(1, dt * 9); if (g.life <= 0) r.rings.splice(i, 1); }
  }

  function updatePlayer(r, dt, st) {
    const p = r.player;
    let ax = input.x + input.kx, ay = input.y + input.ky; const m = Math.hypot(ax, ay);
    if (m > 1) { ax /= m; ay /= m; }
    p.moving = m > 0.12;
    if (p.moving) { p.x += ax * st.speed * dt; p.y += ay * st.speed * dt; p.fx = ax / Math.max(0.01, Math.min(1, m)); p.fy = ay / Math.max(0.01, Math.min(1, m)); p.anim += dt; }
    p.x = clamp(p.x, 14, WW - 14); p.y = clamp(p.y, 26, WH - 4);
    p.inv -= dt; p.swing -= dt;
    // добыча
    p.ht -= dt;
    if (p.ht <= 0) {
      let best = null, bd = 24 * 24;
      for (let i = 0; i < r.nodes.length; i++) { const n = r.nodes[i], d = d2(p.x, p.y, n.x, n.y); if (d < bd) { bd = d; best = n; } }
      if (best) {
        p.ht = 0.42; p.swing = 0.18; best.hp--; best.shake = 0.16;
        burst(best.x, best.y - 8, best.type === 'tree' ? '#9a6b3e' : best.type === 'rock' ? '#9aa3b8' : '#6fe3ff', 4, 40, 0.4, 1);
        Snd.sfx(best.type === 'tree' ? 'chop' : 'mine');
        if (best.hp <= 0) {
          const amt = Math.round((best.type === 'crystal' ? rint(1, 2) : rint(2, 3)) * st.harvest), key = best.type === 'tree' ? 'wood' : best.type === 'rock' ? 'stone' : 'crystal';
          r.res[key] += amt; Snd.sfx('pick'); burst(best.x, best.y - 8, best.type === 'crystal' ? '#9ff3ff' : '#ffd166', 10, 60, 0.6, 1, true);
          r.nodes.splice(r.nodes.indexOf(best), 1); updateHud();
        }
      }
    }
    // автострельба
    p.cd -= dt;
    let tgt = null, bd = st.range * st.range;
    for (let i = 0; i < r.enemies.length; i++) { const e = r.enemies[i]; if (e.dead) continue; const d = d2(p.x, p.y, e.x, e.y); if (d < bd) { bd = d; tgt = e; } }
    if (tgt && p.cd <= 0) {
      p.cd = st.cd; const a0 = Math.atan2(tgt.y - (p.y - 8), tgt.x - p.x), n = st.shots;
      for (let k = 0; k < n; k++) {
        const a = a0 + (k - (n - 1) / 2) * 0.16;
        r.projs.push({ x: p.x, y: p.y - 8, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230, dmg: st.dmg, pierce: st.pierce, life: 0.9, col: r.hd.bolt, hit: [], own: 'p' });
      }
      Snd.sfx('shoot');
    }
    // молния
    const u = r.up;
    if (u.lightning) {
      p.lt -= dt;
      if (p.lt <= 0) {
        const cand = r.enemies.filter(e => !e.dead && d2(p.x, p.y, e.x, e.y) < 175 * 175);
        if (cand.length) {
          p.lt = Math.max(1.0, 3.1 - 0.4 * u.lightning); let cx = p.x, cy = p.y - 8; const hitL = [], n = 2 + u.lightning, dm = 16 + 6 * u.lightning;
          for (let k = 0; k < n; k++) {
            let b = null, bd2 = 1e9; cand.forEach(e => { if (hitL.indexOf(e) < 0 && !e.dead) { const d = d2(cx, cy, e.x, e.y); if (d < bd2 && d < (k ? 95 * 95 : 175 * 175)) { bd2 = d; b = e; } } });
            if (!b) break; hitL.push(b);
            const pts = [[cx, cy]], seg = 4; for (let s = 1; s < seg; s++) pts.push([cx + (b.x - cx) * s / seg + rand(-6, 6), cy + (b.y - 6 - cy) * s / seg + rand(-6, 6)]); pts.push([b.x, b.y - 6]);
            r.bolts.push({ pts: pts, life: 0.16 }); dmgEnemy(b, dm, cx, cy, 60); burst(b.x, b.y - 6, '#bfe8ff', 5, 60, 0.3, 1, true);
            cx = b.x; cy = b.y - 6;
          }
          Snd.sfx('zap'); r.shake = Math.max(r.shake, 1.5);
        } else p.lt = 0.3;
      }
    }
    // огни
    if (u.orbit) {
      r.orbA += dt * 3.2; const n = u.orbit + 1, R = 27, dm = 7 + 3 * u.orbit;
      for (let k = 0; k < n; k++) {
        const a = r.orbA + k * TAU / n, ox = p.x + Math.cos(a) * R, oy = p.y - 7 + Math.sin(a) * R * 0.8;
        for (let i = 0; i < r.enemies.length; i++) { const e = r.enemies[i]; if (e.dead || e.orb > 0) continue; if (d2(ox, oy, e.x, e.y - 5) < (e.r + 5) * (e.r + 5)) { e.orb = 0.35; dmgEnemy(e, dm, ox, oy, 120); } }
      }
    }
    // кольцо огня
    if (u.nova) {
      p.nt -= dt;
      if (p.nt <= 0) {
        const R = 60 + 8 * u.nova, dm = 20 + 8 * u.nova;
        if (r.enemies.some(e => !e.dead && d2(p.x, p.y, e.x, e.y) < R * R)) {
          p.nt = Math.max(2.2, 6 - 0.6 * u.nova); r.rings.push({ x: p.x, y: p.y - 6, r: 6, max: R, life: 0.45 }); Snd.sfx('nova'); r.shake = Math.max(r.shake, 3);
          r.enemies.forEach(e => { if (!e.dead && d2(p.x, p.y, e.x, e.y) < R * R) dmgEnemy(e, dm, p.x, p.y, 220); });
        } else p.nt = 0.4;
      }
    }
    // регенерация днём
    if (r.phase === 'day' && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + 2 * dt);
  }

  function updateStructs(r, dt, st) {
    for (let i = 0; i < r.structs.length; i++) {
      const s = r.structs[i]; s.flash = Math.max(0, s.flash - dt); s.muz = Math.max(0, s.muz - dt);
      if (s.type === 'turret') {
        s.cd -= dt; let t = null, bd = 150 * 150;
        for (let k = 0; k < r.enemies.length; k++) { const e = r.enemies[k]; if (e.dead) continue; const d = d2(s.x, s.y, e.x, e.y); if (d < bd) { bd = d; t = e; } }
        if (t) {
          s.aim = Math.atan2(t.y - (s.y - 13), t.x - s.x);
          if (s.cd <= 0) {
            s.cd = 0.75 / (1 + 0.18 * (r.up.tur || 0)); s.muz = 0.08;
            r.projs.push({ x: s.x, y: s.y - 13, vx: Math.cos(s.aim) * 250, vy: Math.sin(s.aim) * 250, dmg: 7 * st.turret, pierce: 0, life: 0.8, col: '#7df9ff', hit: [], own: 't' });
            Snd.sfx('shoot');
          }
        }
      } else if (s.type === 'torch') {
        s.aura -= dt;
        if (s.aura <= 0) { s.aura = 0.5; r.enemies.forEach(e => { if (!e.dead && d2(e.x, e.y, s.x, s.y) < 38 * 38) dmgEnemy(e, 2.5, s.x, s.y, 20); }); }
      }
    }
  }

  function updateEnemies(r, dt, st) {
    const en = r.enemies, p = r.player, f = r.fire;
    for (let i = 0; i < en.length; i++) {
      const e = en[i]; if (e.dead) continue;
      e.anim += dt; e.hit = Math.max(0, e.hit - dt); e.cd -= dt; e.orb -= dt;
      if (e.kx || e.ky) { e.x += e.kx * dt; e.y += e.ky * dt; const k = Math.pow(0.0006, dt); e.kx *= k; e.ky *= k; if (Math.abs(e.kx) + Math.abs(e.ky) < 2) { e.kx = 0; e.ky = 0; } }
      e.tt -= dt; if (e.tt <= 0 || !e.tgt || e.tgt.dead || (e.tgt.kind === 'p' && p.hp <= 0)) { e.tt = rand(0.35, 0.55); chooseTarget(e); }
      const tg = e.tgt, dx = tg.x - e.x, dy = tg.y - e.y, d = Math.hypot(dx, dy) || 1, reach = e.r + tg.r + 1;
      if (d > reach) {
        let sp = e.spd; if (e.type === 'bat') sp *= 1 + 0.4 * Math.sin(e.anim * 5 + e.ph);
        let vx = dx / d, vy = dy / d;
        if (e.type === 'bat') { const w = Math.sin(e.anim * 4 + e.ph) * 0.7; const nx = -vy, ny = vx; vx += nx * w; vy += ny * w; }
        e.x += vx * sp * dt; e.y += vy * sp * dt;
      } else if (e.cd <= 0) { e.cd = e.type === 'boss' ? 1.3 : 0.9; dmgTarget(tg, e.dmg); }
      // босс
      if (e.type === 'boss') {
        e.sk -= dt; e.sm -= dt; const rage = e.hp < e.maxHp * 0.5;
        if (e.sk <= 0) {
          e.sk = rage ? 2.2 : 3.2; const n = rage ? 16 : 12, off = rand(0, TAU);
          for (let k = 0; k < n; k++) { const a = off + k * TAU / n; r.eprojs.push({ x: e.x, y: e.y - 18, vx: Math.cos(a) * 62, vy: Math.sin(a) * 62, dmg: 9 + r.night * 0.6, life: 6 }); }
          Snd.sfx('boss'); r.shake = Math.max(r.shake, 3);
        }
        if (e.sm <= 0) { e.sm = rage ? 7 : 10; for (let k = 0; k < 5 && en.length < 80; k++) { const t = pick(['slime', 'ghoul', 'bat']); spawnEnemy(t, e.x + rand(-30, 30), e.y + rand(-20, 20)); } burst(e.x, e.y - 10, '#b58cff', 20, 80, 0.7, 2, true); }
      }
      // столкновения с костром и постройками
      const fd = Math.hypot(e.x - f.x, e.y - f.y), fr = e.r + f.r - 2; if (fd < fr && fd > 0.01) { e.x += (e.x - f.x) / fd * (fr - fd); e.y += (e.y - f.y) / fd * (fr - fd); }
      if (e.type !== 'ghost') for (let k = 0; k < r.structs.length; k++) { const s = r.structs[k], sd = Math.hypot(e.x - s.x, e.y - s.y), sr = e.r + s.r - 1; if (sd < sr && sd > 0.01) { e.x += (e.x - s.x) / sd * (sr - sd); e.y += (e.y - s.y) / sd * (sr - sd); } }
      // расталкивание врагов
      for (let k = i + 1; k < en.length; k++) { const o = en[k]; if (o.dead) continue; const ox = e.x - o.x, oy = e.y - o.y, rr = (e.r + o.r) * 0.8; if (Math.abs(ox) < rr && Math.abs(oy) < rr) { const od = Math.hypot(ox, oy) || 0.01; if (od < rr) { const push = (rr - od) * 0.5; e.x += ox / od * push; e.y += oy / od * push; o.x -= ox / od * push; o.y -= oy / od * push; } } }
      e.x = clamp(e.x, 4, WW - 4); e.y = clamp(e.y, 10, WH);
    }
  }

  function updateProjs(r, dt) {
    for (let i = r.projs.length - 1; i >= 0; i--) {
      const q = r.projs[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; let del = q.life <= 0;
      if (!del) for (let k = 0; k < r.enemies.length; k++) {
        const e = r.enemies[k]; if (e.dead || q.hit.indexOf(e) >= 0) continue;
        if (d2(q.x, q.y, e.x, e.y - e.r) < (e.r + 3) * (e.r + 3)) { q.hit.push(e); dmgEnemy(e, q.dmg, q.x - q.vx * 0.02, q.y - q.vy * 0.02, 100); burst(q.x, q.y, q.col, 3, 40, 0.25, 1, true); if (q.pierce-- <= 0) { del = true; break; } }
      }
      if (del) { r.projs[i] = r.projs[r.projs.length - 1]; r.projs.pop(); }
    }
    for (let i = r.eprojs.length - 1; i >= 0; i--) {
      const q = r.eprojs[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; let del = q.life <= 0 || q.x < -10 || q.x > WW + 10 || q.y < -10 || q.y > WH + 10;
      if (!del) {
        const p = r.player, f = r.fire;
        if (d2(q.x, q.y, p.x, p.y - 7) < 7 * 7) { hurtPlayer(q.dmg); del = true; }
        else if (d2(q.x, q.y, f.x, f.y - 4) < 13 * 13) { hurtFire(q.dmg * 0.8); del = true; }
        else for (let k = 0; k < r.structs.length; k++) { const s = r.structs[k]; if (d2(q.x, q.y, s.x, s.y - 6) < (s.r + 3) * (s.r + 3)) { hurtStruct(s, q.dmg); del = true; break; } }
        if (del) burst(q.x, q.y, '#b58cff', 4, 50, 0.3, 1, true);
      }
      if (del) { r.eprojs[i] = r.eprojs[r.eprojs.length - 1]; r.eprojs.pop(); }
    }
    for (let i = r.nodes.length - 1; i >= 0; i--) { const n = r.nodes[i]; if (n.shake > 0) n.shake -= dt; }
  }

  // ================= отрисовка =================
  const groundPat = ctx.createPattern(SPR.ground, 'repeat');
  const borderTrees = [];
  (function () {
    for (let x = -12; x <= WW + 12; x += 13) { borderTrees.push({ x: x + rand(-4, 4), y: rand(4, 16), v: rint(0, 2) }); borderTrees.push({ x: x + rand(-4, 4), y: WH + rand(10, 24), v: rint(0, 2) }); }
    for (let y = 8; y <= WH + 20; y += 13) { borderTrees.push({ x: rand(-6, 8), y: y, v: rint(0, 2) }); borderTrees.push({ x: WW + rand(-8, 6), y: y, v: rint(0, 2) }); }
  })();

  function spr(S, x, y, flash, alpha) {
    if (alpha !== undefined && alpha < 1) ctx.globalAlpha = alpha;
    ctx.drawImage(flash ? S.wc : S.c, Math.round(x - S.w / 2), Math.round(y - S.h));
    if (alpha !== undefined && alpha < 1) ctx.globalAlpha = 1;
  }
  function shadow(x, y, w) {
    x = Math.round(x); y = Math.round(y); ctx.fillStyle = 'rgba(0,0,0,.30)';
    ctx.fillRect(x - w / 2 + 2, y - 1, w - 4, 1); ctx.fillRect(x - w / 2, y, w, 2); ctx.fillRect(x - w / 2 + 2, y + 2, w - 4, 1);
  }
  function hpBar(x, y, w, frac, col) {
    x = Math.round(x - w / 2); y = Math.round(y); ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, w + 2, 4); ctx.fillStyle = '#3a1218'; ctx.fillRect(x, y, w, 2); ctx.fillStyle = col; ctx.fillRect(x, y, Math.max(1, Math.round(w * clamp(frac, 0, 1))), 2);
  }
  function flame(x, y, sc, t, seed) {
    const cols = ['#d63a12', '#ff7a1a', '#ffc23a', '#fff1a8'];
    for (let l = 0; l < 4; l++) {
      const h = Math.round((13 - l * 2.6) * sc * (0.85 + 0.15 * Math.sin(t * 17 + l * 1.7 + seed))), w = (9 - l * 2) * sc;
      ctx.fillStyle = cols[l];
      for (let i = 0; i < h; i++) {
        const k = i / h, rw = Math.max(1, Math.round(w * (1 - k * k) * (0.72 + 0.28 * Math.sin(t * 12 + i * 0.4 + seed)))), sway = Math.round(Math.sin(t * 8 + i * 0.35 + seed) * 1.4 * k * sc);
        ctx.fillRect(Math.round(x - rw / 2 + sway), Math.round(y - i - 1 - l * 0.5), rw, 1);
      }
    }
  }
  function line(x0, y0, x1, y1, col, th) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); ctx.fillStyle = col;
    for (let i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + (x1 - x0) * i / n), Math.round(y0 + (y1 - y0) * i / n), th || 1, th || 1);
  }

  const dl = [];
  function render() {
    const r = run || scene; ctx.imageSmoothingEnabled = false;
    if (!r) { ctx.fillStyle = '#05070f'; ctx.fillRect(0, 0, W, H); return; }
    const t = (r.time = r.time || 0);
    if (!run) { r.time += 1 / 60; }
    // камера
    if (run) {
      const p = r.player, k = 0.12;
      cam.x += (clamp(p.x - W / 2, 0, WW - W) - cam.x) * k; cam.y += (clamp(p.y - 6 - H / 2, 0, WH - H) - cam.y) * k;
    } else { cam.x = CX - W * 0.7; cam.y = CY - H * 0.62; }
    let shx = 0, shy = 0; if (r.shake > 0) { shx = (Math.random() - 0.5) * r.shake; shy = (Math.random() - 0.5) * r.shake; }
    const cx = Math.round(cam.x + shx), cy = Math.round(cam.y + shy);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#080c18'; ctx.fillRect(0, 0, W, H);
    // земля
    ctx.save(); ctx.translate(-cx, -cy); ctx.fillStyle = groundPat;
    const gx0 = Math.max(0, cx), gy0 = Math.max(0, cy), gx1 = Math.min(WW, cx + W), gy1 = Math.min(WH, cy + H);
    if (gx1 > gx0 && gy1 > gy0) ctx.fillRect(gx0, gy0, gx1 - gx0, gy1 - gy0);
    ctx.drawImage(SPR.dirt, CX - 60, CY - 36 + 4);
    ctx.restore();
    // отсортированный список
    dl.length = 0;
    const vx0 = cx - 30, vx1 = cx + W + 30, vy0 = cy - 20, vy1 = cy + H + 70;
    borderTrees.forEach(b => { if (b.x > vx0 && b.x < vx1 && b.y > vy0 - 20 && b.y < vy1 + 40) dl.push({ y: b.y, k: 5, o: b }); });
    r.nodes.forEach(n => { if (n.x > vx0 && n.x < vx1 && n.y > vy0 && n.y < vy1) dl.push({ y: n.y, k: 0, o: n }); });
    r.structs.forEach(s => { if (s.x > vx0 && s.x < vx1 && s.y > vy0 && s.y < vy1) dl.push({ y: s.y, k: 1, o: s }); });
    r.enemies.forEach(e => { if (e.x > vx0 && e.x < vx1 && e.y > vy0 && e.y < vy1) dl.push({ y: e.y, k: 2, o: e }); });
    dl.push({ y: r.player.y, k: 3, o: r.player }); dl.push({ y: r.fire.y, k: 4, o: r.fire });
    dl.sort((a, b) => a.y - b.y);
    for (let i = 0; i < dl.length; i++) {
      const it = dl[i], o = it.o, sx = o.x - cx, sy = o.y - cy;
      switch (it.k) {
        case 5: spr(SPR.tree[o.v], sx, sy, false); break;
        case 0: {
          const shk = o.shake > 0 ? Math.round(Math.sin(o.shake * 90) * 1.4) : 0;
          if (o.type === 'tree') { shadow(sx, sy, 16); spr(SPR.tree[o.v], sx + shk, sy, false); }
          else if (o.type === 'rock') { shadow(sx, sy, 16); spr(SPR.rock[o.v], sx + shk, sy, false); }
          else { shadow(sx, sy, 14); spr(SPR.crystal[0], sx + shk, sy, false); }
          if (o.hp < o.maxHp) hpBar(sx, sy + 2, 12, o.hp / o.maxHp, '#ffd166');
          break;
        }
        case 1: drawStruct(o, sx, sy, r.time); break;
        case 2: drawEnemy(o, sx, sy); break;
        case 3: drawPlayer(r, o, sx, sy); break;
        case 4: drawFire(r, o, sx, sy, r.time); break;
      }
    }
    // снаряды и эффекты
    ctx.globalCompositeOperation = 'lighter';
    r.projs.forEach(q => {
      const x = Math.round(q.x - cx), y = Math.round(q.y - cy); ctx.fillStyle = q.col;
      ctx.globalAlpha = 0.35; ctx.fillRect(Math.round(x - q.vx * 0.03) - 1, Math.round(y - q.vy * 0.03) - 1, 3, 3); ctx.fillRect(Math.round(x - q.vx * 0.06) - 1, Math.round(y - q.vy * 0.06), 2, 2);
      ctx.globalAlpha = 1; ctx.fillRect(x - 1, y - 1, 3, 3); ctx.fillStyle = '#fff'; ctx.fillRect(x, y, 1, 1);
    });
    r.eprojs.forEach(q => { const x = Math.round(q.x - cx), y = Math.round(q.y - cy); ctx.fillStyle = '#b36bff'; ctx.fillRect(x - 2, y - 2, 4, 4); ctx.fillStyle = '#fff'; ctx.fillRect(x - 1, y - 1, 2, 2); });
    ctx.globalAlpha = 1;
    r.bolts.forEach(b => { for (let i = 0; i < b.pts.length - 1; i++) { line(b.pts[i][0] - cx, b.pts[i][1] - cy, b.pts[i + 1][0] - cx, b.pts[i + 1][1] - cy, '#7fd4ff', 2); line(b.pts[i][0] - cx, b.pts[i][1] - cy, b.pts[i + 1][0] - cx, b.pts[i + 1][1] - cy, '#fff', 1); } });
    r.rings.forEach(g => { ctx.globalAlpha = clamp(g.life / 0.45, 0, 1); ctx.fillStyle = '#ffb23a'; const n = Math.max(24, Math.round(g.r * 1.2)); for (let i = 0; i < n; i++) { const a = i / n * TAU; ctx.fillRect(Math.round(g.x - cx + Math.cos(a) * g.r), Math.round(g.y - cy + Math.sin(a) * g.r * 0.8), 2, 2); } ctx.globalAlpha = 1; });
    // огни-спутники
    if (run && r.up.orbit) { const n = r.up.orbit + 1, p = r.player; for (let k = 0; k < n; k++) { const a = r.orbA + k * TAU / n, ox = Math.round(p.x - cx + Math.cos(a) * 27), oy = Math.round(p.y - 7 - cy + Math.sin(a) * 21.6); ctx.fillStyle = '#ff8a2a'; ctx.fillRect(ox - 2, oy - 2, 5, 5); ctx.fillStyle = '#ffe08a'; ctx.fillRect(ox - 1, oy - 1, 3, 3); ctx.fillStyle = '#fff'; ctx.fillRect(ox, oy, 1, 1); } }
    // частицы
    r.parts.forEach(p => { ctx.globalCompositeOperation = p.add ? 'lighter' : 'source-over'; ctx.globalAlpha = clamp(p.life / p.max * 1.4, 0, 1); ctx.fillStyle = p.col; ctx.fillRect(Math.round(p.x - cx), Math.round(p.y - cy), p.size, p.size); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // светлячки
    ctx.globalCompositeOperation = 'lighter';
    r.flies.forEach(fl => { const x = fl.x - cx, y = fl.y - cy; if (x < -4 || x > W + 4 || y < -4 || y > H + 4) return; const a = 0.4 + 0.6 * Math.abs(Math.sin(fl.ph * 2)); ctx.globalAlpha = a; ctx.fillStyle = '#d6ff7a'; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); ctx.globalAlpha = a * 0.3; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // освещение
    const dk = darkness(r); r.dark = dk;
    const LS = [];
    const fl = 0.92 + 0.06 * Math.sin(r.time * 13) + 0.04 * Math.sin(r.time * 31.7);
    LS.push([r.fire.x, r.fire.y - 6, (95 + r.fire.level * 15) * fl, 1, 'w']);
    LS.push([r.player.x, r.player.y - 8, 44, 0.9, 'w']);
    r.structs.forEach(s => { if (s.type === 'torch') LS.push([s.x, s.y - 14, 66 * (0.93 + 0.07 * Math.sin(r.time * 14 + s.x)), 1, 'w']); else if (s.type === 'turret') LS.push([s.x, s.y - 14, 30, 0.8, 'c']); });
    r.nodes.forEach(n => { if (n.type === 'crystal' && n.x > vx0 && n.x < vx1 && n.y > vy0 && n.y < vy1) LS.push([n.x, n.y - 10, 26, 0.8, 'c']); });
    r.projs.forEach(q => LS.push([q.x, q.y, 15, 0.8, q.own === 't' ? 'c' : 'w']));
    r.enemies.forEach(e => { if (e.type === 'boss') LS.push([e.x, e.y - 20, 55, 0.7, 'p']); else if (e.type === 'ghost') LS.push([e.x, e.y - 8, 20, 0.5, 'c']); });
    if (run && r.up.orbit) { const n = r.up.orbit + 1, p = r.player; for (let k = 0; k < n; k++) { const a = r.orbA + k * TAU / n; LS.push([p.x + Math.cos(a) * 27, p.y - 7 + Math.sin(a) * 21.6, 20, 0.7, 'w']); } }
    r.bolts.forEach(b => b.pts.forEach(p => LS.push([p[0], p[1], 28, 0.7, 'c'])));
    r.rings.forEach(g => LS.push([g.x, g.y, g.r + 20, 0.5, 'w']));
    if (dk > 0.01) {
      const col = dk < 0.5 ? mix([255, 130, 70], [60, 40, 95], dk * 2) : mix([60, 40, 95], [7, 10, 40], (dk - 0.5) * 2), al = 0.86 * Math.pow(dk, 0.9);
      lctx.globalCompositeOperation = 'source-over'; lctx.globalAlpha = 1; lctx.clearRect(0, 0, W, H);
      lctx.fillStyle = 'rgba(' + col + ',' + al + ')'; lctx.fillRect(0, 0, W, H);
      lctx.globalCompositeOperation = 'destination-out';
      LS.forEach(l => { const rr = l[2], x = l[0] - cx, y = l[1] - cy; if (x + rr < 0 || x - rr > W || y + rr < 0 || y - rr > H) return; lctx.globalAlpha = l[3]; lctx.drawImage(SPR.cut, x - rr, y - rr, rr * 2, rr * 2); });
      lctx.globalAlpha = 1; lctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(lc, 0, 0);
    }
    // тёплое свечение
    ctx.globalCompositeOperation = 'lighter'; const ga = 0.25 + 0.75 * dk;
    LS.forEach(l => { const rr = l[2] * 1.05, x = l[0] - cx, y = l[1] - cy; if (x + rr < 0 || x - rr > W || y + rr < 0 || y - rr > H) return; ctx.globalAlpha = l[3] * ga * 0.85; ctx.drawImage(l[4] === 'w' ? SPR.warm : l[4] === 'c' ? SPR.cool : SPR.purple, x - rr, y - rr, rr * 2, rr * 2); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // виньетка
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.55, W / 2, H / 2, H * 1.05); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    // стрелка к костру
    if (run && !r.over) {
      const fx = r.fire.x - cx, fy = r.fire.y - cy;
      if (fx < 8 || fx > W - 8 || fy < 8 || fy > H - 8) {
        const a = Math.atan2(fy - H / 2, fx - W / 2), ex = clamp(W / 2 + Math.cos(a) * W, 14, W - 14), ey = clamp(H / 2 + Math.sin(a) * H, 40, H - 40);
        ctx.fillStyle = '#000'; ctx.fillRect(Math.round(ex) - 5, Math.round(ey) - 5, 11, 11); ctx.fillStyle = '#ffb23a'; ctx.fillRect(Math.round(ex) - 4, Math.round(ey) - 4, 9, 9); ctx.fillStyle = '#ff6a1a'; ctx.fillRect(Math.round(ex) - 2, Math.round(ey) - 2, 5, 5);
        for (let i = 1; i <= 3; i++) { ctx.fillStyle = '#fff'; ctx.fillRect(Math.round(ex + Math.cos(a) * (5 + i * 2)) - 1, Math.round(ey + Math.sin(a) * (5 + i * 2)) - 1, 2, 2); }
      }
    }
  }
  function mix(a, b, t) { return Math.round(a[0] + (b[0] - a[0]) * t) + ',' + Math.round(a[1] + (b[1] - a[1]) * t) + ',' + Math.round(a[2] + (b[2] - a[2]) * t); }

  function drawFire(r, f, x, y, t) {
    shadow(x, y + 1, 24);
    spr(SPR.logs[0], x, y + 6, f.flash > 0);
    flame(x, y + 1, 0.8 + f.level * 0.2, t, 0);
    if (f.level >= 3) { flame(x - 6, y + 2, 0.5, t, 2); flame(x + 6, y + 2, 0.5, t, 4); }
  }
  function drawStruct(s, x, y, t) {
    shadow(x, y, 15);
    if (s.type === 'wall') spr(SPR.wall[0], x, y + 1, s.flash > 0);
    else if (s.type === 'turret') {
      spr(SPR.turret[0], x, y + 1, s.flash > 0);
      const a = s.aim, bx = x, by = y - 12; ctx.fillStyle = '#d8f6ff';
      for (let k = 1; k <= 3; k++) ctx.fillRect(Math.round(bx + Math.cos(a) * k * 2.2) - 1, Math.round(by + Math.sin(a) * k * 2.2) - 1, 2, 2);
      if (s.muz > 0) { ctx.fillStyle = '#fff'; ctx.fillRect(Math.round(bx + Math.cos(a) * 9) - 1, Math.round(by + Math.sin(a) * 9) - 1, 3, 3); }
    } else if (s.type === 'torch') { spr(SPR.torch[0], x, y + 1, s.flash > 0); flame(x, y - 16, 0.55, t, s.x); }
    if (s.hp < s.max) hpBar(x, y + 3, 12, s.hp / s.max, '#7dff8f');
  }
  function drawEnemy(e, x, y) {
    const fr = Math.floor(e.anim * 5) % 2, fl = e.hit > 0;
    if (e.type === 'bat') { const oy = 9 + Math.sin(e.anim * 6 + e.ph) * 2; shadow(x, y, 8); spr(SPR.bat[Math.floor(e.anim * 12) % 2], x, y - oy + 8, fl); }
    else if (e.type === 'ghost') { const oy = 4 + Math.sin(e.anim * 3 + e.ph) * 2; shadow(x, y, 9); spr(SPR.ghost[fr], x, y - oy + 6, fl, 0.82); }
    else if (e.type === 'slime') { shadow(x, y, 12); spr(SPR.slime[fr], x, y + 1, fl); }
    else if (e.type === 'ghoul') { shadow(x, y, 12); spr(SPR.ghoul[fr], x, y + 1 - (fr ? 1 : 0), fl); }
    else if (e.type === 'brute') { shadow(x, y, 22); spr(SPR.brute[fr], x, y + 2 - (fr ? 1 : 0), fl); }
    else if (e.type === 'boss') {
      shadow(x, y, 38); const rage = e.hp < e.maxHp * 0.5; spr(SPR.boss[fr], x, y + 3 - (fr ? 2 : 0), fl);
      const hy = Math.round(y - 47 - (fr ? 2 : 0)); ctx.fillStyle = '#ffd447'; ctx.fillRect(Math.round(x) - 8, hy, 16, 3); for (let i = 0; i < 4; i++) ctx.fillRect(Math.round(x) - 8 + i * 5, hy - 3, 3, 3);
      if (rage) { ctx.fillStyle = '#ff3b3b'; ctx.fillRect(Math.round(x) - 7, Math.round(y - 33), 4, 3); ctx.fillRect(Math.round(x) + 3, Math.round(y - 33), 4, 3); }
    }
    if (e.hp < e.maxHp && e.type !== 'boss') hpBar(x, y - (e.type === 'brute' ? 34 : e.type === 'bat' ? 20 : e.type === 'ghost' ? 22 : 20), e.type === 'brute' ? 20 : 12, e.hp / e.maxHp, '#ff5a5f');
  }
  function drawPlayer(r, p, x, y) {
    shadow(x, y, 12);
    const S = SPR.hero[r.heroId], fr = p.moving ? Math.floor(p.anim * 9) % 2 : 0, bob = p.moving ? (fr ? 1 : 0) : (Math.sin(r.time * 3) > 0.7 ? 1 : 0);
    if (p.inv > 0 && Math.floor(p.inv * 20) % 2 === 0 && !r.over) return;
    if (r.over) { ctx.globalAlpha = 0.5; }
    spr(S[fr], x, y + 1 - bob, false); ctx.globalAlpha = 1;
    if (p.swing > 0) { const a = Math.atan2(p.fy, p.fx) + (p.swing / 0.18 - 0.5) * 2; ctx.fillStyle = '#fff6c8'; for (let k = 1; k <= 3; k++) ctx.fillRect(Math.round(x + Math.cos(a) * (6 + k * 2)) - 1, Math.round(y - 8 + Math.sin(a) * (6 + k * 2)) - 1, 2, 2); }
  }

  // ================= ввод =================
  const stage = $('#stage'), joy = $('#joy'), knob = joy.querySelector('i');
  let jid = null, jx = 0, jy = 0;
  function remPx() { return parseFloat(getComputedStyle(document.documentElement).fontSize) || 14; }
  stage.addEventListener('pointerdown', e => {
    if (state !== 'play' || modalOpen || paused || jid !== null) return;
    e.preventDefault(); try { stage.setPointerCapture(e.pointerId); } catch (_) { }
    jid = e.pointerId; jx = e.clientX; jy = e.clientY; joy.style.display = 'block'; joy.style.left = jx + 'px'; joy.style.top = jy + 'px'; knob.style.transform = 'translate(0,0)';
  });
  stage.addEventListener('pointermove', e => {
    if (e.pointerId !== jid) return;
    let dx = e.clientX - jx, dy = e.clientY - jy; const R = remPx() * 2.6, m = Math.hypot(dx, dy);
    if (m > R) { dx = dx / m * R; dy = dy / m * R; }
    input.x = dx / R; input.y = dy / R; knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    if (m > R * 1.6) { jx += (e.clientX - jx) * 0.25; jy += (e.clientY - jy) * 0.25; joy.style.left = jx + 'px'; joy.style.top = jy + 'px'; }
  });
  function endJoy(e) { if (e.pointerId !== jid) return; jid = null; input.x = 0; input.y = 0; joy.style.display = 'none'; }
  stage.addEventListener('pointerup', endJoy); stage.addEventListener('pointercancel', endJoy);
  const keys = {};
  function keyUpd() { input.kx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0); input.ky = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0); }
  window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase(); keys[k] = true; keyUpd(); Snd.init();
    if (state === 'play' && run && !run.over) {
      if (k === 'p' || k === 'escape') { modalOpen ? null : showPause(); }
      if (k === '1') doBuild('wall'); if (k === '2') doBuild('turret'); if (k === '3') doBuild('torch'); if (k === '4') doBuild('repair'); if (k === '5') doBuild('fire');
      if (k === 'n' && run.phase === 'day') run.t = run.dayLen;
    }
  });
  window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; keyUpd(); });
  window.addEventListener('contextmenu', e => e.preventDefault());

  // ================= кнопки меню =================
  function firstGesture() { Snd.setOn(save.sound); Snd.init(); }
  window.addEventListener('pointerdown', firstGesture, { passive: true });
  $('#splash').addEventListener('pointerdown', () => { if (state !== 'splash') return; if ($('#splash').dataset.t < 1) return; firstGesture(); showMenu(); });
  $('#splash').dataset.t = 0; setTimeout(() => { $('#splash').dataset.t = 1; }, 1800);
  $('#bPlay').onclick = () => { firstGesture(); Snd.sfx('click'); startRun(); };
  $('#bHeroes').onclick = () => { Snd.sfx('click'); showHeroes(); };
  $('#bAbout').onclick = () => { Snd.sfx('click'); showAbout(); };
  $('#bSound').onclick = () => { save.sound = !save.sound; Snd.setOn(save.sound); persist(); $('#bSound').textContent = 'Звук: ' + (save.sound ? 'вкл' : 'выкл'); Snd.sfx('click'); };

  // ================= главный цикл =================
  let last = performance.now();
  function frame(now) {
    let dt = (now - last) / 1000; last = now; if (dt > 0.05) dt = 0.05; if (dt < 0) dt = 0;
    try {
      if (state === 'play' && run && !paused && !modalOpen) update(dt);
      else if (state === 'play' && run && (paused || modalOpen)) { /* заморозка */ }
      else if (scene) { scene.time += dt; updateAmbient(scene, dt); }
      if (state === 'splash') { /* фон не нужен */ } else render();
    } catch (err) { console.error(err); }
    requestAnimationFrame(frame);
  }
  scene = newRun(); run = null; scene.dkOverride = 0.78; scene.player.x = CX + 30; scene.player.y = CY + 30;
  requestAnimationFrame(frame);

  // отладочные хуки (для проверки)
  window.__dbg = {
    run: () => run, scene: () => scene, step: dt => { if (run) update(dt); }, render: render, state: () => state,
    startNight: () => { if (run) { run.t = run.dayLen; } }, giveRes: n => { if (run) { run.res.wood += n; run.res.stone += n; run.res.crystal += n; updateHud(); } },
    build: doBuild, save: save, endNight: () => { if (run && run.phase === 'night') { run.t = run.nightLen; } }, setNight: n => { if (run) run.night = n; }
  };
})();
