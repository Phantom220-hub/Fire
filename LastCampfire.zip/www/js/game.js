'use strict';
/* ПОСЛЕДНИЙ КОСТЁР — © Nyxvault. Главный разработчик: Анас Акрамзод. */
(function () {
  const WW = 2400, WH = 1560, CX = 1200, CY = 780;
  const $ = s => document.querySelector(s);
  const clamp = (v, a, b) => v < a ? a : v > b ? b : v;
  const rand = (a, b) => a + Math.random() * (b - a);
  const rint = (a, b) => Math.floor(rand(a, b + 1));
  const pick = a => a[Math.floor(Math.random() * a.length)];
  const d2 = (a, b, c, d) => (a - c) * (a - c) + (b - d) * (b - d);
  const TAU = Math.PI * 2;

  // ================= сохранение =================
  const SAVE_KEY = 'nyxvault_last_campfire_v1';
  const SLOTS = 4;
  const save = { coins: 0, best: 0, kills: 0, hero: 'hunter', owned: { hunter: true }, sound: true };
  try { const s = JSON.parse(localStorage.getItem(SAVE_KEY)); if (s) Object.assign(save, s); } catch (e) { }
  function persist() { try { localStorage.setItem(SAVE_KEY, JSON.stringify(save)); } catch (e) { } }
  const slotKey = i => 'nyxvault_lc_slot_' + i;
  function readSlot(i) { try { const s = localStorage.getItem(slotKey(i)); if (!s) return null; const o = JSON.parse(s); return (o && o.v === 2 && o.meta) ? o : null; } catch (e) { return null; } }
  function writeSlot(i, o) { try { localStorage.setItem(slotKey(i), JSON.stringify(o)); return true; } catch (e) { return false; } }
  function delSlot(i) { try { localStorage.removeItem(slotKey(i)); } catch (e) { } }

  // ================= данные =================
  const HEROES = {
    hunter: { name: 'Охотник', desc: 'Меткий стрелок. Быстро стреляет, хорошо растёт с двойными зарядами.', price: 0, hp: 100, speed: 68, start: {}, bolt: '#ffb347' },
    mage: { name: 'Маг бури', desc: 'Начинает с грозовым посохом: молния бьёт по цепочке врагов. Хрупкий.', price: 60, hp: 80, speed: 66, start: { lightning: 1 }, bolt: '#c58bff' },
    robot: { name: 'Страж-6', desc: 'Стальной боец. Много здоровья, вокруг него кружатся огни.', price: 120, hp: 150, speed: 60, start: { orbit: 1 }, bolt: '#55f0ff' }
  };
  const UPG = [
    { id: 'multi', em: '✦', name: 'Двойной заряд', max: 4, desc: 'Ещё один снаряд за выстрел' },
    { id: 'dmg', em: '🔥', name: 'Сила огня', max: 6, desc: '+30% к урону героя' },
    { id: 'rate', em: '⚡', name: 'Быстрые руки', max: 6, desc: 'Стреляешь на 15% чаще' },
    { id: 'pierce', em: '🏹', name: 'Пронзающий', max: 3, desc: 'Снаряды пробивают +1 врага' },
    { id: 'lightning', em: '🌩️', name: 'Грозовой посох', max: 5, desc: 'Молния бьёт цепочкой врагов' },
    { id: 'orbit', em: '🌀', name: 'Кружащиеся огни', max: 5, desc: 'Огни крутятся вокруг тебя и жгут' },
    { id: 'nova', em: '💥', name: 'Огненное кольцо', max: 5, desc: 'Взрыв вокруг героя каждые секунды' },
    { id: 'speed', em: '👟', name: 'Лёгкие ноги', max: 4, desc: '+12% к скорости бега' },
    { id: 'vit', em: '❤️', name: 'Крепкое тело', max: 5, desc: '+30 здоровья и лечение' },
    { id: 'life', em: '🩸', name: 'Жажда жизни', max: 4, desc: 'Шанс вылечиться при убийстве' },
    { id: 'luck', em: '🍀', name: 'Золотые руки', max: 3, desc: '+35% добычи ресурсов' },
    { id: 'firehp', em: '🛡️', name: 'Щит костра', max: 3, desc: '+60 прочности костра и лечение' },
    { id: 'wall', em: '🧱', name: 'Мастер стен', max: 3, desc: 'Постройки на 50% прочнее' },
    { id: 'tur', em: '🗼', name: 'Умная артиллерия', max: 4, desc: 'Турели, баллисты, мортиры бьют сильнее' }
  ];
  const ET = {
    slime: { hp: 12, spd: 24, dmg: 5, r: 5, w: 6, from: 1, coin: 1, col: '#63d36f' },
    bat: { hp: 7, spd: 50, dmg: 4, r: 4, w: 3, from: 2, coin: 1, col: '#9a6bd8' },
    ghoul: { hp: 32, spd: 30, dmg: 9, r: 6, w: 4, from: 3, coin: 2, col: '#dcd5bb' },
    ghost: { hp: 20, spd: 34, dmg: 7, r: 5, w: 3, from: 5, coin: 2, col: '#9ff3e6' },
    brute: { hp: 120, spd: 19, dmg: 20, r: 10, w: 2, from: 7, coin: 5, col: '#e0734a' },
    boss: { hp: 450, spd: 15, dmg: 26, r: 16, w: 0, from: 99, coin: 40, col: '#c58bff' }
  };
  // постройки
  const SD = {
    wall: { name: 'Деревянная стена', short: 'Дерево', cost: { wood: 4 }, hp: 60, r: 7, spr: 'wall', icon: 'wall' },
    stone: { name: 'Каменная стена', short: 'Камень', cost: { wood: 2, stone: 5 }, hp: 150, r: 7, spr: 'stonewall', icon: 'stonewall' },
    spike: { name: 'Шипастая стена', short: 'Шипы', cost: { wood: 4, stone: 4, crystal: 1 }, hp: 100, r: 7, spr: 'spikewall', icon: 'spikewall', thorns: 6 },
    cwall: { name: 'Кристальная стена', short: 'Кристалл', cost: { stone: 6, crystal: 3 }, hp: 260, r: 7, spr: 'cwall', icon: 'cwall', regen: 2 },
    turret: { name: 'Турель', short: 'Турель', cost: { wood: 8, stone: 6 }, hp: 55, r: 7, spr: 'turret', icon: 'turret' },
    ballista: { name: 'Баллиста', short: 'Баллиста', cost: { wood: 12, stone: 8, crystal: 2 }, hp: 70, r: 8, spr: 'ballista', icon: 'ballista' },
    mortar: { name: 'Мортира', short: 'Мортира', cost: { wood: 10, stone: 14, crystal: 3 }, hp: 80, r: 8, spr: 'mortar', icon: 'mortar' },
    flamer: { name: 'Огнемёт', short: 'Огнемёт', cost: { wood: 8, stone: 6, crystal: 2 }, hp: 65, r: 7, spr: 'flamer', icon: 'flamer' },
    torch: { name: 'Факел', short: 'Факел', cost: { wood: 3, crystal: 1 }, hp: 35, r: 4, spr: 'torch', icon: 'torch' },
    tower: { name: 'Кристальная башня', short: 'Башня', cost: { wood: 6, stone: 8, crystal: 4 }, hp: 90, r: 7, spr: 'tower', icon: 'tower' }
  };
  const CATS = {
    walls: ['wall', 'stone', 'spike', 'cwall'],
    guns: ['turret', 'ballista', 'mortar', 'flamer'],
    light: ['torch', 'tower']
  };
  function fireCost() { const L = run ? run.fire.level : 1; return L >= 6 ? null : { wood: 10 * L, stone: 6 * L, crystal: L >= 3 ? L - 2 : 0 }; }
  const BAR = [
    { id: 'cat:walls', name: 'Стены', icon: 'wall' },
    { id: 'cat:guns', name: 'Оружие', icon: 'turret' },
    { id: 'cat:light', name: 'Свет', icon: 'torch' },
    { id: 'repair', name: 'Чинить', icon: 'hammer', ico: 1, cost: () => ({ wood: 6 }) },
    { id: 'fire', name: 'Костёр+', icon: 'flame', ico: 1, cost: fireCost }
  ];
  const BIOMES = [
    { id: 'stony', x: CX + 720, y: CY - 330, r: 330, tile: 'groundStony', col: '#8a8578' },
    { id: 'crystal', x: CX - 760, y: CY + 300, r: 320, tile: 'groundCrystal', col: '#5a4fa8' },
    { id: 'swamp', x: CX + 260, y: CY + 620, r: 310, tile: 'groundSwamp', col: '#2f6a5a' }
  ];
  const RUIN_POS = [[-820, -380], [830, -450], [-700, 520], [780, 420], [50, -620], [-150, 640]];

  // ================= холст =================
  const cv = $('#cv'), ctx = cv.getContext('2d', { alpha: false });
  const lc = document.createElement('canvas'), lctx = lc.getContext('2d');
  let W = 480, H = 270, SC = 2;
  function resize() {
    const dpr = window.devicePixelRatio || 1;
    const k = Math.max(2, Math.round(window.innerHeight * dpr / 270));
    SC = k / dpr;
    W = clamp(Math.ceil(window.innerWidth / SC), 320, 760); H = Math.ceil(window.innerHeight / SC);
    cv.width = W; cv.height = H; lc.width = W; lc.height = H;
    cv.style.width = (W * SC) + 'px'; cv.style.height = (H * SC) + 'px';
  }
  window.addEventListener('resize', resize); resize();

  // ================= состояние =================
  let state = 'splash'; // splash | menu | play
  let run = null, scene = null;
  let paused = false, modalOpen = false;
  const cam = { x: 0, y: 0 };
  const input = { x: 0, y: 0, kx: 0, ky: 0 };
  let hudT = 0, miniT = 0;

  function stats() {
    const u = run.up, hd = run.hd;
    return {
      dmg: 6 * (1 + 0.3 * (u.dmg || 0)), cd: 0.55 * Math.pow(0.85, u.rate || 0), shots: 1 + (u.multi || 0), pierce: u.pierce || 0,
      speed: hd.speed * (1 + 0.12 * (u.speed || 0)), maxHp: hd.hp + 30 * (u.vit || 0), harvest: 1 + 0.35 * (u.luck || 0),
      tur: 1 + 0.3 * (u.tur || 0), wallMul: 1 + 0.5 * (u.wall || 0), range: 150
    };
  }

  function newRun(heroId, noWorld) {
    const hd = HEROES[heroId] || HEROES.hunter;
    const r = {
      slot: null, heroId: HEROES[heroId] ? heroId : 'hunter', hd: hd, night: 1, phase: 'day', t: 0, dayLen: 60, nightLen: 52, time: 0,
      player: { kind: 'p', x: CX - 34, y: CY + 34, r: 5, hp: hd.hp, maxHp: hd.hp, face: 0.6, anim: 0, inv: 0, cd: 0.3, ht: 0, lt: 2, nt: 3, swing: 0, moving: false, fx: 1, fy: 0 },
      fire: { kind: 'f', x: CX, y: CY + 2, r: 11, hp: 100, maxHp: 100, level: 1, flash: 0, aura: 0.5 },
      res: { wood: 0, stone: 0, crystal: 0 }, nodes: [], structs: [], enemies: [], projs: [], eprojs: [], shells: [], parts: [], bolts: [], rings: [], flies: [], ruins: [],
      up: Object.assign({}, hd.start), kills: 0, coins: 0, paid: 0, bosses: 0, spawnAcc: 0, shake: 0, burstT: 16, orbA: 0, bossRef: null,
      over: false, overT: 0, st: null, dark: 0, dkOverride: null, embT: 0, why: '', pending: 0, saveT: 5, pop: null, sel: null
    };
    for (let i = 0; i < 90; i++) r.flies.push({ x: rand(40, WW - 40), y: rand(40, WH - 40), ph: rand(0, 6), sp: rand(0.4, 1) });
    RUIN_POS.forEach(p => r.ruins.push({ x: CX + p[0], y: CY + p[1], opened: false, cd: 0, prog: 0 }));
    run = r; r.st = stats();
    if (!noWorld) regrow(r, true);
    return r;
  }

  // ================= мир: биомы и ресурсы =================
  function makeBlob(b, seed) {
    const S = Math.ceil(b.r * 2.1), c = document.createElement('canvas'); c.width = S; c.height = S;
    const x = c.getContext('2d'); x.fillStyle = x.createPattern(SPR[b.tile], 'repeat'); x.fillRect(0, 0, S, S);
    const id = x.getImageData(0, 0, S, S), d = id.data, h = S / 2, ph1 = seed * 1.7, ph2 = seed * 0.9, band = b.r * 0.09;
    for (let j = 0; j < S; j++) for (let i = 0; i < S; i++) {
      const dx = i - h, dy = j - h, dist = Math.sqrt(dx * dx + dy * dy), a = Math.atan2(dy, dx);
      const R = b.r * (0.84 + 0.1 * Math.sin(3 * a + ph1) + 0.05 * Math.sin(7 * a + ph2)), t = (dist - (R - band)) / band;
      d[(j * S + i) * 4 + 3] = t <= 0 ? 255 : t < 1 ? (Math.random() > t ? 255 : 0) : 0;
    }
    x.putImageData(id, 0, 0); return c;
  }
  const blobs = BIOMES.map((b, i) => makeBlob(b, i + 1));
  function inBiome(b, x, y) { return d2(x, y, b.x, b.y) < (b.r * 0.78) * (b.r * 0.78); }

  function samplePos(type) {
    const R = Math.random(); let b = null;
    if (type === 'rock' && R < 0.6) b = BIOMES[0]; else if (type === 'crystal' && R < 0.75) b = BIOMES[1]; else if (type === 'tree' && R < 0.16) b = BIOMES[2];
    if (b) { const a = rand(0, TAU), m = Math.sqrt(Math.random()) * 0.78; return [b.x + Math.cos(a) * b.r * m, b.y + Math.sin(a) * b.r * m]; }
    if (Math.random() < 0.45) { const a = rand(0, TAU), m = Math.sqrt(Math.random()); return [CX + Math.cos(a) * 470 * m, CY + Math.sin(a) * 310 * m]; }
    return [rand(50, WW - 50), rand(60, WH - 40)];
  }
  function regrow(r, first) {
    const want = { tree: 190, rock: 66, crystal: 27 }, have = { tree: 0, rock: 0, crystal: 0 };
    r.nodes.forEach(n => have[n.type]++);
    Object.keys(want).forEach(type => {
      let need = want[type] - have[type], tries = 0;
      if (!first) need = Math.min(need, Math.ceil(want[type] * 0.4));
      while (need > 0 && tries++ < 900) {
        const p = samplePos(type), x = p[0], y = p[1];
        if (x < 40 || x > WW - 40 || y < 50 || y > WH - 30) continue;
        if (d2(x, y, CX, CY) < 70 * 70) continue;
        let ok = true;
        for (let i = 0; i < r.ruins.length; i++) if (d2(x, y, r.ruins[i].x, r.ruins[i].y) < 48 * 48) { ok = false; break; }
        for (let i = 0; ok && i < r.nodes.length; i++) { const n = r.nodes[i]; if (Math.abs(x - n.x) < 20 && Math.abs(y - n.y) < 20 && d2(x, y, n.x, n.y) < 400) ok = false; }
        if (!ok) continue;
        const hp = type === 'tree' ? 4 : type === 'rock' ? 6 : 8;
        let v = type === 'crystal' ? 0 : rint(0, 1); if (type === 'tree' && inBiome(BIOMES[2], x, y)) v = 2; else if (type === 'tree' && Math.random() < 0.12) v = 2;
        r.nodes.push({ kind: 'n', type: type, x: x, y: y, hp: hp, maxHp: hp, shake: 0, v: v, r: 6 });
        need--;
      }
    });
  }

  // ================= частицы =================
  function burst(x, y, col, n, spd, life, size, add) {
    const r = run || scene; if (!r) return;
    for (let i = 0; i < n && r.parts.length < 420; i++) {
      const a = rand(0, TAU), s = rand(0.2, 1) * spd;
      r.parts.push({ x: x, y: y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - spd * 0.2, life: rand(0.5, 1) * life, max: life, col: col, size: size || 1, g: 60, add: !!add });
    }
  }
  function spark(x, y, col, life) {
    const r = run || scene; if (!r || r.parts.length > 420) return;
    r.parts.push({ x: x, y: y, vx: rand(-6, 6), vy: rand(-26, -12), life: life, max: life, col: col, size: 1, g: -4, add: true });
  }

  // ================= HUD / экраны =================
  $('#icHeart').src = SPR.iconURL.heart; $('#icFlame').src = SPR.iconURL.flame;
  $('#icWood').src = SPR.iconURL.wood; $('#icStone').src = SPR.iconURL.stone; $('#icCrystal').src = SPR.iconURL.crystal;
  const elHp = $('#hpFill'), elHpT = $('#hpTxt'), elFire = $('#fireFill'), elFireT = $('#fireTxt');
  const elPh = $('#phaseTxt'), elPhF = $('#phaseFill'), elPhS = $('#phaseSub');
  const cache = {};
  function setT(el, key, v) { if (cache[key] !== v) { cache[key] = v; el.textContent = v; } }
  function hint(t, ms) {
    const h = $('#hint'); h.textContent = t; h.classList.add('on'); clearTimeout(hint.tm);
    hint.tm = setTimeout(() => h.classList.remove('on'), ms || 3200);
  }
  function banner(txt, sub, col) {
    const b = $('#banner'); b.style.color = col || '#fff'; b.innerHTML = txt + (sub ? '<small>' + sub + '</small>' : '');
    b.classList.remove('show'); void b.offsetWidth; b.classList.add('show');
  }
  function fmtT(s) { s = Math.max(0, Math.ceil(s)); return Math.floor(s / 60) + ':' + ('0' + (s % 60)).slice(-2); }
  function fmtPlay(t) { t = Math.floor(t || 0); const h = Math.floor(t / 3600), m = Math.floor(t % 3600 / 60); return h ? h + 'ч ' + m + 'м' : m + ' мин'; }
  function costHtml(c) {
    if (!c) return '<span style="color:#ffd166">МАКС</span>';
    return ['wood', 'stone', 'crystal'].filter(k => c[k] > 0).map(k => '<span><img class="ic" src="' + SPR.iconURL[k] + '">' + c[k] + '</span>').join('') || '<span>—</span>';
  }
  function afford(c) { return !c || (run.res.wood >= (c.wood || 0) && run.res.stone >= (c.stone || 0) && run.res.crystal >= (c.crystal || 0)); }
  function pay(c) { run.res.wood -= c.wood || 0; run.res.stone -= c.stone || 0; run.res.crystal -= c.crystal || 0; }

  // ----- нижняя панель и меню построек -----
  function buildBar() {
    const el = $('#build'); el.innerHTML = '';
    BAR.forEach(b => {
      const d = document.createElement('div'); d.className = 'bb'; d.dataset.id = b.id;
      d.innerHTML = '<img class="main' + (b.ico ? ' ico' : '') + '" src="' + SPR.iconURL[b.icon] + '"><div class="nm">' + b.name + '</div><div class="cs"></div>';
      d.addEventListener('pointerdown', e => {
        e.stopPropagation(); e.preventDefault(); if (!run) return;
        if (b.id.indexOf('cat:') === 0) togglePop(b.id.slice(4)); else { closePop(); doBuild(b.id); }
      });
      el.appendChild(d);
    });
  }
  buildBar();
  function togglePop(cat) {
    if (!run) return; hideSel();
    if (run.pop === cat) { closePop(); return; }
    run.pop = cat; const el = $('#pop');
    el.innerHTML = CATS[cat].map(id => { const d = SD[id]; return '<div class="bb" data-sid="' + id + '"><img class="main" src="' + SPR.iconURL[d.icon] + '"><div class="nm">' + d.short + '</div><div class="cs">' + costHtml(d.cost) + '</div></div>'; }).join('');
    el.classList.add('on'); updPop(); Snd.sfx('click');
  }
  function closePop() { if (run) run.pop = null; $('#pop').classList.remove('on'); }
  function updPop() { if (!run || !run.pop) return; document.querySelectorAll('#pop .bb').forEach(el => el.classList.toggle('no', !afford(SD[el.dataset.sid].cost))); }
  $('#pop').addEventListener('pointerdown', e => {
    e.stopPropagation(); e.preventDefault(); const it = e.target.closest('.bb'); if (it && run) doBuild(it.dataset.sid);
  });

  // ----- выбор постройки / улучшение -----
  function upCost(s) { const b = SD[s.type].cost, m = 0.8 * s.lvl, o = {}; Object.keys(b).forEach(k => { o[k] = Math.max(1, Math.round(b[k] * m)); }); return o; }
  function hideSel() { if (run) run.sel = null; $('#upg').classList.remove('on'); }
  function showSel(s) { closePop(); run.sel = s; renderSel(); Snd.sfx('click'); }
  function renderSel() {
    const s = run && run.sel, el = $('#upg');
    if (!s || s.dead) { el.classList.remove('on'); if (run) run.sel = null; return; }
    const d = SD[s.type], c = s.lvl < 3 ? upCost(s) : null;
    el.innerHTML = '<div><b>' + d.name + ' · ур. ' + s.lvl + '/3</b><br><small id="uHp"></small></div><button class="btn ok" id="uUp">' + (c ? 'Улучшить ' + costHtml(c) : 'Макс. уровень') + '</button><button class="btn bad" id="uDel">Разобрать</button>';
    $('#uUp').onpointerdown = e => { e.stopPropagation(); e.preventDefault(); upgradeStruct(s); };
    $('#uDel').onpointerdown = e => { e.stopPropagation(); e.preventDefault(); dismantle(s); };
    el.classList.add('on'); updSel();
  }
  function updSel() {
    const s = run && run.sel; if (!s) return;
    const h = $('#uHp'); if (h) setT(h, 'uhp', 'Прочность ' + Math.ceil(s.hp) + '/' + Math.round(s.max));
    const u = $('#uUp'); if (u && s.lvl < 3) u.classList.toggle('dim', !afford(upCost(s)));
  }
  function upgradeStruct(s) {
    if (!run || s.dead) return;
    if (s.lvl >= 3) { hint('Уже максимальный уровень'); return; }
    const c = upCost(s); if (!afford(c)) { hint('Не хватает ресурсов'); Snd.sfx('no'); return; }
    pay(c); s.lvl++; s.max = Math.round(s.bmax * (1 + 0.6 * (s.lvl - 1))); s.hp = s.max;
    burst(s.x, s.y - 10, '#ffd166', 16, 70, 0.7, 1, true); Snd.sfx('up'); renderSel(); updateHud(); run.saveT = Math.min(run.saveT, 1);
  }
  function dismantle(s) {
    if (!run || s.dead) return; const b = SD[s.type].cost;
    ['wood', 'stone', 'crystal'].forEach(k => { run.res[k] += Math.floor((b[k] || 0) * 0.5); });
    s.dead = true; run.structs = run.structs.filter(x => x !== s); burst(s.x, s.y - 8, '#c9a05a', 10, 50, 0.5, 1); Snd.sfx('build'); hideSel(); updateHud(); run.saveT = Math.min(run.saveT, 1);
  }

  // ----- мини-карта -----
  const mini = $('#mini'), mctx = mini.getContext('2d');
  function drawMini(r) {
    const sx = mini.width / WW, sy = mini.height / WH; mctx.imageSmoothingEnabled = false;
    mctx.fillStyle = '#2d6a3a'; mctx.fillRect(0, 0, mini.width, mini.height);
    BIOMES.forEach(b => { mctx.fillStyle = b.col; mctx.beginPath(); mctx.arc(b.x * sx, b.y * sy, b.r * 0.9 * sx, 0, TAU); mctx.fill(); });
    r.ruins.forEach(u => { if (!u.opened) { mctx.fillStyle = '#ffd447'; mctx.fillRect(Math.round(u.x * sx) - 1, Math.round(u.y * sy) - 1, 3, 3); } });
    r.structs.forEach(s => { mctx.fillStyle = '#c9a05a'; mctx.fillRect(Math.round(s.x * sx), Math.round(s.y * sy), 1, 1); });
    if (r.phase === 'night') { mctx.fillStyle = '#ff5a5f'; r.enemies.forEach(e => mctx.fillRect(Math.round(e.x * sx), Math.round(e.y * sy), 1, 1)); }
    mctx.fillStyle = '#000'; mctx.fillRect(Math.round(r.fire.x * sx) - 2, Math.round(r.fire.y * sy) - 2, 5, 5); mctx.fillStyle = '#ff9a1a'; mctx.fillRect(Math.round(r.fire.x * sx) - 1, Math.round(r.fire.y * sy) - 1, 3, 3);
    mctx.fillStyle = '#fff'; mctx.fillRect(Math.round(r.player.x * sx) - 1, Math.round(r.player.y * sy) - 1, 3, 3);
    mctx.strokeStyle = 'rgba(255,255,255,.55)'; mctx.lineWidth = 1; mctx.strokeRect(Math.round(cam.x * sx) + .5, Math.round(cam.y * sy) + .5, Math.round(W * sx), Math.round(H * sy));
  }

  function updateHud() {
    const r = run; if (!r) return;
    const p = r.player, f = r.fire;
    elHp.style.transform = 'scaleX(' + clamp(p.hp / p.maxHp, 0, 1) + ')'; setT(elHpT, 'hp', Math.ceil(Math.max(0, p.hp)) + '/' + p.maxHp);
    elFire.style.transform = 'scaleX(' + clamp(f.hp / f.maxHp, 0, 1) + ')'; setT(elFireT, 'fire', Math.ceil(Math.max(0, f.hp)) + '/' + f.maxHp);
    ['wood', 'stone', 'crystal'].forEach(k => {
      const el = $('#c' + k[0].toUpperCase() + k.slice(1)), b = el.querySelector('b');
      if (cache['r' + k] !== r.res[k]) { if (cache['r' + k] !== undefined && r.res[k] > cache['r' + k]) { el.classList.remove('pulse'); void el.offsetWidth; el.classList.add('pulse'); } cache['r' + k] = r.res[k]; b.textContent = r.res[k]; }
    });
    const night = r.phase === 'night';
    document.body.classList.toggle('night', night);
    if (r.phase === 'day') { setT(elPh, 'ph', 'ДЕНЬ ' + r.night); const left = r.dayLen - r.t; elPhF.style.transform = 'scaleX(' + clamp(left / r.dayLen, 0, 1) + ')'; setT(elPhS, 'phs', left < 10 ? 'Скоро ночь! Готовь защиту' : 'Ночь через ' + fmtT(left)); }
    else if (night) { setT(elPh, 'ph', 'НОЧЬ ' + r.night); const left = r.nightLen - r.t; elPhF.style.transform = 'scaleX(' + clamp(left / r.nightLen, 0, 1) + ')'; setT(elPhS, 'phs', r.bossRef && !r.bossRef.dead ? 'Победи Короля Теней!' : 'До рассвета ' + fmtT(left)); }
    else { setT(elPh, 'ph', 'РАССВЕТ'); elPhF.style.transform = 'scaleX(1)'; setT(elPhS, 'phs', 'Выбери улучшение'); }
    const bb = $('#bossBar');
    if (r.bossRef && !r.bossRef.dead) { bb.style.display = 'block'; $('#bossFill').style.transform = 'scaleX(' + clamp(r.bossRef.hp / r.bossRef.maxHp, 0, 1) + ')'; } else bb.style.display = 'none';
    $('#vig').style.opacity = (f.hp / f.maxHp < 0.3 || p.hp / p.maxHp < 0.25) && !r.over ? (0.55 + 0.35 * Math.sin(r.time * 6)) : 0;
    document.querySelectorAll('#build .bb').forEach(el => {
      const b = BAR.find(x => x.id === el.dataset.id), key = 'b' + b.id;
      if (b.cost) {
        const c = b.cost(), html = costHtml(c); if (cache[key] !== html) { cache[key] = html; el.querySelector('.cs').innerHTML = html; }
        el.classList.toggle('no', !c || !afford(c));
      } else { if (!cache[key]) { cache[key] = 1; el.querySelector('.cs').innerHTML = '<span style="opacity:.7">▲</span>'; } el.classList.toggle('can', r.pop === b.id.slice(4)); }
    });
    updPop(); updSel();
    if (r.sel && r.sel.dead) hideSel();
    miniT -= 0.1; if (miniT <= 0) { miniT = 0.3; drawMini(r); }
  }

  // ----- экраны / окна -----
  function showMenu() {
    state = 'menu'; run = null; paused = false; document.body.classList.remove('playing', 'night'); $('#vig').style.opacity = 0; closeModal(true); closePopSafe();
    scene = newRun('hunter'); run = null; scene.dkOverride = 0.78; scene.player.x = CX + 30; scene.player.y = CY + 30;
    $('#splash').classList.remove('on'); $('#menu').classList.add('on');
    $('#menuStat').textContent = '🪙 ' + save.coins + '   ·   Рекорд: ' + save.best + ' ноч.';
    $('#bSound').textContent = 'Звук: ' + (save.sound ? 'вкл' : 'выкл');
    Snd.mode('menu');
  }
  function closePopSafe() { $('#pop').classList.remove('on'); $('#upg').classList.remove('on'); }
  function openModal(html, cls) {
    const m = $('#modal'); m.innerHTML = html; m.className = 'modal panel px ' + (cls || '');
    $('#modalbg').classList.add('on'); modalOpen = true;
  }
  function closeModal(silent) { $('#modalbg').classList.remove('on'); modalOpen = false; }

  // ----- слоты -----
  function showSlots() {
    let h = '<h2>Выбери слот</h2><div class="slots">';
    for (let i = 0; i < SLOTS; i++) {
      const o = readSlot(i);
      if (o) {
        const m = o.meta;
        h += '<div class="slot full" data-i="' + i + '"><button class="del" data-del="' + i + '">🗑</button><div class="th">' + (m.thumb ? '<img class="sc" src="' + m.thumb + '">' : '') + '<canvas data-hp="' + m.hero + '"></canvas></div>' +
          '<div class="sn">СЛОТ ' + (i + 1) + '</div><b>' + (m.phase === 'night' ? 'Ночь ' : 'День ') + m.night + '</b><small>' + (HEROES[m.hero] ? HEROES[m.hero].name : '') + ' · костёр ур. ' + m.fireLvl + '</small><small>⏱ ' + fmtPlay(m.time) + ' · убито ' + m.kills + '</small></div>';
      } else {
        h += '<div class="slot empty" data-i="' + i + '"><div class="th"><div class="plus">+</div></div><div class="sn">СЛОТ ' + (i + 1) + '</div><b style="color:#fff;font-size:.9rem">Новая игра</b><small>пустой слот</small></div>';
      }
    }
    h += '</div><div><button class="btn" id="sBack">Назад</button></div>';
    openModal(h, 'wide');
    document.querySelectorAll('canvas[data-hp]').forEach(c => { const s = SPR.hero[c.dataset.hp][0]; c.width = s.w; c.height = s.h; c.getContext('2d').drawImage(s.c, 0, 0); if (c.previousElementSibling) c.style.opacity = 0; });
    document.querySelectorAll('.slot').forEach(el => el.onclick = () => {
      const i = +el.dataset.i; Snd.sfx('click');
      if (el.classList.contains('full')) loadSlot(i); else showHeroPick(i);
    });
    document.querySelectorAll('.slot .del').forEach(b => b.onclick = e => {
      e.stopPropagation(); const i = +b.dataset.del;
      if (b.classList.contains('sure')) { delSlot(i); Snd.sfx('hurt'); showSlots(); return; }
      b.classList.add('sure'); b.textContent = 'Удалить?'; Snd.sfx('click'); setTimeout(() => { if (b.isConnected) { b.classList.remove('sure'); b.textContent = '🗑'; } }, 2500);
    });
    $('#sBack').onclick = () => { Snd.sfx('click'); closeModal(); };
  }
  function showHeroPick(slot) {
    let h = '<h2>Выбери героя</h2><div class="cards">';
    Object.keys(HEROES).forEach(id => {
      const hd = HEROES[id], own = !!save.owned[id];
      h += '<div class="card hero' + (save.hero === id && own ? ' sel' : '') + '" data-id="' + id + '" style="' + (own ? '' : 'opacity:.55') + '"><canvas data-p="' + id + '"></canvas><b>' + hd.name + '</b><small>' + hd.desc + '</small><small style="margin-top:.3rem">❤ ' + hd.hp + ' · 👟 ' + hd.speed + '</small><div class="lv">' + (own ? 'НАЧАТЬ' : '🔒 купи в «Герои» (🪙 ' + hd.price + ')') + '</div></div>';
    });
    h += '</div><div><button class="btn" id="hpBack">Назад</button></div>';
    openModal(h);
    document.querySelectorAll('canvas[data-p]').forEach(c => { const s = SPR.hero[c.dataset.p][0]; c.width = s.w; c.height = s.h; c.getContext('2d').drawImage(s.c, 0, 0); });
    document.querySelectorAll('.card.hero').forEach(el => el.onclick = () => {
      const id = el.dataset.id; if (!save.owned[id]) { Snd.sfx('no'); return; }
      Snd.sfx('click'); startRun(slot, id);
    });
    $('#hpBack').onclick = () => { Snd.sfx('click'); showSlots(); };
  }

  function resetHudCache() { Object.keys(cache).forEach(k => { if (/^(r|b|uhp)/.test(k) || k === 'ph' || k === 'phs') delete cache[k]; }); }
  function enterPlay() {
    scene = null; state = 'play'; paused = false; closeModal(); closePopSafe();
    $('#menu').classList.remove('on'); document.body.classList.add('playing'); resetHudCache();
    cam.x = clamp(run.player.x - W / 2, 0, WW - W); cam.y = clamp(run.player.y - H / 2, 0, WH - H);
    updateHud(); drawMini(run);
  }
  function startRun(slot, heroId) {
    save.hero = heroId; persist();
    newRun(heroId); run.slot = slot; enterPlay();
    Snd.mode('day'); banner('ДЕНЬ 1', 'Руби деревья, добывай камень — герой всё делает сам', '#ffd166');
    const r = run;
    setTimeout(() => { if (run === r && r.night === 1 && r.phase === 'day') hint('Води пальцем по экрану. Нажми на постройку, чтобы улучшить её', 5200); }, 2800);
    saveNow(true);
  }
  function loadSlot(i) {
    const o = readSlot(i); if (!o) { showSlots(); return; }
    try { deserialize(o, i); } catch (e) { console.error(e); hint('Сохранение повреждено'); return; }
    enterPlay();
    const r = run;
    if (r.phase === 'night') { Snd.mode(r.bossRef && !r.bossRef.dead ? 'boss' : 'night'); } else Snd.mode('day');
    banner((r.phase === 'night' ? 'НОЧЬ ' : 'ДЕНЬ ') + r.night, 'Игра загружена', '#8fe3ff');
    if (r.phase === 'choose') setTimeout(() => { if (run === r && !r.over) showUpgrade(r.pending || 1); }, 500);
  }

  function showPause() {
    if (state !== 'play' || !run || run.over || modalOpen) return;
    paused = true; Snd.sfx('click'); saveNow();
    openModal('<h2>Пауза</h2><p>' + (run.phase === 'night' ? 'Ночь ' : 'День ') + run.night + ' · убито ' + run.kills + '<br><small style="opacity:.8">Игра сохранена в слот ' + ((run.slot | 0) + 1) + '</small></p><div><button class="btn go" id="mCont">Продолжить</button></div><div><button class="btn" id="mMenu">Сохранить и выйти</button></div>');
    $('#mCont').onclick = () => { closeModal(); paused = false; Snd.sfx('click'); };
    $('#mMenu').onclick = () => { Snd.sfx('click'); saveAndExit(); };
  }
  $('#pauseBtn').addEventListener('pointerdown', e => { e.stopPropagation(); e.preventDefault(); showPause(); });
  document.addEventListener('visibilitychange', () => { if (document.hidden) { showPause(); saveNow(); } });
  window.addEventListener('pagehide', () => { saveNow(); });

  function payout(r) {
    const total = Math.floor(r.coins / 4) + Math.max(0, r.night - 1) * 3, add = Math.max(0, total - (r.paid || 0));
    if (add > 0) { save.coins += add; r.paid = total; }
    save.best = Math.max(save.best, Math.max(0, r.night - 1)); persist(); return add;
  }
  function saveAndExit() { if (run) { payout(run); saveNow(); } run = null; paused = false; showMenu(); }

  function showOver() {
    const r = run, survived = Math.max(0, r.night - 1);
    payout(r); save.kills += r.kills; persist();
    Snd.sfx('over'); Snd.mode('off');
    openModal('<h2 style="color:' + (r.why === 'fire' ? '#ff8a3a' : '#ff5a5f') + '">' + (r.why === 'fire' ? 'Костёр погас' : 'Герой пал') + '</h2>' +
      '<p>' + (r.why === 'fire' ? 'Тьма поглотила лагерь…' : 'Ночь оказалась слишком длинной…') + '</p>' +
      '<div class="stats"><div><b>' + survived + '</b>ночей пережито</div><div><b>' + r.kills + '</b>монстров убито</div><div><b>+' + r.paid + '</b>монет за забег</div></div>' +
      '<p>Рекорд: <span class="gold">' + save.best + ' ноч.</span></p>' +
      '<div><button class="btn go" id="oAgain">Ещё раз</button><button class="btn" id="oMenu">В меню</button></div>');
    r.over = 2;
    $('#oAgain').onclick = () => { Snd.sfx('click'); const s = r.slot, h = r.heroId; run = null; startRun(s, h); };
    $('#oMenu').onclick = () => { Snd.sfx('click'); run = null; showMenu(); };
  }
  function gameOver(why) {
    const r = run; if (r.over) return; r.over = true; r.overT = 1.1; r.why = why; r.shake = 8;
    if (r.slot !== null) delSlot(r.slot);
    burst(r.player.x, r.player.y - 6, '#ff5a5f', 30, 90, 0.9, 2, true);
  }

  function showHeroes() {
    let h = '<h2>Герои</h2><p>Монеты: <span class="gold">🪙 ' + save.coins + '</span></p><div class="cards">';
    Object.keys(HEROES).forEach(id => {
      const hd = HEROES[id], own = !!save.owned[id];
      h += '<div class="card hero' + (save.hero === id && own ? ' sel' : '') + '" data-id="' + id + '"><canvas width="14" height="18" data-p="' + id + '"></canvas><b>' + hd.name + '</b><small>' + hd.desc + '</small><small style="margin-top:.3rem">❤ ' + hd.hp + ' · 👟 ' + hd.speed + '</small>' +
        '<div class="lv">' + (save.hero === id && own ? 'ВЫБРАН' : own ? 'ВЫБРАТЬ' : '🪙 ' + hd.price + (save.coins >= hd.price ? ' — КУПИТЬ' : ' — не хватает')) + '</div></div>';
    });
    h += '</div><div><button class="btn" id="hBack">Назад</button></div>';
    openModal(h);
    document.querySelectorAll('canvas[data-p]').forEach(c => { const s = SPR.hero[c.dataset.p][0]; c.width = s.w; c.height = s.h; c.getContext('2d').drawImage(s.c, 0, 0); });
    document.querySelectorAll('.card.hero').forEach(el => el.onclick = () => {
      const id = el.dataset.id, hd = HEROES[id];
      if (!save.owned[id]) { if (save.coins >= hd.price) { save.coins -= hd.price; save.owned[id] = true; save.hero = id; Snd.sfx('up'); } else { Snd.sfx('no'); return; } }
      else { save.hero = id; Snd.sfx('click'); }
      persist(); showHeroes(); $('#menuStat').textContent = '🪙 ' + save.coins + '   ·   Рекорд: ' + save.best + ' ноч.';
    });
    $('#hBack').onclick = () => { Snd.sfx('click'); closeModal(); };
  }
  function showAbout() {
    openModal('<h2>Последний костёр</h2><p>Днём собирай ресурсы, исследуй руины и строй базу: стены, турели, баллисты, мортиры.<br>Ночью из тьмы идут чудовища — держи костёр до рассвета!<br>После каждой ночи выбирай новое улучшение. Каждая пятая ночь — босс.</p>' +
      '<p style="margin-top:.8rem">Студия <b class="gold">Nyxvault</b><br>Главный разработчик: <b class="gold">Анас Акрамзод</b></p><p style="opacity:.6;font-size:.75rem">Версия 1.1</p><div><button class="btn" id="aBack">Назад</button></div>');
    $('#aBack').onclick = () => { Snd.sfx('click'); closeModal(); };
  }

  // ================= выбор улучшения =================
  function showUpgrade(n) {
    const r = run; r.pending = n;
    const avail = UPG.filter(u => (r.up[u.id] || 0) < u.max);
    for (let i = avail.length - 1; i > 0; i--) { const j = (Math.random() * (i + 1)) | 0; const t = avail[i]; avail[i] = avail[j]; avail[j] = t; }
    const ch = avail.slice(0, 3);
    let h = '<h2>Рассвет! Выбери улучшение</h2><div class="cards">';
    ch.forEach(u => { const lv = r.up[u.id] || 0; h += '<div class="card" data-id="' + u.id + '"><div class="em">' + u.em + '</div><b>' + u.name + '</b><small>' + u.desc + '</small><span class="lv">Ур. ' + lv + ' → ' + (lv + 1) + '</span></div>'; });
    h += '</div>' + (n > 1 ? '<p class="gold">Награда за босса: ещё одно улучшение!</p>' : '');
    openModal(h); Snd.sfx('up');
    document.querySelectorAll('.card[data-id]').forEach(el => el.onclick = () => {
      const id = el.dataset.id; r.up[id] = (r.up[id] || 0) + 1; applyUpg(id); Snd.sfx('up');
      closeModal(); r.pending--;
      if (r.pending > 0) setTimeout(() => showUpgrade(r.pending), 200); else startDay();
    });
  }
  function applyUpg(id) {
    const r = run, p = r.player, f = r.fire;
    r.st = stats();
    if (id === 'vit') { p.maxHp = r.st.maxHp; p.hp = Math.min(p.maxHp, p.hp + 30); }
    if (id === 'firehp') { f.maxHp += 60; f.hp = Math.min(f.maxHp, f.hp + 60); }
  }

  // ================= ночь / день =================
  function startDay() {
    const r = run; r.phase = 'day'; r.t = 0; r.dayLen = 50; r.nightLen = Math.min(46 + 7 * r.night, 115);
    r.player.hp = Math.min(r.player.maxHp, r.player.hp + r.player.maxHp * 0.35);
    r.ruins.forEach(u => { if (u.opened) { u.cd--; if (u.cd <= 0) { u.opened = false; u.prog = 0; } } });
    regrow(r, false); r.st = stats();
    Snd.mode('day'); banner('ДЕНЬ ' + r.night, 'Пополни запасы, загляни в руины', '#ffd166'); saveNow();
  }
  function startNight() {
    const r = run; r.phase = 'night'; r.t = 0; r.spawnAcc = 0; r.burstT = 14; r.nightLen = Math.min(46 + 7 * r.night, 115);
    const boss = r.night % 5 === 0; closePop();
    Snd.mode(boss ? 'boss' : 'night'); Snd.sfx('horn');
    banner('НОЧЬ ' + r.night, boss ? 'Пришёл Король Теней!' : 'Защити костёр до рассвета', boss ? '#d79bff' : '#8fa0ff');
    if (r.night === 1) setTimeout(() => { if (run === r) hint('Герой стреляет сам. Не дай монстрам потушить костёр!', 5000); }, 2600);
    if (boss) spawnBoss();
    saveNow();
  }
  function endNight() {
    const r = run; r.phase = 'choose';
    r.enemies.forEach(e => { if (!e.dead) { e.dead = true; burst(e.x, e.y - 6, ET[e.type].col, 8, 50, 0.7, 1, true); } });
    r.enemies = []; r.eprojs = []; r.shells = []; r.bossRef = null;
    r.coins += 5 + r.night * 2; save.best = Math.max(save.best, r.night);
    Snd.sfx('dawn'); Snd.mode('day'); banner('РАССВЕТ', 'Ночь ' + r.night + ' пережита!', '#ffd166');
    const boss = r.night % 5 === 0; r.night++; r.pending = boss ? 2 : 1; payout(r); saveNow();
    setTimeout(() => { if (run === r && !r.over && r.phase === 'choose' && !modalOpen) showUpgrade(r.pending); }, 1400);
  }
  function darkness(r) {
    if (r.dkOverride !== null) return r.dkOverride;
    if (r.phase === 'day') { const l = r.dayLen - r.t; return l < 8 ? 1 - l / 8 : 0; }
    if (r.phase === 'night') { const l = r.nightLen - r.t; return (l < 8 && !(r.bossRef && !r.bossRef.dead)) ? clamp(l / 8, 0, 1) : 1; }
    return 0;
  }

  // ================= сохранение забега =================
  function makeThumb() {
    try {
      const t = document.createElement('canvas'); t.width = 120; t.height = Math.max(40, Math.round(120 * H / W));
      t.getContext('2d').drawImage(cv, 0, 0, t.width, t.height); return t.toDataURL('image/jpeg', 0.6);
    } catch (e) { return ''; }
  }
  const R1 = v => Math.round(v * 10) / 10;
  function serialize(r) {
    const p = r.player, f = r.fire, bossIdx = r.bossRef ? r.enemies.indexOf(r.bossRef) : -1;
    return {
      v: 2, slot: r.slot, hero: r.heroId, night: r.night, phase: r.phase, t: r.t, dayLen: r.dayLen, nightLen: r.nightLen, time: r.time,
      p: { x: p.x, y: p.y, hp: p.hp, maxHp: p.maxHp, face: p.face, fx: p.fx, fy: p.fy, inv: p.inv, cd: p.cd, lt: p.lt, nt: p.nt },
      f: { hp: f.hp, maxHp: f.maxHp, level: f.level },
      res: r.res, up: r.up, kills: r.kills, coins: r.coins, paid: r.paid, bosses: r.bosses, spawnAcc: r.spawnAcc, burstT: r.burstT, orbA: r.orbA, pending: r.pending,
      nodes: r.nodes.map(n => [n.type, R1(n.x), R1(n.y), n.hp, n.maxHp, n.v]),
      structs: r.structs.map(s => ({ type: s.type, x: s.x, y: s.y, hp: s.hp, max: s.max, bmax: s.bmax, lvl: s.lvl, cd: s.cd, aim: s.aim })),
      enemies: r.enemies.map(e => ({ type: e.type, x: R1(e.x), y: R1(e.y), hp: e.hp, maxHp: e.maxHp, spd: e.spd, r: e.r, dmg: e.dmg, kx: e.kx, ky: e.ky, cd: e.cd, ph: e.ph, anim: e.anim, sk: e.sk, sm: e.sm, slow: e.slow })),
      bossIdx: bossIdx,
      projs: r.projs.map(q => ({ x: q.x, y: q.y, vx: q.vx, vy: q.vy, dmg: q.dmg, pierce: q.pierce, life: q.life, col: q.col, own: q.own, big: q.big })),
      eprojs: r.eprojs.map(q => ({ x: q.x, y: q.y, vx: q.vx, vy: q.vy, dmg: q.dmg, life: q.life })),
      shells: r.shells.map(s => ({ x: s.x, y: s.y, sx: s.sx, sy: s.sy, tx: s.tx, ty: s.ty, t: s.t, T: s.T, dmg: s.dmg, R: s.R })),
      ruins: r.ruins.map(u => [u.opened ? 1 : 0, u.cd]),
      meta: { hero: r.heroId, night: r.night, phase: r.phase, time: Math.round(r.time), kills: r.kills, fireLvl: f.level, savedAt: Date.now(), thumb: '' }
    };
  }
  function deserialize(o, slot) {
    const r = newRun(o.hero, true);
    r.slot = slot; r.night = o.night; r.phase = o.phase; r.t = o.t; r.dayLen = o.dayLen; r.nightLen = o.nightLen; r.time = o.time;
    Object.assign(r.player, o.p); Object.assign(r.fire, o.f);
    r.res = o.res; r.up = o.up; r.kills = o.kills; r.coins = o.coins; r.paid = o.paid || 0; r.bosses = o.bosses || 0; r.spawnAcc = o.spawnAcc || 0; r.burstT = o.burstT || 14; r.orbA = o.orbA || 0; r.pending = o.pending || 0;
    r.nodes = o.nodes.map(n => ({ kind: 'n', type: n[0], x: n[1], y: n[2], hp: n[3], maxHp: n[4], shake: 0, v: n[5], r: 6 }));
    r.structs = o.structs.map(s => ({ kind: 's', type: s.type, x: s.x, y: s.y, r: SD[s.type].r, hp: s.hp, max: s.max, bmax: s.bmax, lvl: s.lvl || 1, flash: 0, cd: s.cd || 0.3, aim: s.aim || 0, aura: 0.5, dead: false, muz: 0, pf: 0, snd: 0 }));
    r.enemies = o.enemies.map(e => Object.assign({ kx: 0, ky: 0, hit: 0, cd: 0.5, tgt: null, tt: Math.random() * 0.4, orb: 0, ph: 0, anim: 0, dead: false, slow: 0 }, e));
    r.bossRef = o.bossIdx >= 0 ? r.enemies[o.bossIdx] : null;
    r.projs = (o.projs || []).map(q => Object.assign({ hit: [] }, q)); r.eprojs = o.eprojs || []; r.shells = o.shells || [];
    (o.ruins || []).forEach((u, i) => { if (r.ruins[i]) { r.ruins[i].opened = !!u[0]; r.ruins[i].cd = u[1]; } });
    r.st = stats(); run = r; return r;
  }
  function saveNow(first) {
    const r = run; if (!r || r.slot === null || r.over) return;
    try { const o = serialize(r); o.meta.thumb = (r.time > 0.6 && state === 'play') ? makeThumb() : ''; writeSlot(r.slot, o); } catch (e) { console.error('save', e); }
  }

  // ================= враги =================
  function spawnEnemy(type, x, y) {
    const t = ET[type], r = run, n = r.night - 1, m = 1 + 0.15 * n;
    const e = { type: type, x: x, y: y, hp: t.hp * m, maxHp: t.hp * m, spd: t.spd * rand(0.9, 1.1), r: t.r, dmg: t.dmg * (1 + 0.08 * n), kx: 0, ky: 0, hit: 0, cd: rand(0, 0.6), tgt: null, tt: rand(0, 0.4), orb: 0, ph: rand(0, 6.28), anim: rand(0, 5), dead: false, slow: 0 };
    r.enemies.push(e); return e;
  }
  function spawnPos(angle) {
    const r = run; let x, y, tries = 0;
    do {
      const a = angle !== undefined ? angle + rand(-0.35, 0.35) : rand(0, TAU), k = rand(0.95, 1.12);
      x = CX + Math.cos(a) * 480 * k; y = CY + Math.sin(a) * 320 * k;
      x = clamp(x, 30, WW - 30); y = clamp(y, 40, WH - 20);
    } while (d2(x, y, r.player.x, r.player.y) < 170 * 170 && tries++ < 5);
    return [x, y];
  }
  function pickType() {
    const n = run.night, list = []; let tot = 0;
    for (const k in ET) { const t = ET[k]; if (t.w > 0 && n >= t.from) { list.push([k, t.w]); tot += t.w; } }
    let v = Math.random() * tot; for (const it of list) { v -= it[1]; if (v <= 0) return it[0]; }
    return 'slime';
  }
  function spawnBoss() {
    const r = run, p = spawnPos(), tier = r.night / 5;
    const e = spawnEnemy('boss', p[0], p[1]);
    e.maxHp = e.hp = 450 + 260 * (tier - 1); e.dmg = 26 + 4 * tier; e.sk = 2.5; e.sm = 7; r.bossRef = e;
    Snd.sfx('boss');
  }
  function chooseTarget(e) {
    const r = run, p = r.player, f = r.fire;
    let best = f, bd = d2(e.x, e.y, f.x, f.y);
    if (e.type !== 'ghost') for (let i = 0; i < r.structs.length; i++) { const s = r.structs[i], d = d2(e.x, e.y, s.x, s.y); if (d < bd) { bd = d; best = s; } }
    if (d2(e.x, e.y, p.x, p.y) < 70 * 70 && p.hp > 0) best = p;
    e.tgt = best;
  }
  function dmgEnemy(e, d, fx, fy, kb) {
    if (e.dead) return;
    e.hp -= d; e.hit = 0.11; Snd.sfx('hit');
    const a = Math.atan2(e.y - fy, e.x - fx), k = (kb || 90) * (e.type === 'boss' ? 0.04 : e.type === 'brute' ? 0.35 : 1);
    e.kx += Math.cos(a) * k; e.ky += Math.sin(a) * k;
    if (e.hp <= 0) killEnemy(e);
  }
  function killEnemy(e) {
    if (e.dead) return; e.dead = true; const r = run, t = ET[e.type];
    r.kills++; r.coins += t.coin; burst(e.x, e.y - 6, t.col, e.type === 'boss' ? 50 : 9, e.type === 'boss' ? 130 : 60, 0.7, e.type === 'boss' ? 2 : 1, false);
    Snd.sfx('kill');
    const lf = r.up.life || 0; if (lf && Math.random() < 0.2 * lf) r.player.hp = Math.min(r.player.maxHp, r.player.hp + 2);
    if (e.type === 'boss') { r.bosses++; r.shake = 10; burst(e.x, e.y - 20, '#ffffff', 40, 160, 1, 2, true); r.eprojs = []; }
  }
  function hurtPlayer(d) {
    const p = run.player; if (p.inv > 0 || run.over) return;
    p.hp -= d; p.inv = 0.55; run.shake = Math.max(run.shake, 4); Snd.sfx('hurt'); burst(p.x, p.y - 8, '#ff5a5f', 6, 50, 0.4, 1);
    if (p.hp <= 0) gameOver('hero');
  }
  function hurtFire(d) {
    const f = run.fire; if (run.over) return;
    f.hp -= d; f.flash = 0.18; run.shake = Math.max(run.shake, 2.5);
    if (Math.random() < 0.4) Snd.sfx('fire');
    burst(f.x, f.y - 8, '#ff9a3a', 3, 40, 0.5, 1, true);
    if (f.hp <= 0) gameOver('fire');
  }
  function hurtStruct(s, d) {
    s.hp -= d; s.flash = 0.12;
    if (s.hp <= 0 && !s.dead) { s.dead = true; burst(s.x, s.y - 8, '#9a6b3e', 12, 70, 0.7, 1); Snd.sfx('hit'); if (run.sel === s) hideSel(); }
  }
  function dmgTarget(t, d, att) {
    if (t.kind === 'p') hurtPlayer(d); else if (t.kind === 'f') hurtFire(d);
    else {
      hurtStruct(t, d);
      const th = SD[t.type].thorns; if (th && att && !att.dead) dmgEnemy(att, th * (1 + 0.35 * (t.lvl - 1)), t.x, t.y, 60);
    }
  }

  // ================= постройки =================
  function doBuild(id) {
    if (state !== 'play' || !run || run.over || paused || modalOpen || run.phase === 'choose') return;
    const r = run, p = r.player, f = r.fire; r.st = stats();
    if (SD[id]) { placeStruct(id); return; }
    const b = BAR.find(x => x.id === id), c = b.cost();
    if (!c) { hint('Костёр уже на максимальном уровне'); Snd.sfx('no'); return; }
    if (!afford(c)) { hint('Не хватает ресурсов'); Snd.sfx('no'); return; }
    if (id === 'repair') {
      let need = f.hp < f.maxHp; r.structs.forEach(s => { if (s.hp < s.max) need = true; });
      if (!need) { hint('Чинить нечего'); Snd.sfx('no'); return; }
      f.hp = Math.min(f.maxHp, f.hp + f.maxHp * 0.4); r.structs.forEach(s => { s.hp = Math.min(s.max, s.hp + s.max * 0.5); });
      burst(f.x, f.y - 10, '#7dff8f', 14, 60, 0.8, 1, true);
    } else if (id === 'fire') {
      f.level++; const add = 40; f.maxHp += add; f.hp = Math.min(f.maxHp, f.hp + add + 30); burst(f.x, f.y - 10, '#ffd15c', 30, 110, 1, 2, true);
      banner('КОСТЁР УРОВНЯ ' + f.level, 'Больше света, огня и прочности', '#ffb23a');
    }
    pay(c); Snd.sfx('build'); updateHud(); r.saveT = Math.min(r.saveT, 1);
  }
  function placeStruct(id) {
    const r = run, p = r.player, f = r.fire, d = SD[id], c = d.cost;
    if (!afford(c)) { hint('Не хватает ресурсов'); Snd.sfx('no'); return; }
    const ang = Math.atan2(p.fy, p.fx), tries = [0, 0.7, -0.7, 1.4, -1.4, 2.2, -2.2, 3.1];
    let pos = null;
    for (const da of tries) {
      const x = clamp(p.x + Math.cos(ang + da) * 20, 16, WW - 16), y = clamp(p.y + Math.sin(ang + da) * 20 + 2, 30, WH - 6);
      let ok = d2(x, y, f.x, f.y) > 26 * 26;
      for (let i = 0; ok && i < r.structs.length; i++) if (d2(x, y, r.structs[i].x, r.structs[i].y) < 13 * 13) ok = false;
      if (ok) { pos = [x, y]; break; }
    }
    if (!pos) { hint('Здесь нет места'); Snd.sfx('no'); return; }
    const hp = d.hp * r.st.wallMul;
    r.structs.push({ kind: 's', type: id, x: pos[0], y: pos[1], r: d.r, hp: hp, max: hp, bmax: hp, lvl: 1, flash: 0, cd: rand(0.2, 0.6), aim: 0, aura: 0.5, dead: false, muz: 0, pf: 0, snd: 0 });
    burst(pos[0], pos[1] - 6, '#c9a05a', 8, 40, 0.5, 1);
    pay(c); Snd.sfx('build'); updateHud(); r.saveT = Math.min(r.saveT, 1);
  }

  // ================= обновление =================
  function update(dt) {
    const r = run; r.time += dt; r.st = stats(); const st = r.st;
    if (r.over) { r.overT -= dt; updateParts(r, dt); if (r.over === true && r.overT <= 0) { r.over = 1; showOver(); } return; }
    if (r.phase === 'day') { r.t += dt; if (r.t >= r.dayLen) startNight(); }
    else if (r.phase === 'night') {
      r.t += dt; const left = r.nightLen - r.t, bossAlive = r.bossRef && !r.bossRef.dead;
      if (left > 6 || bossAlive) {
        const rate = (0.26 + 0.17 * r.night) * (r.night % 5 === 0 ? 0.6 : 1);
        r.spawnAcc += dt * rate;
        while (r.spawnAcc >= 1) { r.spawnAcc -= 1; if (r.enemies.length < 60) { const p = spawnPos(); spawnEnemy(pickType(), p[0], p[1]); } }
        r.burstT -= dt;
        if (r.burstT <= 0 && left > 12) {
          r.burstT = rand(14, 20); const a = rand(0, TAU), n = 3 + r.night;
          for (let i = 0; i < n && r.enemies.length < 70; i++) { const p = spawnPos(a); spawnEnemy(pickType(), p[0], p[1]); }
          hint('⚠ Орда с той стороны!', 2200); Snd.sfx('horn');
        }
      }
      if (r.t >= r.nightLen && !bossAlive) endNight();
    }
    updatePlayer(r, dt, st);
    updateRuins(r, dt, st);
    updateStructs(r, dt, st);
    updateEnemies(r, dt, st);
    updateProjs(r, dt);
    const f = r.fire; f.flash = Math.max(0, f.flash - dt); f.aura -= dt;
    if (f.aura <= 0) { f.aura = 0.5; const R = 34 + 6 * f.level, D = 2.5 * f.level; r.enemies.forEach(e => { if (!e.dead && d2(e.x, e.y, f.x, f.y) < (R + e.r) * (R + e.r)) dmgEnemy(e, D, f.x, f.y, 40); }); }
    r.structs = r.structs.filter(s => !s.dead); r.enemies = r.enemies.filter(e => !e.dead);
    updateAmbient(r, dt);
    r.shake = Math.max(0, r.shake - dt * 14);
    r.saveT -= dt; if (r.saveT <= 0) { r.saveT = 5; saveNow(); }
    hudT -= dt; if (hudT <= 0) { hudT = 0.1; updateHud(); }
  }

  function updateAmbient(r, dt) {
    updateParts(r, dt);
    r.embT -= dt;
    if (r.embT <= 0) { r.embT = 0.07; spark(r.fire.x + rand(-5, 5), r.fire.y - 8, pick(['#ffb23a', '#ff7a1a', '#ffe08a']), rand(0.8, 1.6)); }
    r.flies.forEach(fl => { fl.ph += dt * fl.sp; fl.x += Math.cos(fl.ph * 1.3) * 6 * dt; fl.y += Math.sin(fl.ph) * 5 * dt; });
  }
  function updateParts(r, dt) {
    const a = r.parts;
    for (let i = a.length - 1; i >= 0; i--) {
      const p = a[i]; p.life -= dt; if (p.life <= 0) { a[i] = a[a.length - 1]; a.pop(); continue; }
      p.x += p.vx * dt; p.y += p.vy * dt; p.vy += p.g * dt; p.vx *= 0.99;
    }
    for (let i = r.bolts.length - 1; i >= 0; i--) { r.bolts[i].life -= dt; if (r.bolts[i].life <= 0) r.bolts.splice(i, 1); }
    for (let i = r.rings.length - 1; i >= 0; i--) { const g = r.rings[i]; g.life -= dt; g.r += (g.max - g.r) * Math.min(1, dt * 9); if (g.life <= 0) r.rings.splice(i, 1); }
  }

  function updateRuins(r, dt, st) {
    const p = r.player;
    r.ruins.forEach(u => {
      if (u.opened) return;
      if (d2(p.x, p.y, u.x, u.y) < 24 * 24) { u.prog += dt; if (u.prog >= 0.9) openChest(u, st); } else u.prog = Math.max(0, u.prog - dt * 2);
    });
  }
  function openChest(u, st) {
    const r = run; u.opened = true; u.cd = 2; u.prog = 0;
    const w = Math.round(rint(8, 16) * st.harvest), s = Math.round(rint(6, 14) * st.harvest), c = Math.round(rint(1, 4) * st.harvest), coin = rint(8, 16);
    r.res.wood += w; r.res.stone += s; r.res.crystal += c; r.coins += coin;
    burst(u.x, u.y - 8, '#ffd447', 26, 90, 0.9, 2, true); Snd.sfx('chest'); r.shake = Math.max(r.shake, 1.5);
    hint('📦 Сундук! +' + w + ' дерева, +' + s + ' камня, +' + c + ' кристаллов', 3600); updateHud();
  }

  function updatePlayer(r, dt, st) {
    const p = r.player;
    let ax = input.x + input.kx, ay = input.y + input.ky; const m = Math.hypot(ax, ay);
    if (m > 1) { ax /= m; ay /= m; }
    p.moving = m > 0.12;
    if (p.moving) { p.x += ax * st.speed * dt; p.y += ay * st.speed * dt; p.fx = ax / Math.max(0.01, Math.min(1, m)); p.fy = ay / Math.max(0.01, Math.min(1, m)); p.anim += dt; }
    p.x = clamp(p.x, 14, WW - 14); p.y = clamp(p.y, 26, WH - 4);
    p.inv -= dt; p.swing -= dt;
    p.ht -= dt;
    if (p.ht <= 0) {
      let best = null, bd = 24 * 24;
      for (let i = 0; i < r.nodes.length; i++) { const n = r.nodes[i]; if (Math.abs(n.x - p.x) > 24 || Math.abs(n.y - p.y) > 24) continue; const d = d2(p.x, p.y, n.x, n.y); if (d < bd) { bd = d; best = n; } }
      if (best) {
        p.ht = 0.42; p.swing = 0.18; best.hp--; best.shake = 0.16;
        burst(best.x, best.y - 8, best.type === 'tree' ? '#9a6b3e' : best.type === 'rock' ? '#9aa3b8' : '#6fe3ff', 4, 40, 0.4, 1);
        Snd.sfx(best.type === 'tree' ? 'chop' : 'mine');
        if (best.hp <= 0) {
          const amt = Math.round((best.type === 'crystal' ? rint(1, 2) : rint(2, 3)) * st.harvest), key = best.type === 'tree' ? 'wood' : best.type === 'rock' ? 'stone' : 'crystal';
          r.res[key] += amt; Snd.sfx('pick'); burst(best.x, best.y - 8, best.type === 'crystal' ? '#9ff3ff' : '#ffd166', 10, 60, 0.6, 1, true);
          r.nodes.splice(r.nodes.indexOf(best), 1); updateHud();
        }
      }
    }
    p.cd -= dt;
    let tgt = null, bd = st.range * st.range;
    for (let i = 0; i < r.enemies.length; i++) { const e = r.enemies[i]; if (e.dead) continue; const d = d2(p.x, p.y, e.x, e.y); if (d < bd) { bd = d; tgt = e; } }
    if (tgt && p.cd <= 0) {
      p.cd = st.cd; const a0 = Math.atan2(tgt.y - (p.y - 8), tgt.x - p.x), n = st.shots;
      for (let k = 0; k < n; k++) {
        const a = a0 + (k - (n - 1) / 2) * 0.16;
        r.projs.push({ x: p.x, y: p.y - 8, vx: Math.cos(a) * 230, vy: Math.sin(a) * 230, dmg: st.dmg, pierce: st.pierce, life: 0.9, col: r.hd.bolt, hit: [], own: 'p' });
      }
      Snd.sfx('shoot');
    }
    const u = r.up;
    if (u.lightning) {
      p.lt -= dt;
      if (p.lt <= 0) {
        const cand = r.enemies.filter(e => !e.dead && d2(p.x, p.y, e.x, e.y) < 175 * 175);
        if (cand.length) {
          p.lt = Math.max(1.0, 3.1 - 0.4 * u.lightning); let cx = p.x, cy = p.y - 8; const hitL = [], n = 2 + u.lightning, dm = 16 + 6 * u.lightning;
          for (let k = 0; k < n; k++) {
            let b = null, bd2 = 1e9; cand.forEach(e => { if (hitL.indexOf(e) < 0 && !e.dead) { const d = d2(cx, cy, e.x, e.y); if (d < bd2 && d < (k ? 95 * 95 : 175 * 175)) { bd2 = d; b = e; } } });
            if (!b) break; hitL.push(b);
            const pts = [[cx, cy]], seg = 4; for (let s = 1; s < seg; s++) pts.push([cx + (b.x - cx) * s / seg + rand(-6, 6), cy + (b.y - 6 - cy) * s / seg + rand(-6, 6)]); pts.push([b.x, b.y - 6]);
            r.bolts.push({ pts: pts, life: 0.16 }); dmgEnemy(b, dm, cx, cy, 60); burst(b.x, b.y - 6, '#bfe8ff', 5, 60, 0.3, 1, true);
            cx = b.x; cy = b.y - 6;
          }
          Snd.sfx('zap'); r.shake = Math.max(r.shake, 1.5);
        } else p.lt = 0.3;
      }
    }
    if (u.orbit) {
      r.orbA += dt * 3.2; const n = u.orbit + 1, R = 27, dm = 7 + 3 * u.orbit;
      for (let k = 0; k < n; k++) {
        const a = r.orbA + k * TAU / n, ox = p.x + Math.cos(a) * R, oy = p.y - 7 + Math.sin(a) * R * 0.8;
        for (let i = 0; i < r.enemies.length; i++) { const e = r.enemies[i]; if (e.dead || e.orb > 0) continue; if (d2(ox, oy, e.x, e.y - 5) < (e.r + 5) * (e.r + 5)) { e.orb = 0.35; dmgEnemy(e, dm, ox, oy, 120); } }
      }
    }
    if (u.nova) {
      p.nt -= dt;
      if (p.nt <= 0) {
        const R = 60 + 8 * u.nova, dm = 20 + 8 * u.nova;
        if (r.enemies.some(e => !e.dead && d2(p.x, p.y, e.x, e.y) < R * R)) {
          p.nt = Math.max(2.2, 6 - 0.6 * u.nova); r.rings.push({ x: p.x, y: p.y - 6, r: 6, max: R, life: 0.45 }); Snd.sfx('nova'); r.shake = Math.max(r.shake, 3);
          r.enemies.forEach(e => { if (!e.dead && d2(p.x, p.y, e.x, e.y) < R * R) dmgEnemy(e, dm, p.x, p.y, 220); });
        } else p.nt = 0.4;
      }
    }
    if (r.phase === 'day' && p.hp < p.maxHp) p.hp = Math.min(p.maxHp, p.hp + 2 * dt);
  }

  function nearestEnemy(x, y, range, minR) {
    const en = run.enemies; let best = null, bd = range * range;
    for (let k = 0; k < en.length; k++) { const e = en[k]; if (e.dead) continue; const d = d2(x, y, e.x, e.y); if (d < bd && (!minR || d > minR * minR)) { bd = d; best = e; } }
    return best;
  }
  function updateStructs(r, dt, st) {
    for (let i = 0; i < r.structs.length; i++) {
      const s = r.structs[i], def = SD[s.type]; s.flash = Math.max(0, s.flash - dt); s.muz = Math.max(0, s.muz - dt);
      const lm = 1 + 0.35 * (s.lvl - 1), rateM = (1 + 0.18 * (r.up.tur || 0)) * (1 + 0.12 * (s.lvl - 1)), dmgM = st.tur * lm;
      if (def.regen && s.hp < s.max) s.hp = Math.min(s.max, s.hp + def.regen * s.lvl * dt);
      if (s.type === 'turret') {
        s.cd -= dt; const t = nearestEnemy(s.x, s.y, 150);
        if (t) {
          s.aim = Math.atan2(t.y - (s.y - 13), t.x - s.x);
          if (s.cd <= 0) { s.cd = 0.75 / rateM; s.muz = 0.08; r.projs.push({ x: s.x, y: s.y - 13, vx: Math.cos(s.aim) * 250, vy: Math.sin(s.aim) * 250, dmg: 7 * dmgM, pierce: 0, life: 0.8, col: '#7df9ff', hit: [], own: 't' }); Snd.sfx('shoot'); }
        }
      } else if (s.type === 'ballista') {
        s.cd -= dt; const t = nearestEnemy(s.x, s.y, 205);
        if (t) {
          s.aim = Math.atan2(t.y - (s.y - 10), t.x - s.x);
          if (s.cd <= 0) { s.cd = 1.7 / rateM; s.muz = 0.1; r.projs.push({ x: s.x, y: s.y - 10, vx: Math.cos(s.aim) * 340, vy: Math.sin(s.aim) * 340, dmg: 22 * dmgM, pierce: 4, life: 0.85, col: '#f3e6b8', hit: [], own: 't', big: true }); Snd.sfx('bolt'); }
        }
      } else if (s.type === 'mortar') {
        s.cd -= dt;
        if (s.cd <= 0) {
          let best = null, bs = -1;
          r.enemies.forEach(e => { if (e.dead) return; const d = d2(s.x, s.y, e.x, e.y); if (d < 50 * 50 || d > 245 * 245) return; let n = 0; r.enemies.forEach(o => { if (!o.dead && d2(o.x, o.y, e.x, e.y) < 38 * 38) n++; }); if (n > bs) { bs = n; best = e; } });
          if (best) { s.cd = 2.9 / rateM; s.muz = 0.12; r.shells.push({ x: s.x, y: s.y - 14, sx: s.x, sy: s.y - 14, tx: best.x, ty: best.y, t: 0, T: 0.95, dmg: 26 * dmgM, R: 30 + 4 * s.lvl }); Snd.sfx('lob'); burst(s.x, s.y - 14, '#bfc6d8', 6, 40, 0.5, 1); } else s.cd = 0.4;
        }
      } else if (s.type === 'flamer') {
        const t = nearestEnemy(s.x, s.y, 64); s.aura -= dt; s.on = !!t;
        if (t) {
          s.aim = Math.atan2(t.y - (s.y - 9), t.x - s.x); s.pf -= dt;
          if (s.pf <= 0) { s.pf = 0.03; const c = Math.cos(s.aim), sn = Math.sin(s.aim); if (r.parts.length < 400) r.parts.push({ x: s.x + c * 9, y: s.y - 9 + sn * 9, vx: c * 95 + rand(-14, 14), vy: sn * 95 + rand(-14, 14) - 6, life: 0.34, max: 0.34, col: pick(['#ff7a1a', '#ffc23a', '#fff1a8', '#d63a12']), size: 2, g: -8, add: true }); }
          if (s.aura <= 0) {
            s.aura = 0.25; const c = Math.cos(s.aim), sn = Math.sin(s.aim);
            r.enemies.forEach(e => { if (e.dead) return; const dx = e.x - s.x, dy = e.y - (s.y - 9), d = Math.hypot(dx, dy); if (d < 66 && (dx * c + dy * sn) / (d || 1) > 0.35) dmgEnemy(e, 4.5 * dmgM, s.x, s.y, 25); });
            s.snd -= 1; if (s.snd <= 0) { s.snd = 2; Snd.sfx('flame'); }
          }
        }
      } else if (s.type === 'tower') {
        s.aura -= dt;
        if (s.aura <= 0) { s.aura = 0.3; const R = 72 + 6 * s.lvl; r.enemies.forEach(e => { if (!e.dead && d2(e.x, e.y, s.x, s.y) < R * R) { e.slow = 0.5; dmgEnemy(e, 1.2 * lm, s.x, s.y, 0); } }); }
      } else if (s.type === 'torch') {
        s.aura -= dt;
        if (s.aura <= 0) { s.aura = 0.5; r.enemies.forEach(e => { if (!e.dead && d2(e.x, e.y, s.x, s.y) < 38 * 38) dmgEnemy(e, 2.5, s.x, s.y, 20); }); }
      }
    }
  }

  function updateEnemies(r, dt, st) {
    const en = r.enemies, p = r.player, f = r.fire;
    for (let i = 0; i < en.length; i++) {
      const e = en[i]; if (e.dead) continue;
      e.anim += dt; e.hit = Math.max(0, e.hit - dt); e.cd -= dt; e.orb -= dt; if (e.slow > 0) e.slow -= dt;
      if (e.kx || e.ky) { e.x += e.kx * dt; e.y += e.ky * dt; const k = Math.pow(0.0006, dt); e.kx *= k; e.ky *= k; if (Math.abs(e.kx) + Math.abs(e.ky) < 2) { e.kx = 0; e.ky = 0; } }
      e.tt -= dt; if (e.tt <= 0 || !e.tgt || e.tgt.dead || (e.tgt.kind === 'p' && p.hp <= 0)) { e.tt = rand(0.35, 0.55); chooseTarget(e); }
      const tg = e.tgt, dx = tg.x - e.x, dy = tg.y - e.y, d = Math.hypot(dx, dy) || 1, reach = e.r + tg.r + 1;
      if (d > reach) {
        let sp = e.spd * (e.slow > 0 ? 0.5 : 1); if (e.type === 'bat') sp *= 1 + 0.4 * Math.sin(e.anim * 5 + e.ph);
        let vx = dx / d, vy = dy / d;
        if (e.type === 'bat') { const w = Math.sin(e.anim * 4 + e.ph) * 0.7; const nx = -vy, ny = vx; vx += nx * w; vy += ny * w; }
        e.x += vx * sp * dt; e.y += vy * sp * dt;
      } else if (e.cd <= 0) { e.cd = e.type === 'boss' ? 1.3 : 0.9; dmgTarget(tg, e.dmg, e); }
      if (e.type === 'boss') {
        e.sk -= dt; e.sm -= dt; const rage = e.hp < e.maxHp * 0.5;
        if (e.sk <= 0) {
          e.sk = rage ? 2.2 : 3.2; const n = rage ? 16 : 12, off = rand(0, TAU);
          for (let k = 0; k < n; k++) { const a = off + k * TAU / n; r.eprojs.push({ x: e.x, y: e.y - 18, vx: Math.cos(a) * 62, vy: Math.sin(a) * 62, dmg: 9 + r.night * 0.6, life: 6 }); }
          Snd.sfx('boss'); r.shake = Math.max(r.shake, 3);
        }
        if (e.sm <= 0) { e.sm = rage ? 7 : 10; for (let k = 0; k < 5 && en.length < 80; k++) { const t = pick(['slime', 'ghoul', 'bat']); spawnEnemy(t, e.x + rand(-30, 30), e.y + rand(-20, 20)); } burst(e.x, e.y - 10, '#b58cff', 20, 80, 0.7, 2, true); }
      }
      const fd = Math.hypot(e.x - f.x, e.y - f.y), fr = e.r + f.r - 2; if (fd < fr && fd > 0.01) { e.x += (e.x - f.x) / fd * (fr - fd); e.y += (e.y - f.y) / fd * (fr - fd); }
      if (e.type !== 'ghost') for (let k = 0; k < r.structs.length; k++) { const s = r.structs[k]; if (Math.abs(e.x - s.x) > 24 || Math.abs(e.y - s.y) > 24) continue; const sd = Math.hypot(e.x - s.x, e.y - s.y), sr = e.r + s.r - 1; if (sd < sr && sd > 0.01) { e.x += (e.x - s.x) / sd * (sr - sd); e.y += (e.y - s.y) / sd * (sr - sd); } }
      for (let k = i + 1; k < en.length; k++) { const o = en[k]; if (o.dead) continue; const ox = e.x - o.x, oy = e.y - o.y, rr = (e.r + o.r) * 0.8; if (Math.abs(ox) < rr && Math.abs(oy) < rr) { const od = Math.hypot(ox, oy) || 0.01; if (od < rr) { const push = (rr - od) * 0.5; e.x += ox / od * push; e.y += oy / od * push; o.x -= ox / od * push; o.y -= oy / od * push; } } }
      e.x = clamp(e.x, 4, WW - 4); e.y = clamp(e.y, 10, WH);
    }
  }

  function updateProjs(r, dt) {
    for (let i = r.projs.length - 1; i >= 0; i--) {
      const q = r.projs[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; let del = q.life <= 0;
      if (!del) for (let k = 0; k < r.enemies.length; k++) {
        const e = r.enemies[k]; if (e.dead || q.hit.indexOf(e) >= 0) continue;
        if (d2(q.x, q.y, e.x, e.y - e.r) < (e.r + 3) * (e.r + 3)) { q.hit.push(e); dmgEnemy(e, q.dmg, q.x - q.vx * 0.02, q.y - q.vy * 0.02, 100); burst(q.x, q.y, q.col, 3, 40, 0.25, 1, true); if (q.pierce-- <= 0) { del = true; break; } }
      }
      if (del) { r.projs[i] = r.projs[r.projs.length - 1]; r.projs.pop(); }
    }
    for (let i = r.shells.length - 1; i >= 0; i--) {
      const s = r.shells[i]; s.t += dt; const k = Math.min(1, s.t / s.T);
      s.x = s.sx + (s.tx - s.sx) * k; s.y = s.sy + (s.ty - s.sy) * k;
      if (k >= 1) {
        r.rings.push({ x: s.tx, y: s.ty, r: 4, max: s.R, life: 0.4 }); Snd.sfx('boom'); r.shake = Math.max(r.shake, 2.2);
        burst(s.tx, s.ty - 4, '#ffb23a', 16, 90, 0.6, 2, true); burst(s.tx, s.ty - 4, '#6b7385', 8, 60, 0.7, 2, false);
        r.enemies.forEach(e => { if (!e.dead) { const d = Math.sqrt(d2(e.x, e.y, s.tx, s.ty)); if (d < s.R + e.r) dmgEnemy(e, s.dmg * (d < s.R * 0.5 ? 1 : 0.65), s.tx, s.ty, 160); } });
        r.shells.splice(i, 1);
      }
    }
    for (let i = r.eprojs.length - 1; i >= 0; i--) {
      const q = r.eprojs[i]; q.life -= dt; q.x += q.vx * dt; q.y += q.vy * dt; let del = q.life <= 0 || q.x < -10 || q.x > WW + 10 || q.y < -10 || q.y > WH + 10;
      if (!del) {
        const p = r.player, f = r.fire;
        if (d2(q.x, q.y, p.x, p.y - 7) < 7 * 7) { hurtPlayer(q.dmg); del = true; }
        else if (d2(q.x, q.y, f.x, f.y - 4) < 13 * 13) { hurtFire(q.dmg * 0.8); del = true; }
        else for (let k = 0; k < r.structs.length; k++) { const s = r.structs[k]; if (d2(q.x, q.y, s.x, s.y - 6) < (s.r + 3) * (s.r + 3)) { hurtStruct(s, q.dmg); del = true; break; } }
        if (del) burst(q.x, q.y, '#b58cff', 4, 50, 0.3, 1, true);
      }
      if (del) { r.eprojs[i] = r.eprojs[r.eprojs.length - 1]; r.eprojs.pop(); }
    }
    for (let i = r.nodes.length - 1; i >= 0; i--) { const n = r.nodes[i]; if (n.shake > 0) n.shake -= dt; }
  }

  // ================= отрисовка =================
  const groundPat = ctx.createPattern(SPR.ground, 'repeat');
  const borderTrees = [];
  (function () {
    for (let x = -12; x <= WW + 12; x += 13) { borderTrees.push({ x: x + rand(-4, 4), y: rand(4, 16), v: rint(0, 2) }); borderTrees.push({ x: x + rand(-4, 4), y: WH + rand(10, 24), v: rint(0, 2) }); }
    for (let y = 8; y <= WH + 20; y += 13) { borderTrees.push({ x: rand(-6, 8), y: y, v: rint(0, 2) }); borderTrees.push({ x: WW + rand(-8, 6), y: y, v: rint(0, 2) }); }
  })();

  function spr(S, x, y, flash, alpha) {
    if (alpha !== undefined && alpha < 1) ctx.globalAlpha = alpha;
    ctx.drawImage(flash ? S.wc : S.c, Math.round(x - S.w / 2), Math.round(y - S.h));
    if (alpha !== undefined && alpha < 1) ctx.globalAlpha = 1;
  }
  function shadow(x, y, w) {
    x = Math.round(x); y = Math.round(y); ctx.fillStyle = 'rgba(0,0,0,.30)';
    ctx.fillRect(x - w / 2 + 2, y - 1, w - 4, 1); ctx.fillRect(x - w / 2, y, w, 2); ctx.fillRect(x - w / 2 + 2, y + 2, w - 4, 1);
  }
  function hpBar(x, y, w, frac, col) {
    x = Math.round(x - w / 2); y = Math.round(y); ctx.fillStyle = '#000'; ctx.fillRect(x - 1, y - 1, w + 2, 4); ctx.fillStyle = '#3a1218'; ctx.fillRect(x, y, w, 2); ctx.fillStyle = col; ctx.fillRect(x, y, Math.max(1, Math.round(w * clamp(frac, 0, 1))), 2);
  }
  function flame(x, y, sc, t, seed) {
    const cols = ['#d63a12', '#ff7a1a', '#ffc23a', '#fff1a8'];
    for (let l = 0; l < 4; l++) {
      const h = Math.round((13 - l * 2.6) * sc * (0.85 + 0.15 * Math.sin(t * 17 + l * 1.7 + seed))), w = (9 - l * 2) * sc;
      ctx.fillStyle = cols[l];
      for (let i = 0; i < h; i++) {
        const k = i / h, rw = Math.max(1, Math.round(w * (1 - k * k) * (0.72 + 0.28 * Math.sin(t * 12 + i * 0.4 + seed)))), sway = Math.round(Math.sin(t * 8 + i * 0.35 + seed) * 1.4 * k * sc);
        ctx.fillRect(Math.round(x - rw / 2 + sway), Math.round(y - i - 1 - l * 0.5), rw, 1);
      }
    }
  }
  function line(x0, y0, x1, y1, col, th) {
    x0 = Math.round(x0); y0 = Math.round(y0); x1 = Math.round(x1); y1 = Math.round(y1);
    const n = Math.max(Math.abs(x1 - x0), Math.abs(y1 - y0), 1); ctx.fillStyle = col;
    for (let i = 0; i <= n; i++) ctx.fillRect(Math.round(x0 + (x1 - x0) * i / n), Math.round(y0 + (y1 - y0) * i / n), th || 1, th || 1);
  }
  function ring(x, y, rx, ry, col, n) {
    ctx.fillStyle = col; n = n || Math.max(20, Math.round(rx * 1.2));
    for (let i = 0; i < n; i++) { const a = i / n * TAU; ctx.fillRect(Math.round(x + Math.cos(a) * rx), Math.round(y + Math.sin(a) * ry), 1, 1); }
  }

  const dl = [];
  function render() {
    const r = run || scene; ctx.imageSmoothingEnabled = false;
    if (!r) { ctx.fillStyle = '#05070f'; ctx.fillRect(0, 0, W, H); return; }
    if (!run) { r.time += 1 / 60; }
    if (run) {
      const p = r.player, k = 0.12;
      cam.x += (clamp(p.x - W / 2, 0, WW - W) - cam.x) * k; cam.y += (clamp(p.y - 6 - H / 2, 0, WH - H) - cam.y) * k;
    } else { cam.x = CX - W * 0.7; cam.y = CY - H * 0.62; }
    let shx = 0, shy = 0; if (r.shake > 0) { shx = (Math.random() - 0.5) * r.shake; shy = (Math.random() - 0.5) * r.shake; }
    const cx = Math.round(cam.x + shx), cy = Math.round(cam.y + shy);
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    ctx.fillStyle = '#080c18'; ctx.fillRect(0, 0, W, H);
    // земля и биомы
    ctx.save(); ctx.translate(-cx, -cy);
    const gx0 = Math.max(0, cx), gy0 = Math.max(0, cy), gx1 = Math.min(WW, cx + W), gy1 = Math.min(WH, cy + H);
    if (gx1 > gx0 && gy1 > gy0) {
      ctx.beginPath(); ctx.rect(gx0, gy0, gx1 - gx0, gy1 - gy0); ctx.clip();
      ctx.fillStyle = groundPat; ctx.fillRect(gx0, gy0, gx1 - gx0, gy1 - gy0);
      for (let i = 0; i < BIOMES.length; i++) { const b = BIOMES[i], bc = blobs[i], bx = Math.round(b.x - bc.width / 2), by = Math.round(b.y - bc.height / 2); if (bx < cx + W && bx + bc.width > cx && by < cy + H && by + bc.height > cy) ctx.drawImage(bc, bx, by); }
      ctx.drawImage(SPR.dirt, CX - 60, CY - 36 + 4);
    }
    ctx.restore();
    // отсортированный список
    dl.length = 0;
    const vx0 = cx - 30, vx1 = cx + W + 30, vy0 = cy - 20, vy1 = cy + H + 70;
    borderTrees.forEach(b => { if (b.x > vx0 && b.x < vx1 && b.y > vy0 - 20 && b.y < vy1 + 40) dl.push({ y: b.y, k: 5, o: b }); });
    r.nodes.forEach(n => { if (n.x > vx0 && n.x < vx1 && n.y > vy0 && n.y < vy1) dl.push({ y: n.y, k: 0, o: n }); });
    r.ruins.forEach(u => { if (u.x > vx0 - 20 && u.x < vx1 + 20 && u.y > vy0 && u.y < vy1) dl.push({ y: u.y, k: 6, o: u }); });
    r.structs.forEach(s => { if (s.x > vx0 && s.x < vx1 && s.y > vy0 && s.y < vy1) dl.push({ y: s.y, k: 1, o: s }); });
    r.enemies.forEach(e => { if (e.x > vx0 && e.x < vx1 && e.y > vy0 && e.y < vy1) dl.push({ y: e.y, k: 2, o: e }); });
    dl.push({ y: r.player.y, k: 3, o: r.player }); dl.push({ y: r.fire.y, k: 4, o: r.fire });
    dl.sort((a, b) => a.y - b.y);
    for (let i = 0; i < dl.length; i++) {
      const it = dl[i], o = it.o, sx = o.x - cx, sy = o.y - cy;
      switch (it.k) {
        case 5: spr(SPR.tree[o.v], sx, sy, false); break;
        case 0: {
          const shk = o.shake > 0 ? Math.round(Math.sin(o.shake * 90) * 1.4) : 0;
          if (o.type === 'tree') { shadow(sx, sy, 16); spr(SPR.tree[o.v], sx + shk, sy, false); }
          else if (o.type === 'rock') { shadow(sx, sy, 16); spr(SPR.rock[o.v], sx + shk, sy, false); }
          else { shadow(sx, sy, 14); spr(SPR.crystal[0], sx + shk, sy, false); }
          if (o.hp < o.maxHp) hpBar(sx, sy + 2, 12, o.hp / o.maxHp, '#ffd166');
          break;
        }
        case 6: drawRuin(o, sx, sy); break;
        case 1: drawStruct(r, o, sx, sy, r.time); break;
        case 2: drawEnemy(o, sx, sy); break;
        case 3: drawPlayer(r, o, sx, sy); break;
        case 4: drawFire(r, o, sx, sy, r.time); break;
      }
    }
    // снаряды и эффекты
    ctx.globalCompositeOperation = 'lighter';
    r.projs.forEach(q => {
      const x = Math.round(q.x - cx), y = Math.round(q.y - cy);
      if (q.big) { line(x - q.vx * 0.032, y - q.vy * 0.032, x, y, '#e8d8a8', 2); ctx.fillStyle = '#fff'; ctx.fillRect(x - 1, y - 1, 3, 3); return; }
      ctx.fillStyle = q.col;
      ctx.globalAlpha = 0.35; ctx.fillRect(Math.round(x - q.vx * 0.03) - 1, Math.round(y - q.vy * 0.03) - 1, 3, 3); ctx.fillRect(Math.round(x - q.vx * 0.06) - 1, Math.round(y - q.vy * 0.06), 2, 2);
      ctx.globalAlpha = 1; ctx.fillRect(x - 1, y - 1, 3, 3); ctx.fillStyle = '#fff'; ctx.fillRect(x, y, 1, 1);
    });
    r.eprojs.forEach(q => { const x = Math.round(q.x - cx), y = Math.round(q.y - cy); ctx.fillStyle = '#b36bff'; ctx.fillRect(x - 2, y - 2, 4, 4); ctx.fillStyle = '#fff'; ctx.fillRect(x - 1, y - 1, 2, 2); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // снаряды мортиры (дуга + тень цели)
    r.shells.forEach(s => {
      const k = Math.min(1, s.t / s.T), h = Math.sin(k * Math.PI) * 46, x = Math.round(s.x - cx), y = Math.round(s.y - cy - h);
      ctx.fillStyle = 'rgba(0,0,0,.35)'; ctx.fillRect(x - 2, Math.round(s.y - cy), 5, 2);
      ring(Math.round(s.tx - cx), Math.round(s.ty - cy), s.R * 0.9, s.R * 0.7, 'rgba(255,140,60,' + (0.35 + 0.4 * k).toFixed(2) + ')', 26);
      ctx.fillStyle = '#22262e'; ctx.fillRect(x - 2, y - 2, 4, 4); ctx.fillStyle = '#ff9a3a'; ctx.fillRect(x - 1, y - 1, 2, 2);
    });
    ctx.globalCompositeOperation = 'lighter';
    r.bolts.forEach(b => { for (let i = 0; i < b.pts.length - 1; i++) { line(b.pts[i][0] - cx, b.pts[i][1] - cy, b.pts[i + 1][0] - cx, b.pts[i + 1][1] - cy, '#7fd4ff', 2); line(b.pts[i][0] - cx, b.pts[i][1] - cy, b.pts[i + 1][0] - cx, b.pts[i + 1][1] - cy, '#fff', 1); } });
    r.rings.forEach(g => { ctx.globalAlpha = clamp(g.life / 0.45, 0, 1); ctx.fillStyle = '#ffb23a'; const n = Math.max(24, Math.round(g.r * 1.2)); for (let i = 0; i < n; i++) { const a = i / n * TAU; ctx.fillRect(Math.round(g.x - cx + Math.cos(a) * g.r), Math.round(g.y - cy + Math.sin(a) * g.r * 0.8), 2, 2); } ctx.globalAlpha = 1; });
    if (run && r.up.orbit) { const n = r.up.orbit + 1, p = r.player; for (let k = 0; k < n; k++) { const a = r.orbA + k * TAU / n, ox = Math.round(p.x - cx + Math.cos(a) * 27), oy = Math.round(p.y - 7 - cy + Math.sin(a) * 21.6); ctx.fillStyle = '#ff8a2a'; ctx.fillRect(ox - 2, oy - 2, 5, 5); ctx.fillStyle = '#ffe08a'; ctx.fillRect(ox - 1, oy - 1, 3, 3); ctx.fillStyle = '#fff'; ctx.fillRect(ox, oy, 1, 1); } }
    r.parts.forEach(p => { ctx.globalCompositeOperation = p.add ? 'lighter' : 'source-over'; ctx.globalAlpha = clamp(p.life / p.max * 1.4, 0, 1); ctx.fillStyle = p.col; ctx.fillRect(Math.round(p.x - cx), Math.round(p.y - cy), p.size, p.size); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // выбранная постройка
    if (run && r.sel && !r.sel.dead) { const s = r.sel; ctx.globalCompositeOperation = 'lighter'; ring(Math.round(s.x - cx), Math.round(s.y - cy - 2), 12, 6, '#8ff7ff', 24); ctx.globalCompositeOperation = 'source-over'; }
    // светлячки
    ctx.globalCompositeOperation = 'lighter';
    r.flies.forEach(fl => { const x = fl.x - cx, y = fl.y - cy; if (x < -4 || x > W + 4 || y < -4 || y > H + 4) return; const a = 0.4 + 0.6 * Math.abs(Math.sin(fl.ph * 2)); ctx.globalAlpha = a; ctx.fillStyle = '#d6ff7a'; ctx.fillRect(Math.round(x), Math.round(y), 1, 1); ctx.globalAlpha = a * 0.3; ctx.fillRect(Math.round(x) - 1, Math.round(y) - 1, 3, 3); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    // освещение
    const dk = darkness(r); r.dark = dk;
    const LS = [];
    const fl = 0.92 + 0.06 * Math.sin(r.time * 13) + 0.04 * Math.sin(r.time * 31.7);
    LS.push([r.fire.x, r.fire.y - 6, (95 + r.fire.level * 15) * fl, 1, 'w']);
    LS.push([r.player.x, r.player.y - 8, 44, 0.9, 'w']);
    r.structs.forEach(s => {
      if (s.type === 'torch') LS.push([s.x, s.y - 14, 66 * (0.93 + 0.07 * Math.sin(r.time * 14 + s.x)), 1, 'w']);
      else if (s.type === 'tower') LS.push([s.x, s.y - 22, 54, 0.9, 'c']);
      else if (s.type === 'flamer' && s.on) LS.push([s.x, s.y - 10, 60, 0.9, 'w']);
      else if (s.type === 'turret' || s.type === 'ballista') LS.push([s.x, s.y - 14, 30, 0.8, 'c']);
      else if (s.type === 'cwall') LS.push([s.x, s.y - 12, 22, 0.7, 'c']);
    });
    r.nodes.forEach(n => { if (n.type === 'crystal' && n.x > vx0 && n.x < vx1 && n.y > vy0 && n.y < vy1) LS.push([n.x, n.y - 10, 26, 0.8, 'c']); });
    r.ruins.forEach(u => { if (!u.opened && u.x > vx0 && u.x < vx1 && u.y > vy0 && u.y < vy1) LS.push([u.x, u.y - 6, 26, 0.8, 'w']); });
    r.projs.forEach(q => LS.push([q.x, q.y, 15, 0.8, q.own === 't' ? 'c' : 'w']));
    r.shells.forEach(s => LS.push([s.x, s.y - Math.sin(Math.min(1, s.t / s.T) * Math.PI) * 46, 24, 0.8, 'w']));
    r.enemies.forEach(e => { if (e.type === 'boss') LS.push([e.x, e.y - 20, 55, 0.7, 'p']); else if (e.type === 'ghost') LS.push([e.x, e.y - 8, 20, 0.5, 'c']); });
    if (run && r.up.orbit) { const n = r.up.orbit + 1, p = r.player; for (let k = 0; k < n; k++) { const a = r.orbA + k * TAU / n; LS.push([p.x + Math.cos(a) * 27, p.y - 7 + Math.sin(a) * 21.6, 20, 0.7, 'w']); } }
    r.bolts.forEach(b => b.pts.forEach(p => LS.push([p[0], p[1], 28, 0.7, 'c'])));
    r.rings.forEach(g => LS.push([g.x, g.y, g.r + 20, 0.5, 'w']));
    if (dk > 0.01) {
      const col = dk < 0.5 ? mix([255, 130, 70], [60, 40, 95], dk * 2) : mix([60, 40, 95], [7, 10, 40], (dk - 0.5) * 2), al = 0.86 * Math.pow(dk, 0.9);
      lctx.globalCompositeOperation = 'source-over'; lctx.globalAlpha = 1; lctx.clearRect(0, 0, W, H);
      lctx.fillStyle = 'rgba(' + col + ',' + al + ')'; lctx.fillRect(0, 0, W, H);
      lctx.globalCompositeOperation = 'destination-out';
      LS.forEach(l => { const rr = l[2], x = l[0] - cx, y = l[1] - cy; if (x + rr < 0 || x - rr > W || y + rr < 0 || y - rr > H) return; lctx.globalAlpha = l[3]; lctx.drawImage(SPR.cut, x - rr, y - rr, rr * 2, rr * 2); });
      lctx.globalAlpha = 1; lctx.globalCompositeOperation = 'source-over';
      ctx.drawImage(lc, 0, 0);
    }
    ctx.globalCompositeOperation = 'lighter'; const ga = 0.25 + 0.75 * dk;
    LS.forEach(l => { const rr = l[2] * 1.05, x = l[0] - cx, y = l[1] - cy; if (x + rr < 0 || x - rr > W || y + rr < 0 || y - rr > H) return; ctx.globalAlpha = l[3] * ga * 0.85; ctx.drawImage(l[4] === 'w' ? SPR.warm : l[4] === 'c' ? SPR.cool : SPR.purple, x - rr, y - rr, rr * 2, rr * 2); });
    ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over';
    const vg = ctx.createRadialGradient(W / 2, H / 2, H * 0.55, W / 2, H / 2, H * 1.05); vg.addColorStop(0, 'rgba(0,0,0,0)'); vg.addColorStop(1, 'rgba(0,0,0,0.45)'); ctx.fillStyle = vg; ctx.fillRect(0, 0, W, H);
    if (run && !r.over) {
      const fx = r.fire.x - cx, fy = r.fire.y - cy;
      if (fx < 8 || fx > W - 8 || fy < 8 || fy > H - 8) {
        const a = Math.atan2(fy - H / 2, fx - W / 2), ex = clamp(W / 2 + Math.cos(a) * W, 14, W - 14), ey = clamp(H / 2 + Math.sin(a) * H, 40, H - 40);
        ctx.fillStyle = '#000'; ctx.fillRect(Math.round(ex) - 5, Math.round(ey) - 5, 11, 11); ctx.fillStyle = '#ffb23a'; ctx.fillRect(Math.round(ex) - 4, Math.round(ey) - 4, 9, 9); ctx.fillStyle = '#ff6a1a'; ctx.fillRect(Math.round(ex) - 2, Math.round(ey) - 2, 5, 5);
        for (let i = 1; i <= 3; i++) { ctx.fillStyle = '#fff'; ctx.fillRect(Math.round(ex + Math.cos(a) * (5 + i * 2)) - 1, Math.round(ey + Math.sin(a) * (5 + i * 2)) - 1, 2, 2); }
      }
    }
  }
  function mix(a, b, t) { return Math.round(a[0] + (b[0] - a[0]) * t) + ',' + Math.round(a[1] + (b[1] - a[1]) * t) + ',' + Math.round(a[2] + (b[2] - a[2]) * t); }

  function drawFire(r, f, x, y, t) {
    shadow(x, y + 1, 24);
    spr(SPR.logs[0], x, y + 6, f.flash > 0);
    flame(x, y + 1, 0.8 + f.level * 0.2, t, 0);
    if (f.level >= 3) { flame(x - 6, y + 2, 0.5, t, 2); flame(x + 6, y + 2, 0.5, t, 4); }
  }
  function drawRuin(u, x, y) {
    x = Math.round(x); y = Math.round(y);
    spr(SPR.pillar[0], x - 15, y - 3); spr(SPR.pillar[1], x + 15, y - 1);
    spr(SPR.chest[u.opened ? 1 : 0], x, y + 2);
    spr(SPR.rubble[0], x - 2, y + 8);
    if (!u.opened && u.prog > 0) hpBar(x, y - 14, 14, u.prog / 0.9, '#ffd447');
  }
  function drawStruct(r, s, x, y, t) {
    const def = SD[s.type], S = SPR[def.spr][0];
    shadow(x, y, def.r > 7 ? 18 : 15);
    spr(S, x, y + 1, s.flash > 0);
    if (s.type === 'turret' || s.type === 'ballista') {
      const a = s.aim, bx = x, by = y - (s.type === 'turret' ? 12 : 9); ctx.fillStyle = s.type === 'turret' ? '#d8f6ff' : '#f3e6b8';
      for (let k = 1; k <= 3; k++) ctx.fillRect(Math.round(bx + Math.cos(a) * k * 2.4) - 1, Math.round(by + Math.sin(a) * k * 2.4) - 1, 2, 2);
      if (s.muz > 0) { ctx.fillStyle = '#fff'; ctx.fillRect(Math.round(bx + Math.cos(a) * 11) - 1, Math.round(by + Math.sin(a) * 11) - 1, 3, 3); }
    } else if (s.type === 'mortar' && s.muz > 0) { ctx.fillStyle = '#fff6c8'; ctx.fillRect(x - 3, y - 18, 6, 3); ctx.fillStyle = '#ffb23a'; ctx.fillRect(x - 2, y - 21, 4, 3); }
    else if (s.type === 'flamer') {
      const a = s.aim; ctx.fillStyle = '#ff9a3a'; ctx.fillRect(Math.round(x + Math.cos(a) * 8), Math.round(y - 9 + Math.sin(a) * 8), 2, 2);
      if (!s.on) { ctx.fillStyle = Math.sin(t * 10) > 0 ? '#ffd54a' : '#ff7a1a'; ctx.fillRect(x + 6, y - 9, 1, 1); }
    } else if (s.type === 'torch') flame(x, y - 16, 0.55, t, s.x);
    else if (s.type === 'tower') { const R = (72 + 6 * s.lvl) * (0.55 + 0.45 * ((t * 0.8) % 1)); ctx.globalCompositeOperation = 'lighter'; ctx.globalAlpha = 0.5 * (1 - ((t * 0.8) % 1)); ring(x, y - 2, R, R * 0.5, '#6fe3ff', 36); ctx.globalAlpha = 1; ctx.globalCompositeOperation = 'source-over'; }
    for (let i = 1; i < s.lvl; i++) { ctx.fillStyle = '#000'; ctx.fillRect(Math.round(x) - 4 + (i - 1) * 5, Math.round(y - S.h) - 3, 4, 4); ctx.fillStyle = '#ffd447'; ctx.fillRect(Math.round(x) - 3 + (i - 1) * 5, Math.round(y - S.h) - 2, 2, 2); }
    if (s.hp < s.max) hpBar(x, y + 3, 12, s.hp / s.max, '#7dff8f');
  }
  function drawEnemy(e, x, y) {
    const fr = Math.floor(e.anim * 5) % 2, fl = e.hit > 0;
    if (e.type === 'bat') { const oy = 9 + Math.sin(e.anim * 6 + e.ph) * 2; shadow(x, y, 8); spr(SPR.bat[Math.floor(e.anim * 12) % 2], x, y - oy + 8, fl); }
    else if (e.type === 'ghost') { const oy = 4 + Math.sin(e.anim * 3 + e.ph) * 2; shadow(x, y, 9); spr(SPR.ghost[fr], x, y - oy + 6, fl, 0.82); }
    else if (e.type === 'slime') { shadow(x, y, 12); spr(SPR.slime[fr], x, y + 1, fl); }
    else if (e.type === 'ghoul') { shadow(x, y, 12); spr(SPR.ghoul[fr], x, y + 1 - (fr ? 1 : 0), fl); }
    else if (e.type === 'brute') { shadow(x, y, 22); spr(SPR.brute[fr], x, y + 2 - (fr ? 1 : 0), fl); }
    else if (e.type === 'boss') {
      shadow(x, y, 38); const rage = e.hp < e.maxHp * 0.5; spr(SPR.boss[fr], x, y + 3 - (fr ? 2 : 0), fl);
      const hy = Math.round(y - 47 - (fr ? 2 : 0)); ctx.fillStyle = '#ffd447'; ctx.fillRect(Math.round(x) - 8, hy, 16, 3); for (let i = 0; i < 4; i++) ctx.fillRect(Math.round(x) - 8 + i * 5, hy - 3, 3, 3);
      if (rage) { ctx.fillStyle = '#ff3b3b'; ctx.fillRect(Math.round(x) - 7, Math.round(y - 33), 4, 3); ctx.fillRect(Math.round(x) + 3, Math.round(y - 33), 4, 3); }
    }
    if (e.slow > 0) { ctx.fillStyle = '#6fe3ff'; ctx.fillRect(Math.round(x) - 1, Math.round(y) + 3, 3, 1); }
    if (e.hp < e.maxHp && e.type !== 'boss') hpBar(x, y - (e.type === 'brute' ? 34 : e.type === 'bat' ? 20 : e.type === 'ghost' ? 22 : 20), e.type === 'brute' ? 20 : 12, e.hp / e.maxHp, '#ff5a5f');
  }
  function drawPlayer(r, p, x, y) {
    shadow(x, y, 12);
    const S = SPR.hero[r.heroId], fr = p.moving ? Math.floor(p.anim * 9) % 2 : 0, bob = p.moving ? (fr ? 1 : 0) : (Math.sin(r.time * 3) > 0.7 ? 1 : 0);
    if (p.inv > 0 && Math.floor(p.inv * 20) % 2 === 0 && !r.over) return;
    if (r.over) { ctx.globalAlpha = 0.5; }
    spr(S[fr], x, y + 1 - bob, false); ctx.globalAlpha = 1;
    if (p.swing > 0) { const a = Math.atan2(p.fy, p.fx) + (p.swing / 0.18 - 0.5) * 2; ctx.fillStyle = '#fff6c8'; for (let k = 1; k <= 3; k++) ctx.fillRect(Math.round(x + Math.cos(a) * (6 + k * 2)) - 1, Math.round(y - 8 + Math.sin(a) * (6 + k * 2)) - 1, 2, 2); }
  }

  // ================= ввод =================
  const stage = $('#stage'), joy = $('#joy'), knob = joy.querySelector('i');
  let jid = null, jx = 0, jy = 0, jt0 = 0, jsx = 0, jsy = 0, jmoved = 0;
  function remPx() { return parseFloat(getComputedStyle(document.documentElement).fontSize) || 14; }
  function handleTap(px, py) {
    if (!run || run.over) return;
    const wx = px / SC + Math.round(cam.x), wy = py / SC + Math.round(cam.y);
    let best = null, bd = 15 * 15;
    run.structs.forEach(s => { const d = d2(wx, wy, s.x, s.y - 7); if (d < bd) { bd = d; best = s; } });
    if (best) showSel(best); else { closePop(); hideSel(); }
  }
  stage.addEventListener('pointerdown', e => {
    if (state !== 'play' || modalOpen || paused || jid !== null) return;
    e.preventDefault(); try { stage.setPointerCapture(e.pointerId); } catch (_) { }
    jid = e.pointerId; jx = e.clientX; jy = e.clientY; jsx = jx; jsy = jy; jt0 = Date.now(); jmoved = 0;
    joy.style.display = 'block'; joy.style.left = jx + 'px'; joy.style.top = jy + 'px'; knob.style.transform = 'translate(0,0)';
  });
  stage.addEventListener('pointermove', e => {
    if (e.pointerId !== jid) return;
    jmoved = Math.max(jmoved, Math.hypot(e.clientX - jsx, e.clientY - jsy));
    let dx = e.clientX - jx, dy = e.clientY - jy; const R = remPx() * 2.6, m = Math.hypot(dx, dy);
    if (m > R) { dx = dx / m * R; dy = dy / m * R; }
    input.x = dx / R; input.y = dy / R; knob.style.transform = 'translate(' + dx + 'px,' + dy + 'px)';
    if (m > R * 1.6) { jx += (e.clientX - jx) * 0.25; jy += (e.clientY - jy) * 0.25; joy.style.left = jx + 'px'; joy.style.top = jy + 'px'; }
  });
  function endJoy(e) {
    if (e.pointerId !== jid) return; jid = null; input.x = 0; input.y = 0; joy.style.display = 'none';
    if (e.type === 'pointerup' && Date.now() - jt0 < 350 && jmoved < 14 && state === 'play' && !modalOpen && !paused) handleTap(e.clientX, e.clientY);
  }
  stage.addEventListener('pointerup', endJoy); stage.addEventListener('pointercancel', endJoy);
  const keys = {};
  function keyUpd() { input.kx = (keys.d || keys.arrowright ? 1 : 0) - (keys.a || keys.arrowleft ? 1 : 0); input.ky = (keys.s || keys.arrowdown ? 1 : 0) - (keys.w || keys.arrowup ? 1 : 0); }
  window.addEventListener('keydown', e => {
    const k = e.key.toLowerCase(); keys[k] = true; keyUpd(); Snd.init();
    if (state === 'play' && run && !run.over) {
      if (k === 'p' || k === 'escape') { modalOpen ? null : showPause(); }
      const hot = { '1': 'wall', '2': 'stone', '3': 'turret', '4': 'ballista', '5': 'mortar', '6': 'flamer', '7': 'torch', '8': 'tower', '9': 'repair', '0': 'fire' };
      if (hot[k]) doBuild(hot[k]);
      if (k === 'n' && run.phase === 'day') run.t = run.dayLen;
    }
  });
  window.addEventListener('keyup', e => { keys[e.key.toLowerCase()] = false; keyUpd(); });
  window.addEventListener('contextmenu', e => e.preventDefault());

  // ================= кнопки меню =================
  function firstGesture() { Snd.setOn(save.sound); Snd.init(); }
  window.addEventListener('pointerdown', firstGesture, { passive: true });
  $('#splash').addEventListener('pointerdown', () => { if (state !== 'splash') return; if ($('#splash').dataset.t < 1) return; firstGesture(); showMenu(); });
  $('#splash').dataset.t = 0; setTimeout(() => { $('#splash').dataset.t = 1; }, 1800);
  $('#bPlay').onclick = () => { firstGesture(); Snd.sfx('click'); showSlots(); };
  $('#bHeroes').onclick = () => { Snd.sfx('click'); showHeroes(); };
  $('#bAbout').onclick = () => { Snd.sfx('click'); showAbout(); };
  $('#bSound').onclick = () => { save.sound = !save.sound; Snd.setOn(save.sound); persist(); $('#bSound').textContent = 'Звук: ' + (save.sound ? 'вкл' : 'выкл'); Snd.sfx('click'); };

  // ================= главный цикл =================
  let last = performance.now();
  function frame(now) {
    let dt = (now - last) / 1000; last = now; if (dt > 0.05) dt = 0.05; if (dt < 0) dt = 0;
    try {
      if (state === 'play' && run && !paused && !modalOpen) update(dt);
      else if (state === 'play' && run && (paused || modalOpen)) { /* заморозка */ }
      else if (scene) { scene.time += dt; updateAmbient(scene, dt); }
      if (state === 'splash') { /* фон не нужен */ } else render();
    } catch (err) { console.error(err); }
    requestAnimationFrame(frame);
  }
  scene = newRun('hunter'); run = null; scene.dkOverride = 0.78; scene.player.x = CX + 30; scene.player.y = CY + 30;
  requestAnimationFrame(frame);

  window.__dbg = {
    run: () => run, scene: () => scene, step: dt => { if (run) update(dt); }, render: render, state: () => state,
    startNight: () => { if (run) { run.t = run.dayLen; } }, giveRes: n => { if (run) { run.res.wood += n; run.res.stone += n; run.res.crystal += n; updateHud(); } },
    build: doBuild, save: save, endNight: () => { if (run && run.phase === 'night') { run.t = run.nightLen; } }, setNight: n => { if (run) run.night = n; },
    saveNow: saveNow, serialize: () => serialize(run), readSlot: readSlot, loadSlot: loadSlot, startRun: startRun, showSlots: showSlots, showMenu: showMenu, saveAndExit: saveAndExit,
    sel: s => { if (run) showSel(s); }, upgrade: s => upgradeStruct(s), WW: WW, WH: WH
  };
})();
