'use strict';
/* Nyxvault — «Последний костёр». Пиксель-арт, нарисованный кодом (без картинок). */
const SPR = (function () {
  function mk(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; }
  function mulberry(a) { return function () { a |= 0; a = a + 0x6D2B79F5 | 0; let t = Math.imul(a ^ a >>> 15, 1 | a); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; }; }

  function grid(rows, pal, scale) {
    scale = scale || 1;
    const h = rows.length, w = rows[0].length, c = mk(w * scale, h * scale), x = c.getContext('2d');
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const ch = rows[j][i]; if (ch === '.' || ch === ' ') continue;
      const col = pal[ch]; if (!col) continue;
      x.fillStyle = col; x.fillRect(i * scale, j * scale, scale, scale);
    }
    return c;
  }

  // добавляет тёмный контур в 1 пиксель и делает белую «вспышку» для попаданий
  function finish(c, outline) {
    outline = outline || '#0e1120';
    const w = c.width, h = c.height, o = mk(w + 2, h + 2), x = o.getContext('2d');
    const sil = mk(w, h), sx = sil.getContext('2d');
    sx.drawImage(c, 0, 0); sx.globalCompositeOperation = 'source-in'; sx.fillStyle = outline; sx.fillRect(0, 0, w, h);
    [[0, 1], [2, 1], [1, 0], [1, 2]].forEach(d => x.drawImage(sil, d[0], d[1]));
    x.drawImage(c, 1, 1);
    const wc = mk(w + 2, h + 2), wx = wc.getContext('2d');
    wx.drawImage(o, 0, 0); wx.globalCompositeOperation = 'source-in'; wx.fillStyle = '#fff'; wx.fillRect(0, 0, w + 2, h + 2);
    return { c: o, wc: wc, w: w + 2, h: h + 2 };
  }

  // ---------- герои (спереди) ----------
  const HERO_A = [
    '....hhhh....',
    '...hHHHHh...',
    '..hHHHHHHh..',
    '..hHssssHh..',
    '..hsessesh..',
    '...ssssss...',
    '..cccccccc..',
    '.scccbbcccs.',
    '.sccccccccs.',
    '..ccbbbbcc..',
    '..cccccccc..',
    '...pppppp...',
    '...pp..pp...',
    '...pp..pp...',
    '..kkk..kkk..',
    '..kkk..kkk..'];
  const HERO_B = HERO_A.slice(0, 12).concat([
    '....pppp....',
    '....pppp....',
    '...kkkkkk...',
    '...kkkkkk...']);
  const HERO_PAL = {
    hunter: { h: '#2b5e3a', H: '#4c9b57', s: '#f1c08a', e: '#1a1a2e', c: '#8a5a32', b: '#e0b45e', p: '#3b3350', k: '#241a14' },
    mage: { h: '#5b2d8a', H: '#8a52c8', s: '#f1c08a', e: '#1a1a2e', c: '#3a4fa8', b: '#ffd166', p: '#2a2a55', k: '#1a1a33' },
    robot: { h: '#6b7a8f', H: '#a3b3c8', s: '#8fa0b5', e: '#37f3ff', c: '#4b5668', b: '#ff9d3a', p: '#39424f', k: '#20242c' }
  };

  const out = { hero: {} };
  Object.keys(HERO_PAL).forEach(k => {
    out.hero[k] = [finish(grid(HERO_A, HERO_PAL[k])), finish(grid(HERO_B, HERO_PAL[k]))];
  });

  // ---------- враги ----------
  out.slime = [finish(grid([
    '....gggg....',
    '..ggGGGGgg..',
    '.ggGGGGGGgg.',
    '.gGGeGGeGGg.',
    'ggGGGGGGGGgg',
    'ggGGGmmGGGgg',
    'ggGGGGGGGGgg',
    '.gggggggggg.'], { g: '#2f8f4a', G: '#63d36f', e: '#10241a', m: '#10241a' })),
  finish(grid([
    '............',
    '....gggg....',
    '..ggGGGGgg..',
    '.gGGeGGeGGg.',
    'gGGGGGGGGGGg',
    'gGGGGmmGGGGg',
    'ggGGGGGGGGgg',
    'gggggggggggg'], { g: '#2f8f4a', G: '#63d36f', e: '#10241a', m: '#10241a' }))];

  const GHOUL = [
    '...bbbbbb...',
    '..bbbbbbbb..',
    '..bbKbbKbb..',
    '..bbKbbKbb..',
    '..bbbbbbbb..',
    '...bmmmmb...',
    '....bbbb....',
    '..rrrbbrrr..',
    '.rrrrbbrrrr.',
    '.brrrbbrrrb.',
    '.b.rrrrrr.b.',
    '...rrrrrr...',
    '...pp..pp...',
    '...pp..pp...',
    '..kkk..kkk..'];
  const GHOUL_B = GHOUL.slice(0, 12).concat(['....pppp....', '....pppp....', '...kkkkkk...']);
  const GP = { b: '#dcd5bb', K: '#e8402f', m: '#3a2a2a', r: '#7a3b3b', p: '#4a3a52', k: '#241a2a' };
  out.ghoul = [finish(grid(GHOUL, GP)), finish(grid(GHOUL_B, GP))];

  const BP = { b: '#c97b5a', K: '#ffe14a', m: '#3a1a1a', r: '#8a2f2f', p: '#4a2a2a', k: '#241414' };
  out.brute = [finish(grid(GHOUL, BP, 2)), finish(grid(GHOUL_B, BP, 2))];

  const KP = { b: '#b58cff', K: '#ffffff', m: '#2a1040', r: '#4a2a8a', p: '#2f1a5a', k: '#1a0f33' };
  out.boss = [finish(grid(GHOUL, KP, 3)), finish(grid(GHOUL_B, KP, 3))];

  const GH = [
    '....wwww....',
    '..wwwwwwww..',
    '.wwwwwwwwww.',
    '.wwKKwwKKww.',
    '.wwKKwwKKww.',
    '.wwwwwmmwww.',
    '.wwwwwmmwww.',
    '.wwwwwwwwww.',
    '.wwwwwwwwww.',
    '.wwwwwwwwww.',
    '.ww.www.www.',
    'ww..ww..ww..'];
  const GHB = GH.slice(0, 10).concat(['.www.ww.www.', '.w..wwww..ww']);
  const GHP = { w: '#9ff3e6', K: '#0b2a33', m: '#0b2a33' };
  out.ghost = [finish(grid(GH, GHP)), finish(grid(GHB, GHP))];

  // летучая мышь — рисуем кадры вручную
  function bat(frame) {
    const c = mk(18, 10), x = c.getContext('2d');
    const wing = frame ? 0 : 3;
    x.fillStyle = '#5b3a8a';
    for (let i = 0; i < 6; i++) { x.fillRect(1 + i, 4 - (frame ? 0 : Math.min(i, 3)) + (i > 3 ? 1 : 0), 1, 3 + (frame ? i >> 1 : 0)); x.fillRect(16 - i, 4 - (frame ? 0 : Math.min(i, 3)) + (i > 3 ? 1 : 0), 1, 3 + (frame ? i >> 1 : 0)); }
    x.fillStyle = '#3a2260'; x.fillRect(7, 3, 4, 5);
    x.fillStyle = '#7a52b8'; x.fillRect(8, 3, 2, 2);
    x.fillStyle = '#ff5a5f'; x.fillRect(8, 5, 1, 1); x.fillRect(10, 5, 1, 1);
    x.fillStyle = '#3a2260'; x.fillRect(7, 2, 1, 2); x.fillRect(10, 2, 1, 2);
    return finish(c);
  }
  out.bat = [bat(0), bat(1)];

  // ---------- природа ----------
  function pine(seed, hue) {
    const r = mulberry(seed), c = mk(28, 40), x = c.getContext('2d');
    x.fillStyle = '#4a2f1b'; x.fillRect(12, 31, 5, 8); x.fillStyle = '#6b4527'; x.fillRect(12, 31, 2, 8);
    const pal = hue ? ['#16402c', '#1f6a4a', '#33946a', '#15332a'] : ['#1d5130', '#2a7a43', '#4fae5c', '#15391f'];
    const tiers = [[34, 14, 12], [26, 13, 10], [18, 13, 8], [10, 10, 5]];
    tiers.forEach(t => {
      const b = t[0], h = t[1], mh = t[2];
      for (let rr = 0; rr < h; rr++) {
        const half = Math.round(2 + rr * (mh - 2) / (h - 1)), y = b - h + rr + 1;
        for (let i = -half; i <= half; i++) {
          let col = pal[0];
          const rel = (i + half) / (2 * half + 1);
          if (rel < 0.38) col = pal[1];
          if (rel < 0.18 && r() < 0.7) col = pal[2];
          if (rr > h - 3) col = pal[3];
          if (r() < 0.08) col = pal[1];
          x.fillStyle = col; x.fillRect(14 + i, y, 1, 1);
        }
      }
    });
    return finish(c);
  }
  out.tree = [pine(11, 0), pine(23, 0), pine(37, 1)];

  function rock(seed) {
    const r = mulberry(seed), c = mk(18, 14), x = c.getContext('2d');
    const pal = ['#4a5062', '#6b7385', '#9aa3b8', '#cfd6e6'];
    for (let j = 0; j < 14; j++) for (let i = 0; i < 18; i++) {
      const dx = (i - 9) / 8.4, dy = (j - 8) / 6.2;
      if (dx * dx + dy * dy > 1) continue;
      const l = (-dx - dy) * 0.5 + 0.5 + (r() - 0.5) * 0.35;
      x.fillStyle = pal[l > 0.78 ? 3 : l > 0.5 ? 2 : l > 0.22 ? 1 : 0];
      x.fillRect(i, j, 1, 1);
    }
    return finish(c);
  }
  out.rock = [rock(5), rock(17), rock(29)];

  function crystal(seed) {
    const r = mulberry(seed), c = mk(16, 22), x = c.getContext('2d');
    function shard(cx, top, bot, hw) {
      for (let y = top; y <= bot; y++) {
        const t = (y - top) / (bot - top), half = Math.round(hw * (t < 0.45 ? t / 0.45 : 1 - (t - 0.45) / 0.55 * 0.35));
        for (let i = -half; i <= half; i++) {
          const rel = (i + half) / (2 * half + 1);
          x.fillStyle = rel < 0.3 ? '#c9f6ff' : rel < 0.65 ? '#5fd6ff' : '#2a8fd0';
          x.fillRect(cx + i, y, 1, 1);
        }
      }
    }
    shard(8, 1, 20, 4); shard(3, 8, 20, 2); shard(13, 10, 20, 2);
    x.fillStyle = '#fff'; x.fillRect(7, 4, 1, 4);
    return finish(c);
  }
  out.crystal = [crystal(1)];

  // ---------- постройки ----------
  function wall() {
    const c = mk(16, 18), x = c.getContext('2d');
    for (let i = 0; i < 4; i++) {
      const top = (i % 2) ? 3 : 1;
      x.fillStyle = '#7a5230'; x.fillRect(i * 4, top + 2, 3, 16 - top - 2);
      x.fillStyle = '#9a6b3e'; x.fillRect(i * 4, top + 2, 1, 16 - top - 2);
      x.fillStyle = '#5a3a1e'; x.fillRect(i * 4 + 2, top + 2, 1, 16 - top - 2);
      x.fillStyle = '#7a5230'; x.fillRect(i * 4 + 1, top, 1, 2);
      x.fillStyle = '#9a6b3e'; x.fillRect(i * 4 + 1, top, 1, 1);
    }
    x.fillStyle = '#c9a05a'; x.fillRect(0, 9, 15, 1); x.fillStyle = '#6b4a24'; x.fillRect(0, 10, 15, 1);
    x.fillStyle = '#c9a05a'; x.fillRect(0, 14, 15, 1);
    return finish(c);
  }
  out.wall = [wall()];

  function turret() {
    const c = mk(16, 20), x = c.getContext('2d');
    x.fillStyle = '#5a6074'; x.fillRect(1, 13, 14, 6);
    x.fillStyle = '#8f98ad'; x.fillRect(1, 13, 14, 2);
    x.fillStyle = '#3d4254'; x.fillRect(1, 17, 14, 2);
    x.fillStyle = '#7a5230'; x.fillRect(5, 6, 6, 8);
    x.fillStyle = '#9a6b3e'; x.fillRect(5, 6, 2, 8);
    x.fillStyle = '#c9a05a'; x.fillRect(4, 5, 8, 2);
    x.fillStyle = '#2a6f8f'; x.fillRect(5, 0, 6, 6);
    x.fillStyle = '#5fd6ff'; x.fillRect(6, 1, 4, 4);
    x.fillStyle = '#e9ffff'; x.fillRect(6, 1, 2, 2);
    return finish(c);
  }
  out.turret = [turret()];

  function torch() {
    const c = mk(8, 20), x = c.getContext('2d');
    x.fillStyle = '#6b4527'; x.fillRect(3, 6, 2, 13); x.fillStyle = '#9a6b3e'; x.fillRect(3, 6, 1, 13);
    x.fillStyle = '#3d4254'; x.fillRect(1, 5, 6, 2);
    x.fillStyle = '#5a6074'; x.fillRect(1, 5, 6, 1);
    x.fillStyle = '#4a2f1b'; x.fillRect(2, 17, 4, 2);
    return finish(c);
  }
  out.torch = [torch()];

  out.logs = [finish((function () {
    const c = mk(22, 10), x = c.getContext('2d');
    function log(x0, y0, dx, dy) {
      for (let i = 0; i < 12; i++) { const px = x0 + Math.round(i * dx), py = y0 + Math.round(i * dy); x.fillStyle = '#6b4527'; x.fillRect(px, py, 3, 3); x.fillStyle = '#9a6b3e'; x.fillRect(px, py, 3, 1); }
      x.fillStyle = '#d9a064'; x.fillRect(x0 + Math.round(11 * dx), y0 + Math.round(11 * dy), 3, 3);
    }
    log(2, 1, 1.5, 0.6); log(2, 8, 1.5, -0.6);
    x.fillStyle = '#6b7385'; for (let i = 0; i < 11; i++) { const a = i / 11 * Math.PI * 2; x.fillRect(11 + Math.round(Math.cos(a) * 10), 5 + Math.round(Math.sin(a) * 4), 2, 2); }
    x.fillStyle = '#9aa3b8'; for (let i = 0; i < 11; i += 2) { const a = i / 11 * Math.PI * 2; x.fillRect(11 + Math.round(Math.cos(a) * 10), 5 + Math.round(Math.sin(a) * 4), 1, 1); }
    return c;
  })())];

  // ---------- иконки интерфейса ----------
  const I = {
    wood: [['..dddd..', '.dBBBBd.', 'dBBllBBd', 'dBlBBlBd', 'dBlBBlBd', 'dBBllBBd', '.dBBBBd.', '..dddd..'], { d: '#5a3a1e', B: '#a9733c', l: '#d9a064' }],
    stone: [['........', '..gggg..', '.gGGGGg.', 'gGGlGGGg', 'gGGGGGGg', 'gGGGGGdg', '.gddddg.', '..gggg..'], { g: '#6b7385', G: '#9aa3b8', l: '#cfd6e6', d: '#4a5062' }],
    crystal: [['...cc...', '..cCCc..', '.cCwCCc.', '.cCwCCc.', '..cCCc..', '..cCCc..', '...cc...', '........'], { c: '#2a9dd8', C: '#6fe3ff', w: '#ffffff' }],
    heart: [['.rr..rr.', 'rRRrrrrr', 'rRRrrrrr', 'rrrrrrrr', '.rrrrrr.', '..rrrr..', '...rr...', '........'], { r: '#e0394a', R: '#ff8a94' }],
    flame: [['...o....', '..oo..o.', '..ooo.oo', '.oooyooo', '.ooyyyoo', '.oyyyyyo', '..oyyyo.', '...ooo..'], { o: '#ff7a1a', y: '#ffd54a' }],
    coin: [['..gggg..', '.gYYYYg.', 'gYYwwYYg', 'gYwYYYYg', 'gYwYYYYg', 'gYYYYYYg', '.gYYYYg.', '..gggg..'], { g: '#b8860b', Y: '#ffd447', w: '#fff3b0' }],
    hammer: [['.gggggg.', '.gGGGGg.', '.gggggg.', '...bb...', '...bb...', '...bb...', '...bb...', '...bb...'], { g: '#6b7385', G: '#cfd6e6', b: '#9a6b3e' }]
  };
  out.icon = {};
  Object.keys(I).forEach(k => { out.icon[k] = grid(I[k][0], I[k][1], 1); });
  out.url = function (c) { return c.toDataURL(); };
  out.iconURL = {};
  Object.keys(out.icon).forEach(k => { out.iconURL[k] = out.icon[k].toDataURL(); });
  out.iconURL.wall = out.wall[0].c.toDataURL();
  out.iconURL.turret = out.turret[0].c.toDataURL();
  out.iconURL.torch = out.torch[0].c.toDataURL();

  // ---------- земля ----------
  function ground() {
    const S = 96, c = mk(S, S), x = c.getContext('2d'), r = mulberry(7);
    x.fillStyle = '#3d8142'; x.fillRect(0, 0, S, S);
    const tones = ['#438a48', '#377a3c', '#4a9450', '#33703a'];
    for (let i = 0; i < 420; i++) { x.fillStyle = tones[(r() * 4) | 0]; x.fillRect((r() * S) | 0, (r() * S) | 0, r() < 0.3 ? 2 : 1, 1); }
    for (let i = 0; i < 26; i++) { // пучки травы
      const px = (r() * (S - 4)) | 0, py = (r() * (S - 4)) | 0;
      x.fillStyle = '#2c6a35'; x.fillRect(px, py + 1, 1, 2); x.fillRect(px + 2, py, 1, 3); x.fillRect(px + 4, py + 1, 1, 2);
      x.fillStyle = '#5fb060'; x.fillRect(px + 2, py, 1, 1);
    }
    const fl = ['#ffffff', '#ff8fb8', '#ffd447', '#9fd7ff'];
    for (let i = 0; i < 9; i++) { const px = (r() * (S - 2)) | 0, py = (r() * (S - 2)) | 0; x.fillStyle = fl[(r() * 4) | 0]; x.fillRect(px, py, 1, 1); x.fillStyle = '#2c6a35'; x.fillRect(px, py + 1, 1, 1); }
    return c;
  }
  out.ground = ground();

  function dirt() {
    const w = 120, h = 84, c = mk(w, h), x = c.getContext('2d'), r = mulberry(3);
    for (let j = 0; j < h; j++) for (let i = 0; i < w; i++) {
      const dx = (i - w / 2) / (w / 2), dy = (j - h / 2) / (h / 2), d = dx * dx + dy * dy + (r() - 0.5) * 0.12;
      if (d > 1) continue;
      x.fillStyle = d > 0.82 ? '#5d4630' : d > 0.5 ? '#4f3a28' : '#43321f';
      x.fillRect(i, j, 1, 1);
    }
    for (let i = 0; i < 40; i++) { const a = r() * 6.28, rr = r() * 0.85; x.fillStyle = r() < 0.5 ? '#6b7385' : '#2f2316'; x.fillRect((w / 2 + Math.cos(a) * rr * w / 2) | 0, (h / 2 + Math.sin(a) * rr * h / 2) | 0, 1, 1); }
    return c;
  }
  out.dirt = dirt();

  // ---------- свет ----------
  function lightSprite(rgb, stops) {
    const c = mk(128, 128), x = c.getContext('2d'), g = x.createRadialGradient(64, 64, 0, 64, 64, 64);
    stops.forEach(s => g.addColorStop(s[0], 'rgba(' + rgb + ',' + s[1] + ')'));
    x.fillStyle = g; x.fillRect(0, 0, 128, 128); return c;
  }
  out.cut = lightSprite('255,255,255', [[0, 1], [0.3, 0.88], [0.6, 0.45], [0.85, 0.12], [1, 0]]);
  out.warm = lightSprite('255,150,60', [[0, 0.55], [0.35, 0.28], [0.7, 0.08], [1, 0]]);
  out.cool = lightSprite('90,210,255', [[0, 0.5], [0.4, 0.22], [0.8, 0.05], [1, 0]]);
  out.purple = lightSprite('170,90,255', [[0, 0.5], [0.4, 0.22], [0.8, 0.05], [1, 0]]);

  // превью героя для меню (в DOM)
  out.heroPreview = function (id) { return out.hero[id][0].c; };
  return out;
})();
