#!/usr/bin/env python3
"""Патчит сгенерированный Capacitor-проект: горизонталь, полный экран, иконка, MainActivity."""
import os, re, shutil, glob

APP = "android/app/src/main"
PKG = "com.nyxvault.lastcampfire"

# 1. Манифест: горизонтальная ориентация
mp = os.path.join(APP, "AndroidManifest.xml")
s = open(mp, encoding="utf-8").read()
if "screenOrientation" not in s:
    s = s.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"', 1)
open(mp, "w", encoding="utf-8").write(s)

# 2. Тема: полный экран + вырез камеры
sp = os.path.join(APP, "res/values/styles.xml")
s = open(sp, encoding="utf-8").read()
extra = ('\n        <item name="android:windowFullscreen">true</item>'
         '\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>')
def add(m):
    return m.group(0) + extra
if "windowFullscreen" not in s:
    s = re.sub(r'<style name="AppTheme\.NoActionBar"[^>]*>', add, s, count=1)
open(sp, "w", encoding="utf-8").write(s)

# 3. MainActivity: иммерсивный режим
ma = os.path.join(APP, "java", *PKG.split("."), "MainActivity.java")
os.makedirs(os.path.dirname(ma), exist_ok=True)
open(ma, "w", encoding="utf-8").write(f"""package {PKG};

import android.os.Bundle;
import android.view.View;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {{
    @Override
    public void onCreate(Bundle savedInstanceState) {{
        super.onCreate(savedInstanceState);
        hideBars();
    }}

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {{
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }}

    private void hideBars() {{
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }}
}}
""")

# 4. Иконка
icon = "resources/icon.png"
if os.path.exists(icon):
    shutil.rmtree(os.path.join(APP, "res/mipmap-anydpi-v26"), ignore_errors=True)
    for d in glob.glob(os.path.join(APP, "res/mipmap-*")):
        for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
            shutil.copy(icon, os.path.join(d, name))
print("Android project patched")

# --- фиксированная подпись: обновления APK ставятся поверх, сохранения не теряются ---
import re as _re
ks_src = "tools/debug.keystore"
gp = "android/app/build.gradle"
if os.path.exists(ks_src) and os.path.exists(gp):
    shutil.copy(ks_src, "android/app/debug.keystore")
    g = open(gp, encoding="utf-8").read()
    if "debug.keystore" not in g:
        sc = 'signingConfigs {\n        debug {\n            storeFile file("debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        }\n    }\n'
        g = g.replace("android {\n", "android {\n    " + sc, 1)
        open(gp, "w", encoding="utf-8").write(g)
    print("signing patched")
