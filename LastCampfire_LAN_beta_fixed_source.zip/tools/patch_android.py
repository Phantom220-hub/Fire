#!/usr/bin/env python3
"""Патчит сгенерированный Capacitor-проект: горизонталь, полный экран, иконка, MainActivity."""
import os, re, shutil, glob

APP = "android/app/src/main"
PKG = "com.nyxvault.lastcampfire"

# 1. Манифест: горизонтальная ориентация
mp = os.path.join(APP, "AndroidManifest.xml")
s = open(mp, encoding="utf-8").read()
if "android.permission.INTERNET" not in s:
    s=s.replace("<manifest", '<manifest\\n    xmlns:tools="http://schemas.android.com/tools"',1) if "xmlns:tools" not in s else s
    s=s.replace("<application", '<uses-permission android:name="android.permission.INTERNET" />\\n    <application',1)
if "screenOrientation" not in s:
    s = s.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"', 1)
open(mp, "w", encoding="utf-8").write(s)

# 2. Тема: полный экран + вырез камеры
sp = os.path.join(APP, "res/values/styles.xml")
s = open(sp, encoding="utf-8").read()
extra = ('\n        <item name="android:windowFullscreen">true</item>'
         '\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>')
def add(m):
    return m.group(0) + extra
if "windowFullscreen" not in s:
    s = re.sub(r'<style name="AppTheme\.NoActionBar"[^>]*>', add, s, count=1)
open(sp, "w", encoding="utf-8").write(s)

# 3. MainActivity: иммерсивный режим
ma = os.path.join(APP, "java", *PKG.split("."), "MainActivity.java")
os.makedirs(os.path.dirname(ma), exist_ok=True)
open(ma, "w", encoding="utf-8").write(f"""package {PKG};

import android.os.Bundle;
import android.view.View;
import com.getcapacitor.BridgeActivity;\nimport com.nyxvault.lastcampfire.LanPlugin;

public class MainActivity extends BridgeActivity {{
    @Override
    public void onCreate(Bundle savedInstanceState) {{
        registerPlugin(LanPlugin.class);\n        super.onCreate(savedInstanceState);
        hideBars();
    }}

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {{
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }}

    private void hideBars() {{
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }}
}}
""")

# 4. Иконка
icon = "resources/icon.png"
if os.path.exists(icon):
    shutil.rmtree(os.path.join(APP, "res/mipmap-anydpi-v26"), ignore_errors=True)
    for d in glob.glob(os.path.join(APP, "res/mipmap-*")):
        for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
            shutil.copy(icon, os.path.join(d, name))
print("Android project patched")

# --- фиксированная подпись: обновления APK ставятся поверх, сохранения не теряются ---
import re as _re
ks_src = "tools/debug.keystore"
gp = "android/app/build.gradle"
if os.path.exists(ks_src) and os.path.exists(gp):
    shutil.copy(ks_src, "android/app/debug.keystore")
    g = open(gp, encoding="utf-8").read()
    if "debug.keystore" not in g:
        sc = 'signingConfigs {\n        debug {\n            storeFile file("debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        }\n    }\n'
        g = g.replace("android {\n", "android {\n    " + sc, 1)
        open(gp, "w", encoding="utf-8").write(g)
    print("signing patched")

# LAN socket plugin: idempotent server, Android Wi-Fi network-bound client sockets,
# discovered host IPv4, bounded listener lifecycle and simple newline messages.
lp = os.path.join(APP, "java", *PKG.split("."), "LanPlugin.java")
open(lp, "w", encoding="utf-8").write(r"""package com.nyxvault.lastcampfire;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import android.content.Context;
import android.net.*;
import android.net.wifi.*;
import java.net.*;
import java.io.*;
import java.util.*;
import java.util.concurrent.*;
@CapacitorPlugin(name="Lan")
public class LanPlugin extends Plugin {
 private static final int PORT=45678;
 private volatile ServerSocket server;
 private volatile Socket socket;
 private volatile PrintWriter writer;
 private volatile boolean hosting=false, connected=false;
 private final ExecutorService pool=Executors.newCachedThreadPool();
 private final Object lifecycle=new Object();
 private ConnectivityManager cm;
 @Override public void load(){cm=(ConnectivityManager)getContext().getSystemService(Context.CONNECTIVITY_SERVICE);}
 private void status(String m){notifyListeners("status",new JSObject().put("message",m));}
 private String localIpv4(){
  try {Enumeration<NetworkInterface> ifs=NetworkInterface.getNetworkInterfaces();
   while(ifs.hasMoreElements()){NetworkInterface ni=ifs.nextElement(); if(!ni.isUp()||ni.isLoopback())continue;
    Enumeration<InetAddress> as=ni.getInetAddresses();while(as.hasMoreElements()){InetAddress a=as.nextElement();
     if(a instanceof Inet4Address&&!a.isLoopbackAddress()&&!a.isLinkLocalAddress())return a.getHostAddress();}}
  }catch(Exception e){} return "IP не определён — проверьте сеть";
 }
 @PluginMethod public void host(PluginCall call){
  synchronized(lifecycle){if(hosting){call.resolve(new JSObject().put("ok",true).put("ip",localIpv4()).put("already",true));status("Сервер уже запущен, повторный запуск не выполняется.");return;} hosting=true;}
  pool.execute(()->{try{ServerSocket ss=new ServerSocket();ss.setReuseAddress(true);ss.bind(new InetSocketAddress(PORT));server=ss;
   status("Сервер слушает порт "+PORT+". IP хоста: "+localIpv4()+". Ожидание второго игрока.");
   Socket accepted=ss.accept();socket=accepted;connected=true;setup(accepted);status("Игрок подключился!");readLoop(accepted);
  }catch(Exception e){if(hosting)status("Ошибка сервера: "+e.getClass().getSimpleName()+": "+e.getMessage());}
   finally{hosting=false;connected=false;closeQuiet(server);server=null;closeQuiet(socket);socket=null;writer=null;status("Сервер остановлен.");}});
  call.resolve(new JSObject().put("ok",true).put("ip",localIpv4()).put("port",PORT));
 }
 private Network wifiNetwork(int timeoutMs)throws Exception{
  final CountDownLatch latch=new CountDownLatch(1);final Network[] result={null};final NetworkCallback cb=new NetworkCallback(){
   @Override public void onAvailable(Network n){result[0]=n;latch.countDown();}
   @Override public void onUnavailable(){latch.countDown();}};
  NetworkRequest req=new NetworkRequest.Builder().addTransportType(NetworkCapabilities.TRANSPORT_WIFI).build();
  cm.requestNetwork(req,cb);
  boolean ok=latch.await(timeoutMs,TimeUnit.MILLISECONDS);
  try{cm.unregisterNetworkCallback(cb);}catch(Exception ignored){}
  if(!ok||result[0]==null)throw new IOException("Wi-Fi network не найден (подключите второй телефон к точке доступа)");
  return result[0];
 }
 @PluginMethod public void connect(PluginCall call){
  String ip=call.getString("ip");if(ip==null||ip.trim().isEmpty()){call.reject("Введите IP хоста");return;}
  if(connected){call.reject("Уже подключено");return;}
  pool.execute(()->{Socket s=null;try{status("Ищем Wi-Fi сеть для LAN...");Network n=wifiNetwork(12000);
    s=new Socket();n.bindSocket(s);s.connect(new InetSocketAddress(ip.trim(),PORT),12000);socket=s;connected=true;setup(s);
    status("Подключено к хосту "+ip.trim()+". Ожидание синхронизации мира (текущая бета — тест связи).");readLoop(s);
   }catch(Exception e){closeQuiet(s);status("Подключение не удалось: "+e.getClass().getSimpleName()+": "+e.getMessage());}
    finally{connected=false;if(socket==s)socket=null;writer=null;}});
  call.resolve(new JSObject().put("ok",true));
 }
 private void setup(Socket s)throws Exception{writer=new PrintWriter(new OutputStreamWriter(s.getOutputStream(),"UTF-8"),true);}
 private void readLoop(Socket s){try{BufferedReader r=new BufferedReader(new InputStreamReader(s.getInputStream(),"UTF-8"));String line;while((line=r.readLine())!=null)notifyListeners("message",new JSObject().put("data",line));}
  catch(Exception e){if(connected)status("Связь потеряна: "+e.getMessage());}}
 @PluginMethod public void send(PluginCall call){String data=call.getString("data","ping");PrintWriter w=writer;if(w==null||!connected){call.reject("Нет соединения");return;}w.println(data);if(w.checkError())call.reject("Ошибка отправки");else call.resolve();}
 @PluginMethod public void stop(PluginCall call){hosting=false;connected=false;closeQuiet(socket);closeQuiet(server);socket=null;server=null;writer=null;call.resolve();status("LAN соединение закрыто.");}
 private void closeQuiet(Closeable c){try{if(c!=null)c.close();}catch(Exception ignored){}}
}
""")
print("LAN plugin patched")
