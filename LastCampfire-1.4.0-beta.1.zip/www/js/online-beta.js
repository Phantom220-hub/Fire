/* Онлайн-бета «Последнего костра».
 * Демонстрационный интерфейс: Google OAuth и сервер пока не подключены.
 */
(function () {
  'use strict';
  const KEY = 'nyxvault_lc_online_beta_v1';
  const HEROES = [
    ['hunter', 'Охотник'], ['mage', 'Маг бури'], ['robot', 'Страж-6'],
    ['knight', 'Рыцарь пламени'], ['engineer', 'Инженер'], ['rogue', 'Тень'], ['necro', 'Некромант']
  ];
  const ACHIEVEMENTS = [
    ['k100', 'Охотник'], ['k1000', 'Истребитель'], ['n5', 'Выживший'],
    ['n10', 'Ночной страж'], ['n20', 'Хранитель огня'], ['b1', 'Убийца боссов'],
    ['b4', 'Повелитель тьмы'], ['c10', 'Кладоискатель'], ['bl50', 'Строитель'],
    ['dg3', 'Исследователь'], ['au', 'Золотая лихорадка'], ['pet', 'Друг зверей']
  ];
  const DEFAULT = {
    nickname: 'Anas_Dev', signedIn: false, selected: 'local',
    players: [
      { id: 'local', nick: 'Anas_Dev', online: true, coins: 0, heroes: ['hunter'], achievements: [] },
      { id: 'nightwolf', nick: 'NightWolf', online: true, coins: 1250, heroes: ['hunter', 'mage'], achievements: ['n5'] },
      { id: 'firefox', nick: 'FireFox', online: false, coins: 840, heroes: ['hunter', 'robot'], achievements: [] },
      { id: 'shadow', nick: 'ShadowTJ', online: false, coins: 320, heroes: ['hunter'], achievements: ['k100'] }
    ]
  };
  let data;
  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || 'null');
    data = Object.assign({}, DEFAULT, saved || {});
    data.players = Array.isArray(data.players) && data.players.length ? data.players : DEFAULT.players.map(p => Object.assign({}, p));
  } catch (_) { data = JSON.parse(JSON.stringify(DEFAULT)); }

  const esc = value => String(value == null ? '' : value).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(data)); } catch (_) {} };
  const localPlayer = () => data.players.find(p => p.id === 'local');
  const profile = () => (window.__dbg && window.__dbg.getProfile) ? window.__dbg.getProfile() : { coins: 0, best: 0, owned: ['hunter'] };
  const online = () => typeof navigator !== 'undefined' && navigator.onLine;
  const playerName = () => data.nickname || 'Anas_Dev';

  const root = document.createElement('section');
  root.id = 'onlineBeta';
  root.setAttribute('aria-label', 'Онлайн и администрирование — бета');
  root.innerHTML = '<div class="ob-wrap" role="dialog" aria-modal="true">' +
    '<div class="ob-top"><div><h2>ОНЛАЙН / АККАУНТ</h2><div class="ob-muted">Бета 1.4 · демонстрационный режим</div></div><span class="ob-tag">BETA DEMO</span></div>' +
    '<div class="ob-warning">Это демонстрация интерфейса. Вход Google и настоящий сервер ещё не подключены. Игроки, кроме профиля этого телефона, являются примерами.</div>' +
    '<div class="ob-tabs"><button data-tab="profile" class="active">Профиль</button><button data-tab="players">Игроки</button><button data-tab="admin">Админ-панель</button><button class="close" data-action="close">Закрыть</button></div>' +
    '<div id="ob-content"></div><div class="ob-success" id="ob-message" aria-live="polite"></div>' +
    '</div>';
  document.body.appendChild(root);
  const content = root.querySelector('#ob-content');
  const message = root.querySelector('#ob-message');
  let tab = 'profile';

  function currentPlayers() {
    const list = data.players.map(p => Object.assign({}, p));
    const local = list.find(p => p.id === 'local');
    if (local) {
      local.nick = playerName();
      local.online = online() && data.signedIn;
      const p = profile();
      local.coins = p.coins || 0;
      local.heroes = p.owned || ['hunter'];
    }
    return list;
  }
  function renderProfile() {
    const p = profile();
    content.innerHTML = '<div class="ob-card"><div class="ob-row"><b>Текущий профиль</b><span class="ob-tag">' + (data.signedIn ? 'ДЕМО-ВХОД' : 'ГОСТЬ') + '</span></div>' +
      '<label for="ob-nick">Игровой ник</label><input id="ob-nick" maxlength="20" value="' + esc(playerName()) + '" autocomplete="nickname">' +
      '<div class="ob-row"><span>Подключение устройства</span><b style="color:' + (online() ? '#7dff8f' : '#aab4d6') + '">' + (online() ? 'Есть интернет' : 'Офлайн') + '</b></div>' +
      '<div class="ob-row"><span>Статус аккаунта</span><b>' + (data.signedIn ? 'Вошёл (демо)' : 'Не авторизован') + '</b></div>' +
      '<div class="ob-row"><span>Монеты на этом устройстве</span><b>🪙 ' + (p.coins || 0) + '</b></div>' +
      '<div class="ob-row"><span>Лучший результат</span><b>' + (p.best || 0) + ' ноч.</b></div></div>' +
      '<button class="primary" data-action="demo-login">' + (data.signedIn ? 'Демо-аккаунт подключён' : 'Продолжить как тестовый аккаунт') + '</button> ' +
      '<button data-action="logout">Выйти</button>' +
      '<p>Настоящая кнопка «Войти через Google» появится после настройки OAuth и серверной базы. Этот тестовый вход не отправляет данные в интернет.</p>';
  }
  function renderPlayers() {
    const players = currentPlayers();
    content.innerHTML = '<div class="ob-card"><div class="ob-row"><b>Список игроков</b><span class="ob-muted">' + players.filter(p => p.online).length + ' онлайн</span></div>' +
      players.map(p => '<div class="ob-player"><span class="ob-dot ' + (p.online ? '' : 'off') + '"></span><div style="flex:1"><b>' + esc(p.nick) + '</b><div class="ob-muted">' + (p.id === 'local' ? 'Текущий телефон' : 'Демонстрационный игрок') + '</div></div><b style="color:' + (p.online ? '#7dff8f' : '#aab4d6') + '">' + (p.online ? 'В сети' : 'Не в сети') + '</b></div>').join('') +
      '</div><p>В реальной версии список будет приходить с сервера и содержать только аккаунты, которые действительно подключены.</p>';
  }
  function renderAdmin() {
    const players = currentPlayers();
    const selected = players.find(p => p.id === data.selected) || players[0];
    data.selected = selected.id;
    const p = selected.id === 'local' ? profile() : selected;
    content.innerHTML = '<div class="ob-card"><b>Выбрать игрока</b><select id="ob-player">' + players.map(x => '<option value="' + esc(x.id) + '" ' + (x.id === selected.id ? 'selected' : '') + '>' + esc(x.nick) + (x.id === 'local' ? ' — этот телефон' : ' — демо') + '</option>').join('') + '</select>' +
      '<div class="ob-row"><span>Статус</span><b>' + (selected.online ? 'В сети' : 'Не в сети') + '</b></div>' +
      '<div class="ob-row"><span>Монеты</span><b>🪙 ' + (p.coins || 0) + '</b></div>' +
      '<div class="ob-row"><span>Открыто героев</span><b>' + ((p.owned || p.heroes || ['hunter']).length) + ' / 7</b></div></div>' +
      '<div class="ob-card"><b>Выдать награду</b><div class="ob-grid">' +
      '<button class="primary" data-action="coins">+5000 монет</button>' +
      '<button data-action="coins-custom">+1000 монет</button></div>' +
      '<label for="ob-hero">Выдать героя</label><select id="ob-hero">' + HEROES.map(h => '<option value="' + h[0] + '">' + h[1] + '</option>').join('') + '</select><button data-action="hero">Открыть героя</button>' +
      '<label for="ob-ach">Выдать достижение</label><select id="ob-ach">' + ACHIEVEMENTS.map(a => '<option value="' + a[0] + '">' + a[1] + '</option>').join('') + '</select><button data-action="achievement">Выдать достижение</button></div>' +
      '<p>Награды для профиля этого телефона изменяют локальное сохранение. Для остальных тестовых игроков изменения хранятся только в демонстрационном списке.</p>';
  }
  function render() {
    root.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('active', b.dataset.tab === tab));
    if (tab === 'profile') renderProfile();
    else if (tab === 'players') renderPlayers();
    else renderAdmin();
  }
  function open() { root.classList.add('on'); tab = 'profile'; message.textContent = ''; render(); }
  function close() { root.classList.remove('on'); }
  function notify(text) { message.textContent = text; }
  function selectedRecord() { return data.players.find(p => p.id === data.selected) || localPlayer(); }
  function grantCoins(amount) {
    const p = selectedRecord();
    if (!p) return;
    if (p.id === 'local') {
      if (!window.__dbg || !window.__dbg.grantCoins || !window.__dbg.grantCoins(amount)) { notify('Не удалось выдать монеты.'); return; }
    } else p.coins = (p.coins || 0) + amount;
    save(); render(); notify('В демо выдано ' + amount + ' монет игроку ' + p.nick + '.');
  }
  function grantHero(id) {
    const p = selectedRecord();
    if (!p) return;
    if (p.id === 'local') {
      if (!window.__dbg || !window.__dbg.grantHero || !window.__dbg.grantHero(id)) { notify('Не удалось открыть героя.'); return; }
    } else { p.heroes = p.heroes || ['hunter']; if (!p.heroes.includes(id)) p.heroes.push(id); }
    save(); render(); notify('Герой открыт в демонстрационном профиле ' + p.nick + '.');
  }
  function grantAchievement(id) {
    const p = selectedRecord();
    if (!p) return;
    if (p.id === 'local') {
      if (!window.__dbg || !window.__dbg.grantAchievement || !window.__dbg.grantAchievement(id)) { notify('Не удалось выдать достижение.'); return; }
    } else { p.achievements = p.achievements || []; if (!p.achievements.includes(id)) p.achievements.push(id); }
    save(); render(); notify('Достижение выдано в демонстрационном профиле ' + p.nick + '.');
  }

  document.getElementById('bOnline').addEventListener('click', open);
  root.addEventListener('click', event => {
    const tabButton = event.target.closest('[data-tab]');
    if (tabButton) { tab = tabButton.dataset.tab; message.textContent = ''; render(); return; }
    const actionButton = event.target.closest('[data-action]');
    if (!actionButton) return;
    const action = actionButton.dataset.action;
    if (action === 'close') close();
    else if (action === 'demo-login') {
      const input = root.querySelector('#ob-nick');
      const nick = (input && input.value.trim()) || playerName();
      if (!/^[\p{L}\p{N}_-]{3,20}$/u.test(nick)) { notify('Ник: 3–20 символов, буквы, цифры, _ или -.'); return; }
      data.nickname = nick; data.signedIn = true; const lp = localPlayer(); if (lp) lp.nick = nick; save(); render(); notify('Демо-профиль подключён. Google ещё не настроен.');
    } else if (action === 'logout') { data.signedIn = false; save(); render(); notify('Вы вышли из тестового аккаунта.'); }
    else if (action === 'coins') grantCoins(5000);
    else if (action === 'coins-custom') grantCoins(1000);
    else if (action === 'hero') { const el = root.querySelector('#ob-hero'); if (el) grantHero(el.value); }
    else if (action === 'achievement') { const el = root.querySelector('#ob-ach'); if (el) grantAchievement(el.value); }
  });
  root.addEventListener('change', event => {
    if (event.target.id === 'ob-player') { data.selected = event.target.value; save(); render(); }
  });
  window.addEventListener('online', () => { if (root.classList.contains('on')) render(); });
  window.addEventListener('offline', () => { if (root.classList.contains('on')) render(); });
})();
