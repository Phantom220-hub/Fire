#!/usr/bin/env python3
"""Патчит сгенерированный Capacitor-проект: горизонталь, полный экран, иконка, MainActivity."""
import os, re, shutil, glob

APP = "android/app/src/main"
PKG = "com.nyxvault.lastcampfire"

# 1. Манифест: горизонтальная ориентация
mp = os.path.join(APP, "AndroidManifest.xml")
s = open(mp, encoding="utf-8").read()
if "android.permission.INTERNET" not in s:
    s=s.replace("<manifest", '<manifest\\n    xmlns:tools="http://schemas.android.com/tools"',1) if "xmlns:tools" not in s else s
    s=s.replace("<application", '<uses-permission android:name="android.permission.INTERNET" />\\n    <application',1)
if "screenOrientation" not in s:
    s = s.replace("<activity", '<activity\n            android:screenOrientation="sensorLandscape"', 1)
open(mp, "w", encoding="utf-8").write(s)

# 2. Тема: полный экран + вырез камеры
sp = os.path.join(APP, "res/values/styles.xml")
s = open(sp, encoding="utf-8").read()
extra = ('\n        <item name="android:windowFullscreen">true</item>'
         '\n        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>')
def add(m):
    return m.group(0) + extra
if "windowFullscreen" not in s:
    s = re.sub(r'<style name="AppTheme\.NoActionBar"[^>]*>', add, s, count=1)
open(sp, "w", encoding="utf-8").write(s)

# 3. MainActivity: иммерсивный режим
ma = os.path.join(APP, "java", *PKG.split("."), "MainActivity.java")
os.makedirs(os.path.dirname(ma), exist_ok=True)
open(ma, "w", encoding="utf-8").write(f"""package {PKG};

import android.os.Bundle;
import android.view.View;
import com.getcapacitor.BridgeActivity;\nimport com.nyxvault.lastcampfire.LanPlugin;

public class MainActivity extends BridgeActivity {{
    @Override
    public void onCreate(Bundle savedInstanceState) {{
        registerPlugin(LanPlugin.class);\n        super.onCreate(savedInstanceState);
        hideBars();
    }}

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {{
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }}

    private void hideBars() {{
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            | View.SYSTEM_UI_FLAG_FULLSCREEN
            | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
            | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN);
    }}
}}
""")

# 4. Иконка
icon = "resources/icon.png"
if os.path.exists(icon):
    shutil.rmtree(os.path.join(APP, "res/mipmap-anydpi-v26"), ignore_errors=True)
    for d in glob.glob(os.path.join(APP, "res/mipmap-*")):
        for name in ("ic_launcher.png", "ic_launcher_round.png", "ic_launcher_foreground.png"):
            shutil.copy(icon, os.path.join(d, name))
print("Android project patched")

# --- фиксированная подпись: обновления APK ставятся поверх, сохранения не теряются ---
import re as _re
ks_src = "tools/debug.keystore"
gp = "android/app/build.gradle"
if os.path.exists(ks_src) and os.path.exists(gp):
    shutil.copy(ks_src, "android/app/debug.keystore")
    g = open(gp, encoding="utf-8").read()
    if "debug.keystore" not in g:
        sc = 'signingConfigs {\n        debug {\n            storeFile file("debug.keystore")\n            storePassword "android"\n            keyAlias "androiddebugkey"\n            keyPassword "android"\n        }\n    }\n'
        g = g.replace("android {\n", "android {\n    " + sc, 1)
        open(gp, "w", encoding="utf-8").write(g)
    print("signing patched")

# LAN socket plugin (local Wi-Fi/hotspot only)
lp = os.path.join(APP, "java", *PKG.split("."), "LanPlugin.java")
open(lp, "w", encoding="utf-8").write(r"""package com.nyxvault.lastcampfire;
import com.getcapacitor.*;
import com.getcapacitor.annotation.*;
import java.net.*;
import java.io.*;
import org.json.JSONObject;
import java.util.concurrent.*;
@CapacitorPlugin(name="Lan")
public class LanPlugin extends Plugin {
 volatile ServerSocket server; volatile Socket socket; volatile BufferedReader reader; volatile PrintWriter writer;
 ExecutorService pool=Executors.newCachedThreadPool();
 @PluginMethod public void host(PluginCall call){
  pool.execute(()->{try{server=new ServerSocket(45678); notifyListeners("status",new JSObject().put("message","Сервер запущен: порт 45678"));
   socket=server.accept(); setup(socket); notifyListeners("status",new JSObject().put("message","Игрок подключился")); readLoop();
  }catch(Exception e){notifyListeners("status",new JSObject().put("message","Ошибка сервера: "+e.getMessage()));}});
  call.resolve(new JSObject().put("ok",true));
 }
 @PluginMethod public void connect(PluginCall call){
  String ip=call.getString("ip"); if(ip==null||ip.trim().isEmpty()){call.reject("Укажите IP");return;}
  pool.execute(()->{try{socket=new Socket();socket.connect(new InetSocketAddress(ip.trim(),45678),8000); setup(socket);notifyListeners("status",new JSObject().put("message","Подключено к "+ip));readLoop();}catch(Exception e){notifyListeners("status",new JSObject().put("message","Не удалось подключиться: "+e.getMessage()));}});
  call.resolve(new JSObject().put("ok",true));
 }
 void setup(Socket s)throws Exception{reader=new BufferedReader(new InputStreamReader(s.getInputStream()));writer=new PrintWriter(s.getOutputStream(),true);}
 void readLoop(){try{String line;while((line=reader.readLine())!=null)notifyListeners("message",new JSObject().put("data",line));}catch(Exception e){notifyListeners("status",new JSObject().put("message","Соединение закрыто"));}}
 @PluginMethod public void send(PluginCall call){String data=call.getString("data","ping");if(writer==null){call.reject("Нет соединения");return;}writer.println(data);call.resolve();}
 @PluginMethod public void stop(PluginCall call){try{if(socket!=null)socket.close();if(server!=null)server.close();}catch(Exception e){}call.resolve();}
}
""")
